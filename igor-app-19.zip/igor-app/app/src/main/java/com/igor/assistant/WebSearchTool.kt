package com.igor.assistant

import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.util.concurrent.TimeUnit

/**
 * Recherche web réelle, utilisée quand l'utilisateur active l'interrupteur "recherche
 * web" du chat, ou pose une question qui semble manifestement factuelle / d'actualité
 * (voir [ChatViewModel.looksTimely]).
 *
 * Version 2 : contrairement à la première mouture, ce module ne se contente plus des
 * courts extraits (snippets) renvoyés par le moteur de recherche — souvent une phrase
 * tronquée, insuffisante pour répondre correctement. Il va aussi lire le contenu réel
 * des meilleures pages trouvées pour donner au modèle de vraies informations à citer.
 * Deux points d'entrée DuckDuckGo sont essayés l'un après l'autre (la version "html"
 * puis la version "lite", plus simple et plus tolérante au scraping), pour limiter les
 * échecs dus à un blocage ponctuel ou à un changement de mise en page.
 *
 * En cas d'échec (pas de réseau, service indisponible, aucun résultat exploitable), la
 * fonction retourne un [Outcome] vide accompagné d'une raison explicite : IGOR sait
 * alors qu'il doit le dire honnêtement à l'utilisateur plutôt que prétendre avoir
 * trouvé une réponse (voir la construction du prompt caché dans [ChatViewModel]).
 */
object WebSearchTool {

    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    private const val userAgent =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128 Mobile Safari/537.36"

    data class Result(val title: String, val url: String, val snippet: String, val excerpt: String = "")
    data class Outcome(val results: List<Result>, val failureReason: String? = null)

    /**
     * Lance une recherche complète pour [query] : trouve jusqu'à [maxResults] résultats,
     * puis va lire le contenu des [maxPagesToFetch] meilleurs pour enrichir le contexte
     * envoyé au modèle. Ne lève jamais d'exception ; retourne toujours un [Outcome],
     * vide et documenté en cas de problème.
     */
    fun search(query: String, maxResults: Int = 5, maxPagesToFetch: Int = 3): Outcome {
        val rawResults = try {
            fetchFromHtmlEndpoint(query, maxResults).ifEmpty { fetchFromLiteEndpoint(query, maxResults) }
        } catch (e: Exception) {
            return Outcome(emptyList(), "erreur réseau (${e.message ?: e::class.simpleName})")
        }

        if (rawResults.isEmpty()) {
            return Outcome(emptyList(), "aucun résultat renvoyé par le moteur de recherche")
        }

        // On enrichit les meilleurs résultats avec le vrai contenu de la page : le
        // snippet seul (une phrase tronquée) suffit rarement à répondre correctement.
        val enriched = rawResults.mapIndexed { index, r ->
            if (index < maxPagesToFetch) {
                val excerpt = try {
                    fetchPageExcerpt(r.url)
                } catch (_: Exception) {
                    ""
                }
                r.copy(excerpt = excerpt)
            } else r
        }

        return Outcome(enriched)
    }

    private fun fetchFromHtmlEndpoint(query: String, maxResults: Int): List<Result> {
        val url = "https://html.duckduckgo.com/html/?q=" + java.net.URLEncoder.encode(query, "UTF-8")
        val doc = fetchDocument(url) ?: return emptyList()
        return doc.select("div.result").take(maxResults).mapNotNull { el ->
            val linkEl = el.select("a.result__a").firstOrNull() ?: return@mapNotNull null
            val title = linkEl.text().trim()
            val href = resolveDuckDuckGoRedirect(linkEl.attr("href"))
            val snippet = el.select("a.result__snippet, .result__snippet").firstOrNull()?.text()?.trim().orEmpty()
            if (title.isEmpty() && snippet.isEmpty()) null
            else Result(title, href, snippet)
        }
    }

    /** Point d'entrée "lite" : mise en page plus simple (table HTML), souvent plus tolérante au scraping. */
    private fun fetchFromLiteEndpoint(query: String, maxResults: Int): List<Result> {
        val url = "https://lite.duckduckgo.com/lite/?q=" + java.net.URLEncoder.encode(query, "UTF-8")
        val doc = fetchDocument(url) ?: return emptyList()
        return doc.select("a.result-link").take(maxResults).mapNotNull { linkEl ->
            val title = linkEl.text().trim()
            if (title.isEmpty()) return@mapNotNull null
            val href = resolveDuckDuckGoRedirect(linkEl.attr("href"))
            val snippet = linkEl.parents().firstOrNull { it.tagName() == "tr" }
                ?.nextElementSibling()
                ?.select("td.result-snippet")
                ?.firstOrNull()
                ?.text()
                ?.trim()
                .orEmpty()
            Result(title, href, snippet)
        }
    }

    private fun fetchDocument(url: String): Document? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .header("Accept-Language", "fr-FR,fr;q=0.9")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val html = response.body?.string() ?: return null
            return Jsoup.parse(html)
        }
    }

    /** DuckDuckGo renvoie des liens de redirection (`//duckduckgo.com/l/?uddg=...`) : on récupère la vraie URL. */
    private fun resolveDuckDuckGoRedirect(href: String): String {
        if (!href.contains("uddg=")) return if (href.startsWith("//")) "https:$href" else href
        val encoded = href.substringAfter("uddg=").substringBefore("&")
        return try {
            java.net.URLDecoder.decode(encoded, "UTF-8")
        } catch (_: Exception) {
            href
        }
    }

    /** Va lire une page trouvée et en extrait un court passage de texte utile (hors menus, scripts, pubs). */
    private fun fetchPageExcerpt(url: String, maxChars: Int = 500): String {
        if (url.isBlank() || !url.startsWith("http")) return ""
        val request = Request.Builder().url(url).header("User-Agent", userAgent).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return ""
            val html = response.body?.string() ?: return ""
            val doc = Jsoup.parse(html)
            doc.select("script, style, nav, header, footer, noscript").remove()
            val text = doc.body()?.text().orEmpty()
            return if (text.length > maxChars) text.take(maxChars).trimEnd() + "…" else text
        }
    }

    /** Formate les résultats pour les injecter dans le prompt caché envoyé au modèle. */
    fun formatForPrompt(results: List<Result>): String {
        if (results.isEmpty()) return ""
        return results.mapIndexed { i, r ->
            val body = r.excerpt.ifEmpty { r.snippet }
            "(${i + 1}) ${r.title} — $body [source : ${r.url}]"
        }.joinToString(" | ")
    }
}
