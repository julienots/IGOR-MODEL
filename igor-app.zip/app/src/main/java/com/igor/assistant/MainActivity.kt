package com.igor.assistant

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.igor.assistant.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashDiagnostics.markPhase(this, "MAIN_ACTIVITY_ONCREATE")
        val previousCrash = CrashDiagnostics.previousProcessReport(this)

        setContent {
            IgorTheme {
                IgorApp(viewModel)
            }
        }

        CrashDiagnostics.markPhase(this, "UI_CREATED")

        if (previousCrash != null) {
            android.app.AlertDialog.Builder(this)
                .setTitle("IGOR a planté lors du précédent lancement")
                .setMessage(previousCrash)
                .setPositiveButton("J’ai compris") { _, _ ->
                    CrashDiagnostics.clearPreviousReport(this)
                }
                .setNeutralButton("Copier le rapport") { _, _ ->
                    val report = CrashDiagnostics.readCrashFile(this) ?: previousCrash
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(
                        android.content.ClipData.newPlainText("Rapport de crash IGOR", report)
                    )
                    Toast.makeText(this, "Rapport copié", Toast.LENGTH_SHORT).show()
                }
                .show()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IgorApp(viewModel: ChatViewModel) {
    val messages by viewModel.messages.collectAsState()
    val modelState by viewModel.modelState.collectAsState()
    val error by viewModel.errorMessage.collectAsState()
    val isThinking by viewModel.isThinking.collectAsState()

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val pickModel = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { viewModel.importModel(it) } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = IgorPanel) {
                Column(Modifier.padding(20.dp)) {
                    Text("IGOR", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = IgorText)
                    Spacer(Modifier.height(18.dp))
                    DrawerItem("Nouvelle conversation") {
                        viewModel.newConversation()
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Importer / changer de modèle (.litertlm)") {
                        scope.launch { drawerState.close() }
                        pickModel.launch(arrayOf("*/*"))
                    }
                    DrawerItem("Réinitialiser IGOR", danger = true) {
                        viewModel.resetModel()
                        scope.launch { drawerState.close() }
                    }
                    Spacer(Modifier.weight(1f))
                    Text(
                        "IGOR fonctionne entièrement hors ligne : le modèle de langage tourne directement sur cet appareil, sans serveur distant.",
                        fontSize = 12.sp,
                        color = IgorMuted,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    ) {
        Scaffold(
            containerColor = IgorBackground,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = IgorBackground,
                        titleContentColor = IgorText
                    ),
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = IgorText)
                        }
                    },
                    title = { Text("IGOR", fontWeight = FontWeight.SemiBold) },
                    actions = {
                        val (dotColor, label) = when (modelState) {
                            ModelState.READY -> Color(0xFF5B8C5A) to "actif"
                            ModelState.LOADING -> IgorAccent to "chargement…"
                            else -> IgorMuted to "modèle requis"
                        }
                        Box(
                            Modifier
                                .padding(end = 16.dp)
                                .size(8.dp)
                                .background(
                                    dotColor,
                                    shape = androidx.compose.foundation.shape.CircleShape
                                )
                        )
                        Text(
                            label,
                            fontSize = 12.sp,
                            color = IgorMuted,
                            modifier = Modifier.padding(end = 12.dp)
                        )
                    }
                )
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (modelState) {
                    ModelState.ABSENT, ModelState.ERROR -> ModelSetupScreen(
                        error = error,
                        onPick = { pickModel.launch(arrayOf("*/*")) }
                    )
                    ModelState.LOADING -> LoadingScreen()
                    ModelState.READY -> ChatScreen(
                        messages = messages,
                        isThinking = isThinking,
                        onSend = viewModel::send
                    )
                }
            }
        }
    }
}

@Composable
fun DrawerItem(label: String, danger: Boolean = false, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        color = IgorPanel2,
        shape = RoundedCornerShape(9.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Text(
            label,
            modifier = Modifier.padding(12.dp),
            color = if (danger) IgorDanger else IgorText,
            fontSize = 14.sp
        )
    }
}

@Composable
fun ModelSetupScreen(error: String?, onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("IGOR", fontSize = 34.sp, fontWeight = FontWeight.SemiBold, color = IgorText)
        Spacer(Modifier.height(10.dp))
        Text(
            "Pour discuter, IGOR a besoin d'un modèle .litertlm compatible avec cette version de LiteRT-LM. Choisis ton fichier modèle pour le charger.",
            color = IgorMuted,
            fontSize = 14.sp,
            lineHeight = 20.sp
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "1. Sur ton téléphone, télécharge un modèle .litertlm compatible.\n2. Reviens ici et choisis ce fichier.",
            color = IgorMuted,
            fontSize = 13.sp,
            lineHeight = 19.sp
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onPick,
            colors = ButtonDefaults.buttonColors(
                containerColor = IgorAccent,
                contentColor = IgorAccentInk
            )
        ) {
            Text("Choisir le fichier modèle")
        }
        if (error != null) {
            Spacer(Modifier.height(14.dp))
            Text(
                error,
                color = IgorDanger,
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
fun LoadingScreen() {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(color = IgorAccent)
        Spacer(Modifier.height(14.dp))
        Text("Chargement du modèle…", color = IgorMuted, fontSize = 13.sp)
    }
}

@Composable
fun ChatScreen(messages: List<ChatMessage>, isThinking: Boolean, onSend: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Column(Modifier.fillMaxSize()) {
        if (messages.isEmpty()) {
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("IGOR", fontSize = 30.sp, fontWeight = FontWeight.SemiBold, color = IgorText)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Pose une question, discute librement, ou donne-moi un calcul à résoudre.",
                    color = IgorMuted,
                    fontSize = 14.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages) { msg -> MessageBubble(msg) }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .background(IgorPanel, RoundedCornerShape(18.dp))
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Écris à IGOR…", color = IgorMuted) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = IgorText,
                    unfocusedTextColor = IgorText,
                )
            )
            IconButton(
                enabled = !isThinking && input.isNotBlank(),
                onClick = {
                    onSend(input)
                    input = ""
                },
                modifier = Modifier
                    .padding(4.dp)
                    .background(IgorAccent, androidx.compose.foundation.shape.CircleShape)
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Envoyer", tint = IgorAccentInk)
            }
        }
    }
}

@Composable
fun MessageBubble(msg: ChatMessage) {
    val isUser = msg.role == Role.USER
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (isUser) IgorAccent else IgorPanel2,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Text(
                text = msg.text.ifEmpty { "…" },
                color = if (isUser) IgorAccentInk else IgorText,
                modifier = Modifier.padding(12.dp),
                fontSize = 15.sp,
                lineHeight = 21.sp
            )
        }
    }
}
