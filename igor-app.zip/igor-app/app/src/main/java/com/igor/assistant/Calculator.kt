package com.igor.assistant

import kotlin.math.pow

/**
 * Moteur de calcul déterministe : IGOR ne "devine" jamais un résultat numérique,
 * il l'obtient toujours de ce moteur puis le formule dans sa réponse.
 */
object Calculator {

    private val leadIn = Regex(
        "^(combien\\s+(fait|font|vaut|valent)|calcule(?:r)?|quel\\s+est\\s+le\\s+r[ée]sultat\\s+de|r[ée]sous|c'est\\s+quoi)\\s*[:\\-]?\\s*",
        RegexOption.IGNORE_CASE
    )

    /** Retourne l'expression brute extraite du message si celui-ci ressemble à un calcul, sinon null. */
    fun extractExpression(raw: String): String? {
        var s = raw.trim()
        s = leadIn.replace(s, "")
        s = s.trimEnd('?', ' ')
        if (s.isEmpty()) return null
        if (!s.matches(Regex("^[0-9+\\-*/^%().,\\s]+$"))) return null
        if (!s.any { it.isDigit() }) return null
        if (!s.any { it in "+-*/^%" }) return null
        return s
    }

    /** Évalue une expression arithmétique et renvoie un résultat arrondi proprement, ou lève une exception. */
    fun evaluate(expression: String): Double {
        val normalized = expression.replace(',', '.')
        val parser = ExprParser(normalized)
        val result = parser.parseExpression()
        parser.skipSpaces()
        if (!parser.isAtEnd()) throw IllegalArgumentException("Expression invalide")
        if (result.isNaN() || result.isInfinite()) throw IllegalArgumentException("Résultat invalide")
        return Math.round(result * 1e10) / 1e10
    }

    fun format(value: Double): String {
        var s = if (value == value.toLong().toDouble()) value.toLong().toString() else value.toString()
        if (s.contains('.')) {
            s = s.trimEnd('0').trimEnd('.')
        }
        return s.replace('.', ',')
    }

    /** Petit analyseur récursif descendant : expr -> terme (['+'|'-'] terme)*  etc. Gère % et ^. */
    private class ExprParser(private val text: String) {
        private var pos = 0

        fun isAtEnd() = pos >= text.length

        fun skipSpaces() {
            while (pos < text.length && text[pos].isWhitespace()) pos++
        }

        fun parseExpression(): Double {
            skipSpaces()
            var value = parseTerm()
            while (true) {
                skipSpaces()
                if (isAtEnd()) break
                val c = text[pos]
                if (c == '+') { pos++; value += parseTerm() }
                else if (c == '-') { pos++; value -= parseTerm() }
                else break
            }
            return value
        }

        private fun parseTerm(): Double {
            skipSpaces()
            var value = parseFactor()
            while (true) {
                skipSpaces()
                if (isAtEnd()) break
                val c = text[pos]
                if (c == '*') { pos++; value *= parseFactor() }
                else if (c == '/') {
                    pos++
                    val divisor = parseFactor()
                    if (divisor == 0.0) throw ArithmeticException("Division par zéro")
                    value /= divisor
                } else if (c == '%') { pos++; value %= parseFactor() }
                else break
            }
            return value
        }

        private fun parseFactor(): Double {
            skipSpaces()
            var value = parseUnary()
            skipSpaces()
            if (!isAtEnd() && text[pos] == '^') {
                pos++
                val exponent = parseFactor()
                value = value.pow(exponent)
            }
            return value
        }

        private fun parseUnary(): Double {
            skipSpaces()
            if (!isAtEnd() && text[pos] == '-') { pos++; return -parseUnary() }
            if (!isAtEnd() && text[pos] == '+') { pos++; return parseUnary() }
            return parsePrimary()
        }

        private fun parsePrimary(): Double {
            skipSpaces()
            if (isAtEnd()) throw IllegalArgumentException("Expression incomplète")
            val c = text[pos]
            if (c == '(') {
                pos++
                val value = parseExpression()
                skipSpaces()
                if (isAtEnd() || text[pos] != ')') throw IllegalArgumentException("Parenthèse manquante")
                pos++
                return applyTrailingPercent(value)
            }
            val start = pos
            while (pos < text.length && (text[pos].isDigit() || text[pos] == '.')) pos++
            if (pos == start) throw IllegalArgumentException("Nombre attendu")
            val number = text.substring(start, pos).toDouble()
            return applyTrailingPercent(number)
        }

        private fun applyTrailingPercent(value: Double): Double {
            skipSpaces()
            if (!isAtEnd() && text[pos] == '%') {
                pos++
                return value / 100.0
            }
            return value
        }
    }
}
