package com.igor.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val IgorBackground = Color(0xFF14181D)
val IgorPanel = Color(0xFF1B2027)
val IgorPanel2 = Color(0xFF20262E)
val IgorLine = Color(0x1AEDEAE3)
val IgorText = Color(0xFFEDEAE3)
val IgorMuted = Color(0xFF8B94A0)
val IgorAccent = Color(0xFFD79A52)
val IgorAccentInk = Color(0xFF14181D)
val IgorDanger = Color(0xFFE08770)

private val IgorColors = darkColorScheme(
    background = IgorBackground,
    surface = IgorPanel,
    primary = IgorAccent,
    onPrimary = IgorAccentInk,
    onBackground = IgorText,
    onSurface = IgorText,
    secondary = IgorPanel2,
    error = IgorDanger,
)

@Composable
fun IgorTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = IgorColors, content = content)
}
