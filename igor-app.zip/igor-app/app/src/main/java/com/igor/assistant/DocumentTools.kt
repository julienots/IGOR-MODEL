package com.igor.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Xml
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode
import org.jsoup.select.NodeTraversor
import org.jsoup.select.NodeVisitor
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.ln

/** Un fichier lu par IGOR : son texte complet (déjà extrait) et quelques métadonnées. */
data class LoadedDocument(
    val name: String,
    val kind: String,
    val text: String,
    val note: String? = null
)

/**
 * Lecture de fichiers envoyés à IGOR. Tout se passe sur le téléphone :
 * - texte, code, CSV, JSON, Markdown… : lus directement (UTF-8 ou Windows-1252) ;
 * - HTML : texte visible extrait avec Jsoup ;
 * - PDF : texte extrait avec PdfBox-Android, page par page ; si le PDF est un scan
 *   (aucune couche texte), les premières pages sont rendues en image puis lues par OCR ;
 * - Word (.docx), Excel (.xlsx), PowerPoint (.pptx) : ces formats sont des archives ZIP
 *   de fichiers XML, lus avec un simple parseur XML (aucune bibliothèque Office) ;
 * - images (photo d'un document, capture d'écran…) : texte reconnu par OCR (ML Kit).
 *   IGOR ne « voit » pas l'image, il lit le texte qu'elle contient.
 */
object DocumentReader {

    const val MAX_FILE_BYTES = 30L * 1024 * 1024
    const val MAX_TEXT_CHARS = 300_000
    private const val MAX_ENTRY_BYTES = 60L * 1024 * 1024
    private const val MAX_PDF_PAGES = 300
    private const val MAX_OCR_PDF_PAGES = 6
    private const val MAX_SHEET_ROWS = 1500
    private const val MAX_SHEET_COLS = 60

    private val imageExtensions = setOf("png", "jpg", "jpeg", "webp", "bmp", "gif", "heic")
    private val legacyOffice = mapOf("doc" to "docx", "xls" to "xlsx", "ppt" to "pptx")

    fun displayName(context: Context, uri: Uri): String {
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) {
                        val n = c.getString(idx)
                        if (!n.isNullOrBlank()) return n
                    }
                }
            }
        } catch (_: Exception) {
            // on retombe sur le nom déduit de l'URI
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "fichier"
    }

    suspend fun read(context: Context, uri: Uri): LoadedDocument = withContext(Dispatchers.IO) {
        val name = displayName(context, uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = context.contentResolver.getType(uri).orEmpty()

        when {
            ext == "pdf" || mime == "application/pdf" -> readPdf(context, uri, name)
            ext in imageExtensions || mime.startsWith("image/") -> readImage(context, uri, name)
            ext in legacyOffice -> throw IllegalStateException(
                "L'ancien format .$ext n'est pas lu : réenregistre le fichier en .${legacyOffice[ext]} (ou en PDF)."
            )
            else -> {
                val bytes = readBytesLimited(context, uri)
                when (ext) {
                    "docx" -> finish(name, "Document Word", readDocx(bytes))
                    "xlsx", "xlsm" -> finish(name, "Classeur Excel", readXlsx(bytes))
                    "pptx" -> finish(name, "Présentation PowerPoint", readPptx(bytes))
                    "html", "htm", "xhtml" -> finish(name, "Page web", htmlToText(decodeText(bytes)))
                    else -> {
                        if (looksBinary(bytes)) {
                            throw IllegalStateException(
                                "Format non pris en charge. IGOR lit : texte, code, CSV, JSON, HTML, PDF, Word (.docx), Excel (.xlsx), PowerPoint (.pptx) et images."
                            )
                        }
                        finish(name, kindOfText(ext), decodeText(bytes))
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Utilitaires communs
    // ------------------------------------------------------------------

    private fun kindOfText(ext: String): String = when (ext) {
        "", "txt", "log" -> "Texte"
        "csv", "tsv" -> "Tableau (CSV)"
        "json" -> "JSON"
        "md", "markdown" -> "Markdown"
        else -> "Fichier .$ext"
    }

    private fun readBytesLimited(context: Context, uri: Uri): ByteArray {
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Impossible d'ouvrir le fichier.")
        return input.use { s ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(64 * 1024)
            var total = 0L
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                total += n
                if (total > MAX_FILE_BYTES) {
                    throw IllegalStateException("Fichier trop volumineux (maximum 30 Mo).")
                }
                out.write(buf, 0, n)
            }
            out.toByteArray()
        }
    }

    private fun hasUtf16Bom(bytes: ByteArray): Boolean {
        if (bytes.size < 2) return false
        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        return (b0 == 0xFF && b1 == 0xFE) || (b0 == 0xFE && b1 == 0xFF)
    }

    private fun looksBinary(bytes: ByteArray): Boolean {
        if (hasUtf16Bom(bytes)) return false
        val n = minOf(bytes.size, 4096)
        for (i in 0 until n) {
            if (bytes[i].toInt() == 0) return true
        }
        return false
    }

    private fun decodeText(bytes: ByteArray): String {
        if (hasUtf16Bom(bytes)) {
            val le = (bytes[0].toInt() and 0xFF) == 0xFF
            return String(bytes, 2, bytes.size - 2, if (le) Charsets.UTF_16LE else Charsets.UTF_16BE)
        }
        val utf8 = String(bytes, Charsets.UTF_8)
        val bad = utf8.count { it == '\uFFFD' }
        val text = if (bad > 0 && bad * 200 > utf8.length) String(bytes, charset("windows-1252")) else utf8
        return text.removePrefix("\uFEFF")
    }

    /** Nettoie le texte, le tronque si besoin et refuse les fichiers sans aucun texte. */
    private fun finish(name: String, kind: String, raw: String, note: String? = null): LoadedDocument {
        val cleaned = raw
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .replace(Regex("[ \\t]+\n"), "\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
        if (cleaned.isBlank()) throw IllegalStateException("Aucun texte lisible trouvé dans ce fichier.")
        return if (cleaned.length > MAX_TEXT_CHARS) {
            val warn = "Fichier très long : seuls les $MAX_TEXT_CHARS premiers caractères sont pris en compte."
            LoadedDocument(name, kind, cleaned.take(MAX_TEXT_CHARS), listOfNotNull(note, warn).joinToString(" "))
        } else {
            LoadedDocument(name, kind, cleaned, note)
        }
    }

    private fun readZip(bytes: ByteArray, wanted: (String) -> Boolean): Map<String, ByteArray> {
        val result = LinkedHashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && wanted(entry.name)) {
                    // Garde-fou : une archive piégée peut se décompresser en des gigaoctets.
                    val out = ByteArrayOutputStream()
                    val buf = ByteArray(32 * 1024)
                    var size = 0L
                    while (true) {
                        val n = zip.read(buf)
                        if (n < 0) break
                        size += n
                        if (size > MAX_ENTRY_BYTES) {
                            throw IllegalStateException("Fichier invalide ou trop volumineux une fois décompressé.")
                        }
                        out.write(buf, 0, n)
                    }
                    result[entry.name] = out.toByteArray()
                }
                entry = zip.nextEntry
            }
        }
        return result
    }

    // ------------------------------------------------------------------
    // HTML
    // ------------------------------------------------------------------

    private fun htmlToText(html: String): String {
        val doc = Jsoup.parse(html)
        doc.select("script, style, noscript, svg, head").remove()
        val sb = StringBuilder()
        NodeTraversor.traverse(object : NodeVisitor {
            override fun head(node: Node, depth: Int) {
                if (node is TextNode) {
                    val t = node.text().trim()
                    if (t.isNotEmpty()) sb.append(t).append(' ')
                } else if (node is Element && node.tagName() == "br") {
                    sb.append('\n')
                }
            }

            override fun tail(node: Node, depth: Int) {
                if (node is Element && (node.isBlock || node.tagName() == "tr")) sb.append('\n')
            }
        }, doc)
        return sb.toString()
    }

    // ------------------------------------------------------------------
    // Word (.docx)
    // ------------------------------------------------------------------

    private fun readDocx(bytes: ByteArray): String {
        val parts = readZip(bytes) { it == "word/document.xml" }
        val main = parts["word/document.xml"] ?: throw IllegalStateException("Fichier Word invalide.")
        return extractWordXml(main)
    }

    private fun extractWordXml(xml: ByteArray): String {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(xml), null)
        val sb = StringBuilder()
        var inText = false
        var prefix = ""
        var prefixPending = false
        var tableDepth = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "w:p" -> { prefix = ""; prefixPending = false }
                    "w:pStyle" -> {
                        val style = p.getAttributeValue(null, "w:val") ?: ""
                        val lower = style.lowercase()
                        if (lower.startsWith("heading") || lower.startsWith("titre")) {
                            val level = style.filter { it.isDigit() }.toIntOrNull() ?: 1
                            prefix = "#".repeat(level.coerceIn(1, 4)) + " "
                            prefixPending = true
                        } else if (lower == "title") {
                            prefix = "# "
                            prefixPending = true
                        }
                    }
                    "w:t" -> inText = true
                    "w:tbl" -> tableDepth++
                    "w:tab" -> sb.append('\t')
                    "w:br", "w:cr" -> sb.append('\n')
                }
                XmlPullParser.TEXT -> if (inText) {
                    if (prefixPending) {
                        sb.append(prefix)
                        prefixPending = false
                    }
                    sb.append(p.text)
                }
                XmlPullParser.END_TAG -> when (p.name) {
                    "w:t" -> inText = false
                    "w:tbl" -> if (tableDepth > 0) tableDepth--
                    // Dans un tableau, un paragraphe de cellule ne saute pas de ligne.
                    "w:p" -> sb.append(if (tableDepth > 0) ' ' else '\n')
                    "w:tc" -> sb.append(" | ")
                    "w:tr" -> sb.append('\n')
                }
            }
            ev = p.next()
        }
        return sb.toString().replace(Regex(" +\\| *\n"), "\n").replace(Regex("[ ]{2,}"), " ")
    }

    // ------------------------------------------------------------------
    // PowerPoint (.pptx)
    // ------------------------------------------------------------------

    private fun readPptx(bytes: ByteArray): String {
        val parts = readZip(bytes) { it.startsWith("ppt/slides/slide") && it.endsWith(".xml") }
        val numberRegex = Regex("(\\d+)")
        val ordered = parts.entries.sortedBy {
            numberRegex.find(it.key.substringAfterLast('/'))?.value?.toIntOrNull() ?: 0
        }
        val sb = StringBuilder()
        ordered.forEachIndexed { i, e ->
            val t = extractDrawingXml(e.value).trim()
            if (t.isNotEmpty()) sb.append("## Diapositive ").append(i + 1).append('\n').append(t).append("\n\n")
        }
        return sb.toString()
    }

    private fun extractDrawingXml(xml: ByteArray): String {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(xml), null)
        val sb = StringBuilder()
        var inText = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "a:t" -> inText = true
                    "a:br" -> sb.append('\n')
                }
                XmlPullParser.TEXT -> if (inText) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "a:t" -> inText = false
                    "a:p" -> sb.append('\n')
                }
            }
            ev = p.next()
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------
    // Excel (.xlsx)
    // ------------------------------------------------------------------

    private fun readXlsx(bytes: ByteArray): String {
        val parts = readZip(bytes) {
            it == "xl/sharedStrings.xml" || it == "xl/workbook.xml" || it == "xl/_rels/workbook.xml.rels" ||
                (it.startsWith("xl/worksheets/") && it.endsWith(".xml"))
        }
        val shared = parts["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val sheetList = parts["xl/workbook.xml"]?.let { parseSheetNames(it) } ?: emptyList()
        val rels = parts["xl/_rels/workbook.xml.rels"]?.let { parseRelationships(it) } ?: emptyMap()

        val sheets = ArrayList<Pair<String, String>>() // (chemin dans le zip, nom affiché)
        for ((sheetName, rid) in sheetList) {
            val target = rels[rid] ?: continue
            val clean = target.removePrefix("/")
            sheets.add((if (clean.startsWith("xl/")) clean else "xl/$clean") to sheetName)
        }
        if (sheets.isEmpty()) {
            parts.keys.filter { it.startsWith("xl/worksheets/") }.sorted().forEachIndexed { i, path ->
                sheets.add(path to "Feuille ${i + 1}")
            }
        }

        val sb = StringBuilder()
        for ((path, sheetName) in sheets) {
            val data = parts[path] ?: continue
            val content = parseSheet(data, shared)
            if (content.isNotBlank()) sb.append("## Feuille : ").append(sheetName).append('\n').append(content).append('\n')
        }
        return sb.toString()
    }

    private fun parseSharedStrings(xml: ByteArray): List<String> {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(xml), null)
        val list = ArrayList<String>()
        val cur = StringBuilder()
        var inT = false
        var inPhonetic = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "si" -> cur.setLength(0)
                    "t" -> inT = true
                    "rPh" -> inPhonetic = true
                }
                XmlPullParser.TEXT -> if (inT && !inPhonetic) cur.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "t" -> inT = false
                    "rPh" -> inPhonetic = false
                    "si" -> list.add(cur.toString())
                }
            }
            ev = p.next()
        }
        return list
    }

    private fun parseSheetNames(xml: ByteArray): List<Pair<String, String>> {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(xml), null)
        val out = ArrayList<Pair<String, String>>()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && p.name == "sheet") {
                val n = p.getAttributeValue(null, "name")
                val rid = p.getAttributeValue(null, "r:id")
                if (n != null && rid != null) out.add(n to rid)
            }
            ev = p.next()
        }
        return out
    }

    private fun parseRelationships(xml: ByteArray): Map<String, String> {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(xml), null)
        val out = HashMap<String, String>()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                val id = p.getAttributeValue(null, "Id")
                val target = p.getAttributeValue(null, "Target")
                if (id != null && target != null) out[id] = target
            }
            ev = p.next()
        }
        return out
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) {
            if (ch.isLetter()) n = n * 26 + (ch.uppercaseChar() - 'A' + 1) else break
        }
        return n - 1
    }

    private fun parseSheet(xml: ByteArray, shared: List<String>): String {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(xml), null)
        val out = StringBuilder()
        val row = HashMap<Int, String>()
        var cellCol = 0
        var cellType = ""
        val value = StringBuilder()
        var inV = false
        var inIs = false
        var inT = false
        var rows = 0
        var ev = p.eventType
        loop@ while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> row.clear()
                    "c" -> {
                        cellCol = colIndex(p.getAttributeValue(null, "r") ?: "A1")
                        cellType = p.getAttributeValue(null, "t") ?: ""
                        value.setLength(0)
                    }
                    "v" -> inV = true
                    "is" -> inIs = true
                    "t" -> if (inIs) inT = true
                }
                XmlPullParser.TEXT -> if (inV || inT) value.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "is" -> inIs = false
                    "c" -> {
                        val raw = value.toString()
                        val cell = when (cellType) {
                            "s" -> raw.trim().toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                            "b" -> if (raw.trim() == "1") "VRAI" else "FAUX"
                            else -> raw
                        }
                        if (cell.isNotBlank() && cellCol in 0 until MAX_SHEET_COLS) row[cellCol] = cell.trim()
                    }
                    "row" -> {
                        if (row.isNotEmpty()) {
                            val last = row.keys.maxOrNull() ?: 0
                            out.append((0..last).joinToString(" | ") { row[it] ?: "" }).append('\n')
                            rows++
                            if (rows >= MAX_SHEET_ROWS) {
                                out.append("… (feuille tronquée)\n")
                                break@loop
                            }
                        }
                    }
                }
            }
            ev = p.next()
        }
        return out.toString()
    }

    // ------------------------------------------------------------------
    // PDF (couche texte, sinon OCR sur les premières pages)
    // ------------------------------------------------------------------

    private suspend fun readPdf(context: Context, uri: Uri, name: String): LoadedDocument {
        var extracted = ""
        var pageCount = 0
        try {
            PDFBoxResourceLoader.init(context.applicationContext)
            val stream = context.contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Impossible d'ouvrir le fichier.")
            stream.use { s ->
                PDDocument.load(s).use { pdf ->
                    pageCount = pdf.numberOfPages
                    val stripper = PDFTextStripper()
                    stripper.setSortByPosition(true)
                    val sb = StringBuilder()
                    val last = minOf(pageCount, MAX_PDF_PAGES)
                    for (i in 1..last) {
                        stripper.setStartPage(i)
                        stripper.setEndPage(i)
                        val t = stripper.getText(pdf).trim()
                        if (t.isNotEmpty()) sb.append("[Page ").append(i).append("]\n").append(t).append("\n\n")
                        if (sb.length > MAX_TEXT_CHARS) break
                    }
                    extracted = sb.toString()
                }
            }
        } catch (e: Exception) {
            throw IllegalStateException("PDF illisible ou protégé par un mot de passe.")
        }

        val textOnly = extracted.replace(Regex("\\[Page \\d+]\\s*"), "").trim()
        val kind = "PDF ($pageCount pages)"
        if (textOnly.length >= 40) {
            val note = if (pageCount > MAX_PDF_PAGES) "Seules les $MAX_PDF_PAGES premières pages sont lues." else null
            return finish(name, kind, extracted, note)
        }

        // Aucune couche texte : c'est probablement un scan -> OCR sur les premières pages.
        val ocrText = try {
            ocrPdf(context, uri)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ""
        }
        if (ocrText.isBlank()) {
            throw IllegalStateException("Aucun texte trouvé dans ce PDF (scan illisible ?).")
        }
        val pagesRead = minOf(pageCount, MAX_OCR_PDF_PAGES)
        return finish(
            name, "PDF scanné ($pageCount pages)", ocrText,
            "PDF scanné : texte reconnu par OCR sur les $pagesRead premières pages seulement."
        )
    }

    private suspend fun ocrPdf(context: Context, uri: Uri): String {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return ""
        val sb = StringBuilder()
        pfd.use { fd ->
            PdfRenderer(fd).use { renderer ->
                val count = minOf(renderer.pageCount, MAX_OCR_PDF_PAGES)
                for (i in 0 until count) {
                    renderer.openPage(i).use { page ->
                        val scale = 1600f / page.width.coerceAtLeast(1)
                        val w = (page.width * scale).toInt().coerceAtLeast(1)
                        val h = (page.height * scale).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val t = ocr(InputImage.fromBitmap(bmp, 0)).trim()
                        bmp.recycle()
                        if (t.isNotEmpty()) sb.append("[Page ").append(i + 1).append("]\n").append(t).append("\n\n")
                    }
                }
            }
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------
    // Images (OCR)
    // ------------------------------------------------------------------

    private suspend fun readImage(context: Context, uri: Uri, name: String): LoadedDocument {
        val text = ocr(InputImage.fromFilePath(context, uri))
        if (text.isBlank()) {
            throw IllegalStateException(
                "Aucun texte reconnu dans cette image (IGOR lit le texte des images, il ne « voit » pas encore les photos)."
            )
        }
        return finish(name, "Image (texte reconnu par OCR)", text)
    }

    private suspend fun ocr(image: InputImage): String = suspendCancellableCoroutine { cont ->
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                recognizer.close()
                if (cont.isActive) cont.resume(result.text)
            }
            .addOnFailureListener { e ->
                recognizer.close()
                if (cont.isActive) cont.resumeWithException(e)
            }
    }
}

// ----------------------------------------------------------------------
// Sélection des passages utiles (sans embeddings : mots-clés pondérés)
// ----------------------------------------------------------------------

private class Cand(val doc: Int, val idx: Int, val text: String, val label: String, var score: Double = 0.0)

/**
 * Un petit modèle embarqué ne peut lire qu'une poignée de milliers de caractères à la
 * fois. Ce composant choisit donc, pour chaque question, les passages des documents
 * ouverts qui la concernent le plus (pondération type TF-IDF), ou prépare un plan de
 * lecture « par parties » pour les demandes globales (résume, de quoi ça parle…).
 */
object DocumentContext {

    /** Nombre maximal de caractères de documents injectés dans un message. */
    const val CONTEXT_BUDGET = 3600
    private const val CHUNK_SIZE = 900
    private const val MAP_WINDOW = 2800
    private const val MAP_MAX_WINDOWS = 6

    data class Piece(val docName: String, val label: String, val text: String)

    private val globalIntent = Regex(
        "(r[ée]sum|synth[èe]se|de quoi (?:[çc]a |cela )?parle|th[èe]me|points? (?:cl[ée]s?|importants?|principaux)|" +
            "l'essentiel|en bref|vue d'ensemble|explique[- ]moi (?:ce|le|ces|les)|analyse (?:ce|le|ces|les)|" +
            "que contient|contenu (?:du|de ce)|tl;?dr|lis (?:ce|le|ces|les))",
        RegexOption.IGNORE_CASE
    )

    fun isGlobalRequest(question: String): Boolean = globalIntent.containsMatchIn(question)

    /** Découpe [text] en morceaux d'environ [size] caractères, en respectant autant que possible les paragraphes. */
    fun chunks(text: String, size: Int): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (para in text.split("\n")) {
            var p = para
            while (p.length > size) {
                val space = p.lastIndexOf(' ', size)
                val cut = if (space < size / 2) size else space
                if (cur.isNotEmpty()) {
                    out.add(cur.toString().trim())
                    cur.setLength(0)
                }
                out.add(p.substring(0, cut).trim())
                p = p.substring(cut).trim()
            }
            if (cur.isNotEmpty() && cur.length + p.length + 1 > size) {
                out.add(cur.toString().trim())
                cur.setLength(0)
            }
            cur.append(p).append('\n')
        }
        if (cur.isNotBlank()) out.add(cur.toString().trim())
        return out.filter { it.isNotBlank() }
    }

    private val pageMarker = Regex("\\[Page (\\d+)]")

    /**
     * Retourne le bloc de texte à injecter dans le message : tous les documents s'ils
     * tiennent dans le budget, sinon les extraits les plus pertinents pour [question].
     */
    fun select(docs: List<LoadedDocument>, question: String, budget: Int = CONTEXT_BUDGET): String {
        if (docs.isEmpty()) return ""
        val total = docs.sumOf { it.text.length }
        if (total <= budget) {
            val all = StringBuilder()
            docs.forEach { d -> all.append("Document «").append(d.name).append("» (").append(d.kind).append(") :\n").append(d.text).append("\n\n") }
            return all.toString().trim()
        }

        val cands = ArrayList<Cand>()
        docs.forEachIndexed { di, d ->
            val parts = chunks(d.text, CHUNK_SIZE)
            var page: Int? = null
            parts.forEachIndexed { ci, t ->
                pageMarker.findAll(t).lastOrNull()?.let { page = it.groupValues[1].toIntOrNull() }
                val label = page?.let { "page $it" } ?: "extrait ${ci + 1}/${parts.size}"
                cands.add(Cand(di, ci, t, label))
            }
        }

        val qTokens = Lexicon.keywords(question).distinct()
        if (qTokens.isNotEmpty()) {
            val bags = cands.map { Lexicon.keywords(it.text) }
            val df = HashMap<String, Int>()
            for (bag in bags) for (t in bag.toSet()) df[t] = (df[t] ?: 0) + 1
            val n = cands.size.toDouble()
            cands.forEachIndexed { i, c ->
                val tf = bags[i].groupingBy { it }.eachCount()
                var s = 0.0
                for (q in qTokens) {
                    val f = tf[q] ?: continue
                    s += (1 + ln(f.toDouble())) * ln(1 + n / (1 + (df[q] ?: 0)))
                }
                c.score = s
            }
        }

        val chosen = ArrayList<Cand>()
        var used = 0
        for (c in cands.filter { it.score > 0 }.sortedByDescending { it.score }) {
            if (used + c.text.length > budget) continue
            chosen.add(c)
            used += c.text.length
        }
        if (chosen.isEmpty()) {
            // Question générique : quelques passages répartis sur tout le document.
            val k = (budget / CHUNK_SIZE).coerceAtLeast(1)
            val step = (cands.size.toDouble() / k).coerceAtLeast(1.0)
            var pos = 0.0
            while (pos < cands.size && chosen.size < k) {
                val c = cands[pos.toInt()]
                if (used + c.text.length <= budget) {
                    chosen.add(c)
                    used += c.text.length
                }
                pos += step
            }
        } else {
            // Ajoute le début de chaque document (titre, introduction) s'il reste de la place.
            for (c in cands.filter { it.idx == 0 }) {
                if (chosen.contains(c) || used + c.text.length > budget) continue
                chosen.add(c)
                used += c.text.length
            }
        }

        val byDoc = chosen.sortedWith(compareBy<Cand>({ it.doc }, { it.idx })).groupBy { it.doc }
        val out = StringBuilder()
        for ((di, list) in byDoc) {
            val d = docs[di]
            out.append("Document «").append(d.name).append("» (").append(d.kind).append(", ")
                .append(d.text.length).append(" caractères — extraits les plus pertinents) :\n")
            list.forEach { c -> out.append('[').append(c.label).append("] ").append(c.text).append("\n\n") }
        }
        return out.toString().trim()
    }

    /** Plan de lecture « par parties » pour une demande globale : au plus [MAP_MAX_WINDOWS] passages répartis. */
    fun mapPlan(docs: List<LoadedDocument>): List<Piece> {
        val perDoc = (MAP_MAX_WINDOWS / docs.size.coerceAtLeast(1)).coerceAtLeast(1)
        val plan = ArrayList<Piece>()
        for (d in docs) {
            val parts = chunks(d.text, MAP_WINDOW)
            val picked = if (parts.size <= perDoc) {
                parts.indices.toList()
            } else {
                val step = parts.size.toDouble() / perDoc
                (0 until perDoc).map { (it * step).toInt() }
            }
            for (i in picked) {
                plan.add(Piece(d.name, "partie ${i + 1}/${parts.size} de «${d.name}»", parts[i]))
            }
        }
        return plan
    }
}
