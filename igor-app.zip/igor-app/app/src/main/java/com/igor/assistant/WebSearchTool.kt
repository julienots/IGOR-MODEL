package com.igor.assistant

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.util.concurrent.TimeUnit

/**
 * Recherche web réelle, utilisée quand l'utilisateur active l'interrupteur "recherche
 * web" du chat, ou pose une question qui semble manifestement factuelle / d'actualité
 * (voir [ChatViewModel.looksTimely]).
 *
 * Version 3 : au lieu de dépendre d'un seul moteur de recherche généraliste (fragile,
 * bloque parfois le scraping, remplit ses pages de publicité), IGOR essaie maintenant
 * plusieurs sources dans un ordre pensé pour maximiser les chances d'obtenir une vraie
 * réponse exploitable :
 *
 * 1. **Météo** : question météo détectée -> appel direct à l'API Open-Meteo (gratuite,
 *    sans clé, données officielles), au lieu d'espérer qu'un résultat de recherche
 *    contienne la bonne info.
 * 2. **Wikipédia** : question de type "qui est / qu'est-ce que" -> API officielle de
 *    Wikipédia (stable, pas de scraping HTML fragile), un résumé fiable et sourcé.
 * 3. **Recherche généraliste** : sinon, ou si les deux étapes précédentes échouent,
 *    on interroge successivement DuckDuckGo (html puis lite) puis Bing en secours, et
 *    on va lire le contenu réel des meilleures pages trouvées (pas seulement le court
 *    extrait renvoyé par le moteur) pour donner au modèle de vraies informations à
 *    citer.
 *
 * En cas d'échec total (pas de réseau, tous les services indisponibles, aucun résultat
 * exploitable), la fonction retourne un [Outcome] vide accompagné d'une raison
 * explicite : IGOR sait alors qu'il doit le dire honnêtement à l'utilisateur plutôt que
 * prétendre avoir trouvé une réponse (voir la construction du prompt caché dans
 * [ChatViewModel] et les instructions dans [LlmEngineManager]).
 */
object WebSearchTool {

    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    private const val userAgent =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128 Mobile Safari/537.36"

    data class Result(val title: String, val url: String, val snippet: String, val excerpt: String = "")
    data class Outcome(val results: List<Result>, val failureReason: String? = null)

    /**
     * Lance une recherche complète pour [query] : essaie d'abord les sources ciblées
     * (météo, Wikipédia) les plus fiables pour ce type de question, puis une recherche
     * généraliste multi-moteurs enrichie avec le vrai contenu des pages. Ne lève jamais
     * d'exception ; retourne toujours un [Outcome], vide et documenté en cas de
     * problème.
     */
    fun search(query: String, maxResults: Int = 5, maxPagesToFetch: Int = 4): Outcome {
        weatherLocation(query)?.let { location ->
            val weather = try {
                fetchWeather(location)
            } catch (_: Exception) {
                null
            }
            if (weather != null) return Outcome(listOf(weather))
            // Pas de ville reconnue ou service météo indisponible : on continue avec
            // la recherche généraliste plutôt que d'abandonner tout de suite.
        }

        if (looksLikeDefinitionQuestion(query)) {
            val wiki = try {
                fetchWikipediaSummary(query)
            } catch (_: Exception) {
                null
            }
            if (wiki != null) return Outcome(listOf(wiki))
        }

        val rawResults = try {
            fetchFromHtmlEndpoint(query, maxResults)
                .ifEmpty { fetchFromLiteEndpoint(query, maxResults) }
                .ifEmpty { fetchFromBing(query, maxResults) }
        } catch (e: Exception) {
            return Outcome(emptyList(), "erreur réseau (${e.message ?: e::class.simpleName})")
        }

        if (rawResults.isEmpty()) {
            return Outcome(emptyList(), "aucun résultat renvoyé par les moteurs de recherche")
        }

        // On enrichit les meilleurs résultats avec le vrai contenu de la page : le
        // snippet seul (une phrase tronquée) suffit rarement à répondre correctement.
        val enriched = rawResults.mapIndexed { index, r ->
            if (index < maxPagesToFetch) {
                val excerpt = try {
                    fetchPageExcerpt(r.url)
                } catch (_: Exception) {
                    ""
                }
                r.copy(excerpt = excerpt)
            } else r
        }

        return Outcome(enriched)
    }

    // ---------------------------------------------------------------------
    // 1. Météo (Open-Meteo — géocodage + prévisions, sans clé API)
    // ---------------------------------------------------------------------

    private val weatherPattern = Regex(
        "m[ée]t[ée]o\\s+(?:(?:actuelle|du\\s+jour)\\s+)?(?:à|a|de|pour|sur|dans)?\\s*([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ' \\-]{1,40})",
        RegexOption.IGNORE_CASE
    )

    /** Extrait un nom de ville d'une question météo, si possible. */
    private fun weatherLocation(query: String): String? {
        if (!Regex("m[ée]t[ée]o", RegexOption.IGNORE_CASE).containsMatchIn(query)) return null
        val match = weatherPattern.find(query) ?: return null
        var location = match.groupValues[1].trim()
        // On coupe au premier mot qui ressemble à autre chose qu'un nom de lieu
        // ("météo à Lyon demain" -> "Lyon").
        location = location.split(Regex("\\s+(demain|aujourd'hui|ce\\s+matin|ce\\s+soir|cette\\s+semaine)\\b", RegexOption.IGNORE_CASE)).first()
        location = location.trim(' ', '?', '.', ',')
        return location.ifBlank { null }
    }

    private val weatherCodeLabels = mapOf(
        0 to "ciel dégagé", 1 to "plutôt dégagé", 2 to "partiellement nuageux", 3 to "couvert",
        45 to "brouillard", 48 to "brouillard givrant",
        51 to "bruine légère", 53 to "bruine modérée", 55 to "bruine dense",
        56 to "bruine verglaçante", 57 to "bruine verglaçante dense",
        61 to "pluie légère", 63 to "pluie modérée", 65 to "pluie forte",
        66 to "pluie verglaçante", 67 to "pluie verglaçante forte",
        71 to "neige légère", 73 to "neige modérée", 75 to "neige forte", 77 to "grains de neige",
        80 to "averses légères", 81 to "averses modérées", 82 to "averses violentes",
        85 to "averses de neige légères", 86 to "averses de neige fortes",
        95 to "orage", 96 to "orage avec grêle légère", 99 to "orage avec grêle forte"
    )

    private fun fetchWeather(location: String): Result? {
        val geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            java.net.URLEncoder.encode(location, "UTF-8") + "&count=1&language=fr&format=json"
        val geoJson = fetchJson(geoUrl) ?: return null
        val results = geoJson.optJSONArray("results") ?: return null
        if (results.length() == 0) return null
        val place = results.getJSONObject(0)
        val lat = place.getDouble("latitude")
        val lon = place.getDouble("longitude")
        val placeName = place.optString("name", location)
        val country = place.optString("country", "")

        val forecastUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m" +
            "&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1"
        val forecastJson = fetchJson(forecastUrl) ?: return null
        val current = forecastJson.optJSONObject("current") ?: return null
        val daily = forecastJson.optJSONObject("daily")

        val temp = current.optDouble("temperature_2m", Double.NaN)
        val feelsLike = current.optDouble("apparent_temperature", Double.NaN)
        val wind = current.optDouble("wind_speed_10m", Double.NaN)
        val humidity = current.optDouble("relative_humidity_2m", Double.NaN)
        val code = current.optInt("weather_code", -1)
        val label = weatherCodeLabels[code] ?: "conditions non précisées"

        val tMax = daily?.optJSONArray("temperature_2m_max")?.optDouble(0)
        val tMin = daily?.optJSONArray("temperature_2m_min")?.optDouble(0)

        val text = buildString {
            append("Météo actuelle à $placeName")
            if (country.isNotBlank()) append(" ($country)")
            append(" : $label, ${trim1(temp)}°C")
            if (!feelsLike.isNaN()) append(" (ressenti ${trim1(feelsLike)}°C)")
            if (tMin != null && tMax != null) append(", min/max du jour ${trim1(tMin)}°C / ${trim1(tMax)}°C")
            if (!wind.isNaN()) append(", vent ${trim1(wind)} km/h")
            if (!humidity.isNaN()) append(", humidité ${trim1(humidity)}%")
            append(".")
        }
        return Result(
            title = "Météo — $placeName",
            url = "https://open-meteo.com",
            snippet = text,
            excerpt = text
        )
    }

    private fun trim1(v: Double): String = if (v.isNaN()) "?" else "%.1f".format(v).trimEnd('0').trimEnd('.')

    // ---------------------------------------------------------------------
    // 2. Wikipédia (résumé officiel via l'API REST, pas de scraping)
    // ---------------------------------------------------------------------

    private val definitionPattern = Regex(
        "^(qui\\s+(est|était|sont)|qu'est[- ]ce\\s+que|c'est\\s+quoi|d[ée]finition\\s+de|" +
            "qu'est[- ]ce\\s+qu'|explique(?:[- ]moi)?\\s+(ce\\s+qu'est|qui\\s+est))\\b",
        RegexOption.IGNORE_CASE
    )

    private fun looksLikeDefinitionQuestion(query: String): Boolean =
        definitionPattern.containsMatchIn(query.trim())

    /** Retire le préfixe de question ("qui est", "c'est quoi"...) pour ne garder que le sujet recherché. */
    private fun extractSubject(query: String): String {
        var s = query.trim()
        s = definitionPattern.replace(s, "")
        s = s.trimStart(' ', '\'')
        s = s.trimEnd('?', ' ', '.')
        return s
    }

    private fun fetchWikipediaSummary(query: String): Result? {
        val subject = extractSubject(query)
        if (subject.isBlank()) return null

        val searchUrl = "https://fr.wikipedia.org/w/api.php?action=opensearch&search=" +
            java.net.URLEncoder.encode(subject, "UTF-8") + "&limit=1&namespace=0&format=json"
        val searchBody = fetchRaw(searchUrl) ?: return null
        val searchArray = JSONArray(searchBody)
        val titles = searchArray.optJSONArray(1) ?: return null
        if (titles.length() == 0) return null
        val title = titles.getString(0)

        val summaryUrl = "https://fr.wikipedia.org/api/rest_v1/page/summary/" +
            java.net.URLEncoder.encode(title, "UTF-8").replace("+", "%20")
        val summaryJson = fetchJson(summaryUrl) ?: return null
        val extract = summaryJson.optString("extract", "").trim()
        if (extract.isEmpty()) return null
        val pageUrl = summaryJson.optJSONObject("content_urls")
            ?.optJSONObject("desktop")
            ?.optString("page")
            ?.takeIf { it.isNotBlank() }
            ?: "https://fr.wikipedia.org/wiki/${title.replace(" ", "_")}"

        return Result(title = "Wikipédia — $title", url = pageUrl, snippet = extract, excerpt = extract)
    }

    // ---------------------------------------------------------------------
    // 3. Recherche généraliste multi-moteurs (DuckDuckGo html/lite, puis Bing)
    // ---------------------------------------------------------------------

    private fun fetchFromHtmlEndpoint(query: String, maxResults: Int): List<Result> {
        val url = "https://html.duckduckgo.com/html/?q=" + java.net.URLEncoder.encode(query, "UTF-8")
        val doc = fetchDocument(url) ?: return emptyList()
        if (looksBlocked(doc)) return emptyList()
        return doc.select("div.result").take(maxResults).mapNotNull { el ->
            val linkEl = el.select("a.result__a").firstOrNull() ?: return@mapNotNull null
            val title = linkEl.text().trim()
            val href = resolveDuckDuckGoRedirect(linkEl.attr("href"))
            val snippet = el.select("a.result__snippet, .result__snippet").firstOrNull()?.text()?.trim().orEmpty()
            if (title.isEmpty() && snippet.isEmpty()) null
            else Result(title, href, snippet)
        }
    }

    /** Point d'entrée "lite" : mise en page plus simple (table HTML), souvent plus tolérante au scraping. */
    private fun fetchFromLiteEndpoint(query: String, maxResults: Int): List<Result> {
        val url = "https://lite.duckduckgo.com/lite/?q=" + java.net.URLEncoder.encode(query, "UTF-8")
        val doc = fetchDocument(url) ?: return emptyList()
        if (looksBlocked(doc)) return emptyList()
        return doc.select("a.result-link").take(maxResults).mapNotNull { linkEl ->
            val title = linkEl.text().trim()
            if (title.isEmpty()) return@mapNotNull null
            val href = resolveDuckDuckGoRedirect(linkEl.attr("href"))
            val snippet = linkEl.parents().firstOrNull { it.tagName() == "tr" }
                ?.nextElementSibling()
                ?.select("td.result-snippet")
                ?.firstOrNull()
                ?.text()
                ?.trim()
                .orEmpty()
            Result(title, href, snippet)
        }
    }

    /** Repli final : Bing en HTML simple, structure différente de DuckDuckGo donc rarement bloqué en même temps. */
    private fun fetchFromBing(query: String, maxResults: Int): List<Result> {
        val url = "https://www.bing.com/search?q=" + java.net.URLEncoder.encode(query, "UTF-8") + "&setlang=fr&cc=FR"
        val doc = fetchDocument(url) ?: return emptyList()
        return doc.select("li.b_algo").take(maxResults).mapNotNull { el ->
            val linkEl = el.select("h2 a").firstOrNull() ?: return@mapNotNull null
            val title = linkEl.text().trim()
            val href = linkEl.attr("href")
            val snippet = el.select(".b_caption p, .b_lineclamp2, .b_lineclamp3, .b_lineclamp4")
                .firstOrNull()?.text()?.trim().orEmpty()
            if (title.isEmpty() || href.isBlank()) null else Result(title, href, snippet)
        }
    }

    /** Détecte une page de blocage / captcha plutôt qu'une vraie page de résultats. */
    private fun looksBlocked(doc: Document): Boolean {
        val text = doc.text().lowercase()
        return text.contains("unusual traffic") ||
            text.contains("détecté un trafic inhabituel") ||
            (text.contains("captcha") && text.length < 800)
    }

    private fun fetchDocument(url: String): Document? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .header("Accept-Language", "fr-FR,fr;q=0.9")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val html = response.body?.string() ?: return null
            return Jsoup.parse(html)
        }
    }

    private fun fetchRaw(url: String): String? {
        val request = Request.Builder().url(url).header("User-Agent", userAgent).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            return response.body?.string()
        }
    }

    private fun fetchJson(url: String): JSONObject? {
        val body = fetchRaw(url) ?: return null
        return try {
            JSONObject(body)
        } catch (_: Exception) {
            null
        }
    }

    /** DuckDuckGo renvoie des liens de redirection (`//duckduckgo.com/l/?uddg=...`) : on récupère la vraie URL. */
    private fun resolveDuckDuckGoRedirect(href: String): String {
        if (!href.contains("uddg=")) return if (href.startsWith("//")) "https:$href" else href
        val encoded = href.substringAfter("uddg=").substringBefore("&")
        return try {
            java.net.URLDecoder.decode(encoded, "UTF-8")
        } catch (_: Exception) {
            href
        }
    }

    /** Va lire une page trouvée et en extrait un passage de texte utile (hors menus, scripts, pubs). */
    private fun fetchPageExcerpt(url: String, maxChars: Int = 800): String {
        if (url.isBlank() || !url.startsWith("http")) return ""
        val request = Request.Builder().url(url).header("User-Agent", userAgent).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return ""
            val html = response.body?.string() ?: return ""
            val doc = Jsoup.parse(html)
            doc.select("script, style, nav, header, footer, noscript, aside, form").remove()
            val text = doc.body()?.text().orEmpty()
            return if (text.length > maxChars) text.take(maxChars).trimEnd() + "…" else text
        }
    }

    /** Formate les résultats pour les injecter dans le prompt caché envoyé au modèle. */
    fun formatForPrompt(results: List<Result>): String {
        if (results.isEmpty()) return ""
        return results.mapIndexed { i, r ->
            val body = r.excerpt.ifEmpty { r.snippet }
            "(${i + 1}) ${r.title} — $body [source : ${r.url}]"
        }.joinToString(" | ")
    }
}
