package com.igor.assistant

import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Un résultat de recherche web brut : titre, extrait, adresse.
 */
data class WebResult(val title: String, val snippet: String, val url: String)

/**
 * Recherche internet minimaliste pour IGOR.
 *
 * Il n'y a pas de clé d'API ici : on interroge directement la version "lite" de
 * DuckDuckGo (lite.duckduckgo.com), une page HTML très simple pensée pour les
 * lecteurs texte, et on en extrait les résultats avec des expressions régulières.
 * C'est volontairement simple et sans dépendance lourde (pas de moteur HTML
 * complet) — la contrepartie est que si DuckDuckGo change la structure de cette
 * page un jour, l'extraction ci-dessous peut casser et devra être ajustée aux
 * nouvelles balises. Si tu préfères une recherche plus robuste et illimitée,
 * remplace [search] par un appel à une API payante (Google Custom Search, Bing,
 * SerpApi…) avec une clé stockée côté appli.
 */
object WebSearch {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    /**
     * Lance la recherche et renvoie directement un texte prêt à être injecté dans
     * le prompt du modèle (voir la balise [RECHERCHE_WEB] dans ChatViewModel).
     * Ne lève jamais d'exception : en cas d'échec, décrit l'échec en français.
     */
    fun searchAndFormat(query: String, maxResults: Int = 4): String {
        val results = try {
            search(query, maxResults)
        } catch (e: Exception) {
            return "La recherche internet a échoué (${e.message ?: "erreur réseau"}). " +
                "Réponds honnêtement que tu n'as pas pu vérifier cette information en ligne, " +
                "sans inventer de résultat."
        }
        if (results.isEmpty()) {
            return "Aucun résultat trouvé pour cette recherche. " +
                "Dis-le clairement plutôt que d'inventer une réponse."
        }
        return results.joinToString("\n\n") { r ->
            "- ${r.title} : ${r.snippet} (source : ${r.url})"
        }
    }

    private fun search(query: String, maxResults: Int): List<WebResult> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val request = Request.Builder()
            .url("https://lite.duckduckgo.com/lite/?q=$encoded")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Igor) AppleWebKit/537.36")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return emptyList()
            val html = response.body?.string() ?: return emptyList()
            return parse(html).take(maxResults)
        }
    }

    // La page lite.duckduckgo.com/lite/ liste ses résultats sous forme de liens
    // <a class="result-link" href="...">Titre</a> suivis d'une cellule
    // <td class="result-snippet">Extrait</td>. On extrait les deux listes en
    // parallèle puis on les recombine par position.
    private fun parse(html: String): List<WebResult> {
        val linkRegex = Regex(
            """<a[^>]*class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>""",
            RegexOption.DOT_MATCHES_ALL
        )
        val snippetRegex = Regex(
            """<td[^>]*class="result-snippet"[^>]*>(.*?)</td>""",
            RegexOption.DOT_MATCHES_ALL
        )

        val links = linkRegex.findAll(html).map { it.groupValues[1] to stripTags(it.groupValues[2]) }.toList()
        val snippets = snippetRegex.findAll(html).map { stripTags(it.groupValues[1]) }.toList()

        return links.mapIndexed { i, (url, title) ->
            WebResult(title = title, snippet = snippets.getOrNull(i) ?: "", url = url)
        }.filter { it.title.isNotBlank() }
    }

    private fun stripTags(raw: String): String =
        raw.replace(Regex("<[^>]*>"), "")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .trim()
}
