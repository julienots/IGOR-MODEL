package com.igor.assistant

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.sp

/**
 * Rendu Markdown minimal pour les réponses d'IGOR : titres (#), listes à puces,
 * **gras**, *italique*, `code` et blocs de code. Pas de dépendance externe : on
 * construit simplement un AnnotatedString. Les balises encore incomplètes pendant
 * le streaming (un ** pas encore refermé) restent affichées telles quelles jusqu'à
 * leur fermeture.
 */
private val headingRegex = Regex("^(#{1,4})\\s+(.*)$")
private val bulletRegex = Regex("^(\\s*)([-*•])\\s+(.*)$")
private val inlineRegex = Regex("(\\*\\*[^*\\n]+\\*\\*|`[^`\\n]+`|\\*[^*\\s][^*\\n]*\\*)")
private val codeBackground = Color(0x33FFFFFF)

private fun AnnotatedString.Builder.appendInline(text: String) {
    var last = 0
    for (m in inlineRegex.findAll(text)) {
        if (m.range.first > last) append(text.substring(last, m.range.first))
        val tok = m.value
        when {
            tok.startsWith("**") ->
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(tok.substring(2, tok.length - 2)) }
            tok.startsWith("`") ->
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBackground)) {
                    append(tok.substring(1, tok.length - 1))
                }
            else ->
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(tok.substring(1, tok.length - 1)) }
        }
        last = m.range.last + 1
    }
    if (last < text.length) append(text.substring(last))
}

fun renderMarkdown(src: String): AnnotatedString = buildAnnotatedString {
    var inCode = false
    var first = true
    for (rawLine in src.split("\n")) {
        val line = rawLine.trimEnd()
        if (line.trimStart().startsWith("```")) {
            inCode = !inCode
            continue
        }
        if (!first) append('\n')
        first = false

        if (inCode) {
            withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBackground, fontSize = 13.sp)) {
                append(line.ifEmpty { " " })
            }
            continue
        }
        val heading = headingRegex.matchEntire(line)
        if (heading != null) {
            val size = when (heading.groupValues[1].length) {
                1 -> 19.sp
                2 -> 17.sp
                else -> 16.sp
            }
            withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = size)) {
                appendInline(heading.groupValues[2])
            }
            continue
        }
        val bullet = bulletRegex.matchEntire(line)
        if (bullet != null) {
            append(bullet.groupValues[1])
            append("• ")
            appendInline(bullet.groupValues[3])
            continue
        }
        appendInline(line)
    }
}
