package com.igor.assistant

import android.app.Application

class IgorApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashDiagnostics.markPhase(this, "APPLICATION_ONCREATE")
        CrashDiagnostics.installHandler(this)
        CrashDiagnostics.markPhase(this, "APPLICATION_READY")
    }
}
