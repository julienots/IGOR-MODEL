package com.igor.assistant

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CrashDiagnostics {
    private const val PREFS = "igor_diagnostics"
    private const val PHASE = "startup_phase"
    private const val LAST_REPORT = "last_report"
    private const val LAST_REPORT_TIME = "last_report_time"

    fun markPhase(context: Context, phase: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(PHASE, phase).apply()
    }

    fun installHandler(context: Context) {
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val phase = prefs.getString(PHASE, "phase inconnue") ?: "phase inconnue"
                val report = buildString {
                    appendLine("IGOR - RAPPORT DE CRASH")
                    appendLine("Date: ${now()}")
                    appendLine("Thread: ${thread.name}")
                    appendLine("Dernière étape: $phase")
                    appendLine("Type: exception Java/Kotlin")
                    appendLine()
                    appendLine(throwable.stackTraceToString())
                }
                File(appContext.filesDir, "igor_last_crash.txt").writeText(report)
                prefs.edit()
                    .putString(LAST_REPORT, report)
                    .putString(LAST_REPORT_TIME, now())
                    .apply()
            } catch (_: Throwable) {
                // Ne jamais empêcher le système de terminer le processus.
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    fun previousProcessReport(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val javaReport = prefs.getString(LAST_REPORT, null)
        if (!javaReport.isNullOrBlank()) return javaReport

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val exits = am.getHistoricalProcessExitReasons(context.packageName, 0, 8)
                val previous = exits.firstOrNull() ?: return null
                val reason = when (previous.reason) {
                    ApplicationExitInfo.REASON_CRASH -> "CRASH Java/Kotlin"
                    ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH NATIF (bibliothèque C/C++)"
                    ApplicationExitInfo.REASON_ANR -> "ANR (application bloquée)"
                    ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "Échec d'initialisation Android"
                    ApplicationExitInfo.REASON_LOW_MEMORY -> "Arrêt par manque de mémoire"
                    ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "Arrêt pour consommation excessive de ressources"
                    ApplicationExitInfo.REASON_SIGNALED -> "Processus terminé par un signal système"
                    else -> return null
                }
                return buildString {
                    appendLine("IGOR - DERNIER ARRÊT ANORMAL")
                    appendLine("Date: ${Date(previous.timestamp)}")
                    appendLine("Type détecté: $reason")
                    appendLine("Dernière étape connue: ${prefs.getString(PHASE, "inconnue")}")
                    if (previous.description != null) appendLine("Description système: ${previous.description}")
                    appendLine()
                    appendLine("Cela indique où chercher le problème. Si le type est CRASH NATIF, il faut regarder le Logcat/tombstone Android.")
                }
            } catch (_: Throwable) {
                // Diagnostic non disponible sur cet appareil.
            }
        }
        return null
    }

    fun clearPreviousReport(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(LAST_REPORT).remove(LAST_REPORT_TIME).apply()
    }

    fun readCrashFile(context: Context): String? {
        val file = File(context.filesDir, "igor_last_crash.txt")
        return if (file.exists()) file.readText() else null
    }

    private fun now(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
}
