package com.igor.assistant

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Role { USER, ASSISTANT }
data class ChatMessage(val role: Role, val text: String, val isCalc: Boolean = false)

enum class ModelState { ABSENT, LOADING, READY, ERROR }

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val engine = LlmEngineManager()
    private val modelFile: File get() = File(getApplication<Application>().filesDir, "igor-model.litertlm")

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _modelState = MutableStateFlow(ModelState.ABSENT)
    val modelState: StateFlow<ModelState> = _modelState.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    init {
        if (modelFile.exists()) loadModel()
    }

    /** Copie le fichier .litertlm choisi par l'utilisateur dans le stockage privé de l'appli, puis le charge. */
    fun importModel(uri: Uri) {
        _modelState.value = ModelState.LOADING
        _errorMessage.value = null
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                        modelFile.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalStateException("Impossible de lire le fichier sélectionné")
                }
                loadModel()
            } catch (e: Exception) {
                _modelState.value = ModelState.ERROR
                _errorMessage.value = "Import impossible : ${e.message ?: "erreur inconnue"}"
            }
        }
    }

    private fun loadModel() {
        _modelState.value = ModelState.LOADING
        viewModelScope.launch {
            try {
                withContext(Dispatchers.Default) { engine.initialize(modelFile) }
                _modelState.value = ModelState.READY
            } catch (e: Exception) {
                _modelState.value = ModelState.ERROR
                _errorMessage.value = "Chargement du modèle impossible : ${e.message ?: "erreur inconnue"}"
            }
        }
    }

    fun resetModel() {
        engine.close()
        if (modelFile.exists()) modelFile.delete()
        _modelState.value = ModelState.ABSENT
        _messages.value = emptyList()
    }

    fun newConversation() {
        _messages.value = emptyList()
    }

    fun send(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty() || _isThinking.value) return

        _messages.value = _messages.value + ChatMessage(Role.USER, text)

        val expr = Calculator.extractExpression(text)
        val hiddenPrompt: String
        val isCalc: Boolean
        if (expr != null) {
            try {
                val value = Calculator.evaluate(expr)
                val formatted = Calculator.format(value)
                hiddenPrompt = "[CALCUL_EXACT: $expr = $formatted] Message original : \"$text\""
                isCalc = true
            } catch (e: Exception) {
                askEngine(text, text, false)
                return
            }
            askEngine(text, hiddenPrompt, isCalc)
        } else {
            askEngine(text, text, false)
        }
    }

    private fun askEngine(displayText: String, prompt: String, isCalc: Boolean) {
        if (_modelState.value != ModelState.READY) {
            _messages.value = _messages.value + ChatMessage(
                Role.ASSISTANT,
                "Le modèle d'IGOR n'est pas encore chargé — importe le fichier .litertlm depuis le menu.",
                isCalc
            )
            return
        }
        _isThinking.value = true
        val placeholderIndex = _messages.value.size
        _messages.value = _messages.value + ChatMessage(Role.ASSISTANT, "", isCalc)

        viewModelScope.launch {
            try {
                val final = engine.ask(prompt) { partial ->
                    updateLastAssistantMessage(placeholderIndex, partial, isCalc)
                }
                updateLastAssistantMessage(placeholderIndex, final, isCalc)
            } catch (e: Exception) {
                updateLastAssistantMessage(
                    placeholderIndex,
                    "Un imprévu m'empêche de répondre : ${e.message ?: "erreur inconnue"}",
                    isCalc
                )
            } finally {
                _isThinking.value = false
            }
        }
    }

    private fun updateLastAssistantMessage(index: Int, text: String, isCalc: Boolean) {
        val current = _messages.value.toMutableList()
        if (index in current.indices) {
            current[index] = ChatMessage(Role.ASSISTANT, text, isCalc)
            _messages.value = current
        }
    }

    override fun onCleared() {
        engine.close()
        super.onCleared()
    }
}
