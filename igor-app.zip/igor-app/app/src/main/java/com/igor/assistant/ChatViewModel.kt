package com.igor.assistant

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Role { USER, ASSISTANT }

data class ChatMessage(
    val role: Role,
    val text: String,
    val isCalc: Boolean = false,
    val usedWeb: Boolean = false,
    val generatedFilePath: String? = null,
    /** Brouillon de réflexion d'IGOR (étape 1), affiché dans un bloc repliable. */
    val thought: String = "",
    val thoughtSeconds: Int? = null,
    val isReflecting: Boolean = false,
    /** Noms des fichiers joints à ce message (côté utilisateur). */
    val attachments: List<String> = emptyList()
)

enum class ModelState { ABSENT, LOADING, READY, ERROR }

enum class FileStatus { READING, READY, FAILED }

/** Un fichier choisi par l'utilisateur, en cours de lecture ou prêt à être envoyé avec le prochain message. */
data class PendingFile(
    val id: Long,
    val name: String,
    val status: FileStatus,
    val doc: LoadedDocument? = null,
    val error: String? = null
)

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val engine = LlmEngineManager()
    private val modelFile: File get() = File(getApplication<Application>().filesDir, "igor-model.litertlm")
    private val memory = MemoryStore(getApplication<Application>().filesDir)
    private val prefs = app.getSharedPreferences("igor_prefs", Context.MODE_PRIVATE)

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _modelState = MutableStateFlow(ModelState.ABSENT)
    val modelState: StateFlow<ModelState> = _modelState.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    /** Étape en cours (« Recherche sur le web… », « Lecture des documents 2/5… »), affichée sous le chat. */
    private val _status = MutableStateFlow<String?>(null)
    val status: StateFlow<String?> = _status.asStateFlow()

    /** Interrupteur "recherche web" que l'utilisateur peut activer/désactiver. */
    private val _webSearchEnabled = MutableStateFlow(false)
    val webSearchEnabled: StateFlow<Boolean> = _webSearchEnabled.asStateFlow()

    /** Mode réflexion : IGOR rédige d'abord un brouillon de raisonnement, puis répond. */
    private val _reflectionEnabled = MutableStateFlow(prefs.getBoolean("reflection", true))
    val reflectionEnabled: StateFlow<Boolean> = _reflectionEnabled.asStateFlow()

    private val _memories = MutableStateFlow<List<MemoryStore.Memory>>(memory.all())
    val memories: StateFlow<List<MemoryStore.Memory>> = _memories.asStateFlow()

    /** Fichiers générés par IGOR (notes/rapports/PDF), les plus récents en premier. */
    private val _generatedFiles = MutableStateFlow<List<File>>(FileGenerator.listGenerated(getApplication()))
    val generatedFiles: StateFlow<List<File>> = _generatedFiles.asStateFlow()

    /** Fichiers choisis mais pas encore envoyés. */
    private val _pendingFiles = MutableStateFlow<List<PendingFile>>(emptyList())
    val pendingFiles: StateFlow<List<PendingFile>> = _pendingFiles.asStateFlow()

    /** Documents « ouverts » dans la conversation : IGOR peut s'y référer pour toutes les questions suivantes. */
    private val _openDocuments = MutableStateFlow<List<LoadedDocument>>(emptyList())
    val openDocuments: StateFlow<List<LoadedDocument>> = _openDocuments.asStateFlow()

    private var currentJob: Job? = null
    private var activeIndex = -1

    init {
        if (modelFile.exists()) loadModel()
    }

    // ------------------------------------------------------------------
    // Réglages et actions simples
    // ------------------------------------------------------------------

    fun toggleWebSearch() {
        _webSearchEnabled.value = !_webSearchEnabled.value
    }

    fun toggleReflection() {
        val next = !_reflectionEnabled.value
        _reflectionEnabled.value = next
        prefs.edit().putBoolean("reflection", next).apply()
    }

    fun clearMemory() {
        memory.clear()
        _memories.value = emptyList()
    }

    private fun refreshMemories() {
        _memories.value = memory.all()
    }

    fun deleteGeneratedFile(file: File) {
        FileGenerator.delete(file)
        _generatedFiles.value = FileGenerator.listGenerated(getApplication())
    }

    // ------------------------------------------------------------------
    // Fichiers joints
    // ------------------------------------------------------------------

    /** Lit en arrière-plan les fichiers choisis par l'utilisateur ; ils partiront avec le prochain message. */
    fun addFiles(uris: List<Uri>) {
        val context = getApplication<Application>()
        uris.forEach { uri ->
            val id = System.nanoTime()
            _pendingFiles.update { it + PendingFile(id, DocumentReader.displayName(context, uri), FileStatus.READING) }
            viewModelScope.launch {
                var doc: LoadedDocument? = null
                var error: String? = null
                try {
                    doc = DocumentReader.read(context, uri)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    error = e.message ?: "lecture impossible"
                }
                val loaded = doc
                val failure = error
                _pendingFiles.update { list ->
                    list.map { pf ->
                        when {
                            pf.id != id -> pf
                            loaded != null -> pf.copy(status = FileStatus.READY, doc = loaded, name = loaded.name)
                            else -> pf.copy(status = FileStatus.FAILED, error = failure)
                        }
                    }
                }
            }
        }
    }

    fun removePendingFile(id: Long) {
        _pendingFiles.update { list -> list.filter { it.id != id } }
    }

    fun closeDocument(name: String) {
        _openDocuments.update { list -> list.filter { it.name != name } }
    }

    // ------------------------------------------------------------------
    // Modèle
    // ------------------------------------------------------------------

    /** Copie le fichier .litertlm choisi par l'utilisateur dans le stockage privé de l'appli, puis le charge. */
    fun importModel(uri: Uri) {
        _modelState.value = ModelState.LOADING
        _errorMessage.value = null
        viewModelScope.launch {
            try {
                val displayName = DocumentReader.displayName(getApplication(), uri)
                withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                        modelFile.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalStateException("Impossible de lire le fichier sélectionné")
                }
                prefs.edit().putString("model_name", displayName).apply()
                loadModel()
            } catch (e: Exception) {
                _modelState.value = ModelState.ERROR
                _errorMessage.value = "Import impossible : ${e.message ?: "erreur inconnue"}"
            }
        }
    }

    private fun loadModel() {
        _modelState.value = ModelState.LOADING
        viewModelScope.launch {
            try {
                val name = prefs.getString("model_name", null)
                withContext(Dispatchers.Default) { engine.initialize(modelFile, name) }
                _modelState.value = ModelState.READY
            } catch (e: Exception) {
                _modelState.value = ModelState.ERROR
                _errorMessage.value = "Chargement du modèle impossible : ${e.message ?: "erreur inconnue"}"
            }
        }
    }

    fun resetModel() {
        currentJob?.cancel()
        engine.close()
        if (modelFile.exists()) modelFile.delete()
        prefs.edit().remove("model_name").apply()
        _modelState.value = ModelState.ABSENT
        _messages.value = emptyList()
        _openDocuments.value = emptyList()
        _pendingFiles.value = emptyList()
    }

    fun newConversation() {
        currentJob?.cancel()
        _messages.value = emptyList()
        _openDocuments.value = emptyList()
        _pendingFiles.value = emptyList()
        engine.resetConversation()
    }

    /** Interrompt la réponse en cours (le texte déjà produit est conservé). */
    fun stop() {
        currentJob?.cancel()
    }

    // ------------------------------------------------------------------
    // Envoi d'un message
    // ------------------------------------------------------------------

    fun send(rawText: String) {
        val typed = rawText.trim()
        val pending = _pendingFiles.value
        if (_isThinking.value || pending.any { it.status == FileStatus.READING }) return
        val newDocs = pending.mapNotNull { it.doc }
        if (typed.isEmpty() && newDocs.isEmpty()) return

        val text = typed.ifEmpty {
            if (newDocs.size > 1) "Lis ces documents et fais-m'en un résumé clair."
            else "Lis ce document et fais-m'en un résumé clair."
        }

        if (newDocs.isNotEmpty()) {
            val kept = _openDocuments.value.filter { old -> newDocs.none { it.name == old.name } }
            _openDocuments.value = (kept + newDocs).takeLast(MAX_OPEN_DOCS)
        }
        _pendingFiles.value = emptyList()

        val history = _messages.value
        _messages.value = history + ChatMessage(Role.USER, text, attachments = newDocs.map { it.name })
        _isThinking.value = true
        activeIndex = -1

        currentJob = viewModelScope.launch {
            try {
                runTurn(text, history)
            } catch (e: CancellationException) {
                markInterrupted()
                throw e
            } catch (e: Exception) {
                showError("Un imprévu m'empêche de répondre : ${e.message ?: "erreur inconnue"}")
            } finally {
                _isThinking.value = false
                _status.value = null
                currentJob = null
            }
        }
    }

    private fun markInterrupted() {
        if (activeIndex >= 0) {
            updateAssistant(activeIndex) { m ->
                m.copy(
                    text = if (m.text.isBlank()) "⏹ Réponse interrompue." else m.text,
                    isReflecting = false
                )
            }
        } else {
            _messages.update { it + ChatMessage(Role.ASSISTANT, "⏹ Interrompu.") }
        }
    }

    private fun showError(message: String) {
        if (activeIndex >= 0) {
            updateAssistant(activeIndex) { it.copy(text = message, isReflecting = false) }
        } else {
            _messages.update { it + ChatMessage(Role.ASSISTANT, message) }
        }
    }

    /** Traite un message de bout en bout : outils exacts, mémoire, web, documents, réflexion, réponse. */
    private suspend fun runTurn(text: String, history: List<ChatMessage>) {
        // 1. Demande explicite de mémorisation (« retiens que… ») : on stocke tout de suite le fait.
        val explicitFact = MemoryStore.extractExplicitMemory(text)
        if (explicitFact != null) {
            memory.rememberIfNew(explicitFact)
            refreshMemories()
            val hidden = "[MEMOIRE_ENREGISTREE: \"$explicitFact\"] Confirme en une phrase naturelle que tu as retenu ceci."
            answer(text, hidden, history, isCalc = false, usedWeb = false, isFileRequest = false, reflect = false)
            return
        }

        // Faits que l'utilisateur donne spontanément sur lui (prénom, ville, goûts…).
        val facts = MemoryStore.extractPersonalFacts(text)
        if (facts.isNotEmpty()) {
            facts.forEach { memory.rememberIfNew(it) }
            refreshMemories()
        }

        val docs = _openDocuments.value
        val isFileRequest = FileGenerator.isFileRequest(text)

        // 2. Calcul exact, puis conversion d'unités / calcul de dates (moteurs déterministes).
        if (!isFileRequest) {
            val calc = Calculator.extractExpression(text)?.let { expr ->
                try {
                    expr to Calculator.format(Calculator.evaluate(expr))
                } catch (_: Exception) {
                    null
                }
            }
            if (calc != null) {
                val hidden = buildHiddenPrompt(text, calcTag = "${calc.first} = ${calc.second}")
                answer(text, hidden, history, isCalc = true, usedWeb = false, isFileRequest = false, reflect = false)
                return
            }
            val conversion = UnitConverter.tryConvert(text) ?: UnitConverter.tryDaysBetween(text)
            if (conversion != null) {
                val hidden = buildHiddenPrompt(text, conversionTag = conversion)
                answer(text, hidden, history, isCalc = true, usedWeb = false, isFileRequest = false, reflect = false)
                return
            }
        }

        // 3. Flux normal : recherche web si activée (ou question d'actualité sans document ouvert)…
        var outcome: WebSearchTool.Outcome? = null
        if (_webSearchEnabled.value || (docs.isEmpty() && looksTimely(text))) {
            _status.value = "Recherche sur le web…"
            outcome = withContext(Dispatchers.IO) {
                if (isOnline()) WebSearchTool.search(text)
                else WebSearchTool.Outcome(emptyList(), "pas de connexion internet")
            }
        }

        // …passages utiles des documents ouverts…
        val docBudget = if (outcome?.results?.isNotEmpty() == true) 2_400 else DocumentContext.CONTEXT_BUDGET
        val docBlock = if (docs.isNotEmpty()) buildDocBlock(text, docs, docBudget) else null

        // …puis réflexion et réponse.
        val hidden = buildHiddenPrompt(text, webOutcome = outcome, fileRequest = isFileRequest, docBlock = docBlock)
        val usedWeb = outcome?.results?.isNotEmpty() == true
        answer(
            text, hidden, history,
            isCalc = false, usedWeb = usedWeb, isFileRequest = isFileRequest,
            reflect = shouldReflect(text, docs.isNotEmpty())
        )
    }

    /** Prépare le contexte « documents » : passages pertinents, ou lecture par parties pour une demande globale. */
    private suspend fun buildDocBlock(question: String, docs: List<LoadedDocument>, budget: Int): String {
        val total = docs.sumOf { it.text.length }
        val notes = docs.mapNotNull { d -> d.note?.let { "«${d.name}» : $it" } }

        val body = if (total > budget && DocumentContext.isGlobalRequest(question)) {
            val plan = DocumentContext.mapPlan(docs)
            val sb = StringBuilder()
            plan.forEachIndexed { i, piece ->
                _status.value = "Lecture des documents… (${i + 1}/${plan.size})"
                val summary = engine.askOneShot(
                    "Voici un passage (${piece.label}). Résume-le fidèlement en 3 à 5 phrases, en français, " +
                        "en gardant les noms, chiffres et dates importants. N'invente rien et n'ajoute aucun commentaire.\n\n" +
                        "PASSAGE :\n${piece.text}"
                )
                sb.append("• ").append(piece.label).append(" : ").append(summary.take(700)).append('\n')
            }
            val covered = plan.sumOf { it.text.length }
            val coverage = if (covered < total * 0.9) {
                "lecture partielle : des passages répartis sur tout le contenu"
            } else {
                "contenu lu en entier"
            }
            "Résumé par parties ($coverage) :\n$sb"
        } else {
            DocumentContext.select(docs, question, budget)
        }
        return if (notes.isEmpty()) body else body + "\nRemarques : " + notes.joinToString(" ")
    }

    private fun shouldReflect(text: String, hasDocs: Boolean): Boolean {
        if (!_reflectionEnabled.value) return false
        if (hasDocs) return true
        val words = text.trim().split(Regex("\\s+")).size
        if (words <= 3) return false
        if (words <= 8 && smallTalk.containsMatchIn(text)) return false
        return true
    }

    /** Construit le prompt final : message original + balises de contexte fiable (mémoire, web, documents, calcul, fichier). */
    private fun buildHiddenPrompt(
        originalText: String,
        calcTag: String? = null,
        conversionTag: String? = null,
        webOutcome: WebSearchTool.Outcome? = null,
        fileRequest: Boolean = false,
        docBlock: String? = null
    ): String {
        val tags = StringBuilder()
        if (calcTag != null) tags.append("[CALCUL_EXACT: $calcTag] ")
        if (conversionTag != null) tags.append("[CONVERSION_EXACTE: $conversionTag] ")

        val relevantMemories = memory.relevant(originalText)
        if (relevantMemories.isNotEmpty()) {
            tags.append("[MEMOIRE: ${relevantMemories.joinToString(" ; ")}] ")
        }

        // On distingue explicitement une recherche réussie d'une recherche qui a bien eu
        // lieu mais n'a rien donné : sans cette distinction, le modèle a tendance à dire
        // "d'après mes recherches" par habitude même quand il n'a rien reçu de concret.
        if (webOutcome != null) {
            if (webOutcome.results.isNotEmpty()) {
                // Plafonné : la fenêtre de contexte d'un modèle embarqué est petite.
                val snippets = WebSearchTool.formatForPrompt(webOutcome.results).take(MAX_WEB_CHARS)
                // La consigne d'usage est répétée ici, juste à côté des extraits : avec un
                // petit modèle embarqué, une instruction répétée juste avant la question
                // est bien mieux suivie qu'une instruction lue plusieurs tours plus tôt.
                tags.append(
                    "[RECHERCHE_WEB_OK (${webOutcome.results.size} sources) : $snippets] " +
                        "[RAPPEL: une recherche internet vient réellement d'être effectuée à l'instant et a " +
                        "réussi — les sources ci-dessus sont réelles. Ne dis jamais que tu n'as pas accès à " +
                        "internet : utilise ces sources pour répondre.] "
                )
            } else {
                val reason = webOutcome.failureReason ?: "aucun résultat"
                tags.append(
                    "[RECHERCHE_WEB_ECHEC ($reason)] " +
                        "[RAPPEL: une recherche a réellement été tentée à l'instant mais n'a rien donné. " +
                        "Dis-le simplement à l'utilisateur, sans inventer de réponse.] "
                )
            }
        }

        if (docBlock != null) {
            tags.append(
                "[DOCUMENTS_JOINTS: $docBlock] " +
                    "[RAPPEL: ces extraits proviennent réellement des fichiers de l'utilisateur, lus à l'instant. " +
                    "Ne dis jamais que tu ne peux pas lire les fichiers : réponds à partir de ces extraits et cite le fichier.] "
            )
        }

        if (fileRequest) tags.append("[DEMANDE_FICHIER] ")

        return if (tags.isEmpty()) originalText else "$tags Message original : \"$originalText\""
    }

    // ------------------------------------------------------------------
    // Génération de la réponse (avec ou sans réflexion)
    // ------------------------------------------------------------------

    private suspend fun answer(
        userText: String,
        hiddenPrompt: String,
        history: List<ChatMessage>,
        isCalc: Boolean,
        usedWeb: Boolean,
        isFileRequest: Boolean,
        reflect: Boolean
    ) {
        if (_modelState.value != ModelState.READY) {
            _messages.update {
                it + ChatMessage(
                    Role.ASSISTANT,
                    "Le modèle d'IGOR n'est pas encore chargé — importe le fichier .litertlm depuis le menu.",
                    isCalc
                )
            }
            return
        }

        val index = _messages.value.size
        activeIndex = index
        _messages.update { it + ChatMessage(Role.ASSISTANT, "", isCalc = isCalc, usedWeb = usedWeb, isReflecting = reflect) }
        val recap = { buildRecap(history) }

        var promptForAnswer = hiddenPrompt
        var fallbackForAnswer = hiddenPrompt
        if (reflect) {
            // Étape 1 : brouillon de réflexion (affiché dans un bloc repliable).
            _status.value = "IGOR réfléchit…"
            val started = System.currentTimeMillis()
            val reflectionPrompt = hiddenPrompt + REFLECT_SUFFIX
            val thought = askWithRetry(reflectionPrompt, reflectionPrompt, recap) { partial ->
                updateAssistant(index) { it.copy(thought = partial, isReflecting = true) }
            }.trim()
            val seconds = ((System.currentTimeMillis() - started) / 1000).toInt()
            updateAssistant(index) { it.copy(thought = thought, thoughtSeconds = seconds, isReflecting = false) }

            // Étape 2 : réponse finale. La conversation contient déjà le contexte et la
            // réflexion, donc ce second message est court ; en cas de reprise sur
            // conversation neuve, on renvoie le contexte complet.
            promptForAnswer = ANSWER_PROMPT
            fallbackForAnswer = hiddenPrompt + "\n\n[REFLEXION_FAITE: $thought]\n" + ANSWER_PROMPT
        }

        _status.value = "IGOR rédige la réponse…"
        val final = askWithRetry(promptForAnswer, fallbackForAnswer, recap) { partial ->
            updateAssistant(index) { it.copy(text = partial) }
        }

        var filePath: String? = null
        if (isFileRequest && final.isNotBlank()) {
            filePath = withContext(Dispatchers.IO) {
                try {
                    val format = FileGenerator.detectFormat(userText)
                    val generated = FileGenerator.generate(getApplication(), final, format, userText)
                    generated.file.absolutePath
                } catch (_: Exception) {
                    null
                }
            }
            if (filePath != null) {
                _generatedFiles.value = FileGenerator.listGenerated(getApplication())
            }
        }

        val shown = final.ifBlank { "Je n'ai pas réussi à formuler une réponse. Peux-tu reformuler ta demande ?" }
        updateAssistant(index) { it.copy(text = shown, generatedFilePath = filePath, isReflecting = false) }
    }

    /** Interroge le modèle ; en cas d'erreur (contexte saturé, moteur bloqué…), retente une fois sur une conversation neuve. */
    private suspend fun askWithRetry(
        prompt: String,
        fallback: String,
        recap: () -> String,
        onChunk: (String) -> Unit
    ): String {
        return try {
            engine.ask(prompt, fallback, recap, onChunk)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            engine.markDirty()
            engine.ask(fallback, fallback, recap, onChunk)
        }
    }

    /** Rappel compact des derniers échanges, pour repartir d'une conversation neuve sans perdre le fil. */
    private fun buildRecap(history: List<ChatMessage>): String {
        val recent = history.filter { it.text.isNotBlank() }.takeLast(6)
        val docs = _openDocuments.value
        if (recent.isEmpty() && docs.isEmpty()) return ""
        val sb = StringBuilder()
        recent.forEach { m ->
            sb.append(if (m.role == Role.USER) "Utilisateur : " else "IGOR : ")
                .append(m.text.replace("\n", " ").take(260))
                .append('\n')
        }
        if (docs.isNotEmpty()) sb.append("Documents ouverts : ").append(docs.joinToString { it.name }).append('\n')
        return sb.toString().trim()
    }

    private fun updateAssistant(index: Int, transform: (ChatMessage) -> ChatMessage) {
        _messages.update { current ->
            if (index in current.indices) {
                current.toMutableList().also { it[index] = transform(it[index]) }
            } else {
                current
            }
        }
    }

    private fun isOnline(): Boolean {
        return try {
            val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java)
            val network = cm?.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            false
        }
    }

    override fun onCleared() {
        engine.close()
        super.onCleared()
    }

    companion object {
        private const val MAX_OPEN_DOCS = 4
        private const val MAX_WEB_CHARS = 3_000

        private const val REFLECT_SUFFIX =
            "\n\n[ETAPE_REFLEXION] Avant de répondre, réfléchis en écrivant un court brouillon en français " +
                "(5 à 8 lignes maximum, style notes, à la première personne) : ce que l'utilisateur veut vraiment ; " +
                "les informations utiles dont je dispose (documents, mémoire, recherche, calcul) et celles qui manquent ; " +
                "le plan de ma réponse ; les erreurs ou pièges à éviter. N'écris PAS encore la réponse finale."

        private const val ANSWER_PROMPT =
            "[ETAPE_REPONSE] Ta réflexion est terminée. Écris maintenant directement la réponse finale destinée à " +
                "l'utilisateur, en suivant ton plan et en t'appuyant sur les informations fournies. Ne recopie pas ton " +
                "brouillon et ne parle pas de ta réflexion. Si un fichier a été demandé ([DEMANDE_FICHIER]), écris " +
                "directement le contenu du fichier."

        // Messages courts de conversation courante pour lesquels une réflexion serait superflue.
        private val smallTalk = Regex(
            "\\b(bonjour|bonsoir|salut|coucou|hello|merci|[çc]a va|ok|d'accord|super|cool|au revoir|bonne (nuit|journ[ée]e))\\b",
            RegexOption.IGNORE_CASE
        )

        // Mots-clés indiquant qu'une question porte probablement sur une information
        // factuelle, récente ou changeante, pour déclencher une recherche web même si
        // l'utilisateur n'a pas explicitement activé l'interrupteur. Volontairement
        // large : le modèle embarqué n'a ni connaissances très à jour ni beaucoup de
        // connaissances de niche, donc en cas de doute il vaut mieux vérifier sur
        // internet que répondre de mémoire.
        private val timelyPattern = Regex(
            "\\b(aujourd'hui|hier|demain|actualit[ée]s?|derni[eè]re?s?\\s+nouvelles?|en\\s+direct|" +
                "ce\\s+matin|cette\\s+semaine|cette\\s+ann[ée]e|l'ann[ée]e\\s+derni[eè]re|" +
                "m[ée]t[ée]o|score|r[ée]sultat(s)?\\s+du\\s+match|" +
                "qui\\s+est(\\s+(le|la))?|qui\\s+a\\s+(gagn[ée]|invent[ée]|cr[ée][ée]?|d[ée]couvert)|" +
                "o[uù]\\s+(se\\s+trouve|est|sont|se\\s+situe)|quand\\s+(a|est|sera|sort|ouvre|ferme)|" +
                "combien\\s+(co[uû]te|de|font|vaut|p[eè]se|mesure)|prix\\s+(du|de|d'un|d'une)|" +
                "derni[eè]re?\\s+version|nouvelle\\s+version|vient\\s+de\\s+sortir|(vient\\s+de\\s+)?sortir|est\\s+sorti|" +
                "existe[- ]t[- ]il|est[- ]ce\\s+(que|toujours|encore)|disponible|en\\s+ce\\s+moment|" +
                "actuel(le)?(ment)?|pr[ée]sident|premier\\s+ministre|\\bpdg\\b|" +
                "c'est\\s+quoi|qu'est[- ]ce\\s+que|20(2[6-9]|[3-9]\\d))\\b",
            RegexOption.IGNORE_CASE
        )

        fun looksTimely(text: String): Boolean = timelyPattern.containsMatchIn(text)
    }
}
