package com.igor.assistant

import android.app.Application
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Role { USER, ASSISTANT }
data class ChatMessage(
    val role: Role,
    val text: String,
    val isCalc: Boolean = false,
    val usedWeb: Boolean = false,
    val generatedFilePath: String? = null
)

enum class ModelState { ABSENT, LOADING, READY, ERROR }

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val engine = LlmEngineManager()
    private val modelFile: File get() = File(getApplication<Application>().filesDir, "igor-model.litertlm")
    private val memory = MemoryStore(getApplication<Application>().filesDir)

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _modelState = MutableStateFlow(ModelState.ABSENT)
    val modelState: StateFlow<ModelState> = _modelState.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    /** Interrupteur "recherche web" que l'utilisateur peut activer/désactiver pour ce message. */
    private val _webSearchEnabled = MutableStateFlow(false)
    val webSearchEnabled: StateFlow<Boolean> = _webSearchEnabled.asStateFlow()

    private val _memories = MutableStateFlow<List<MemoryStore.Memory>>(memory.all())
    val memories: StateFlow<List<MemoryStore.Memory>> = _memories.asStateFlow()

    /** Fichiers générés par IGOR (notes/rapports/PDF), les plus récents en premier. */
    private val _generatedFiles = MutableStateFlow<List<File>>(FileGenerator.listGenerated(getApplication()))
    val generatedFiles: StateFlow<List<File>> = _generatedFiles.asStateFlow()

    init {
        if (modelFile.exists()) loadModel()
    }

    fun toggleWebSearch() {
        _webSearchEnabled.value = !_webSearchEnabled.value
    }

    fun clearMemory() {
        memory.clear()
        _memories.value = emptyList()
    }

    fun deleteGeneratedFile(file: File) {
        FileGenerator.delete(file)
        _generatedFiles.value = FileGenerator.listGenerated(getApplication())
    }

    /** Copie le fichier .litertlm choisi par l'utilisateur dans le stockage privé de l'appli, puis le charge. */
    fun importModel(uri: Uri) {
        _modelState.value = ModelState.LOADING
        _errorMessage.value = null
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                        modelFile.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalStateException("Impossible de lire le fichier sélectionné")
                }
                loadModel()
            } catch (e: Exception) {
                _modelState.value = ModelState.ERROR
                _errorMessage.value = "Import impossible : ${e.message ?: "erreur inconnue"}"
            }
        }
    }

    private fun loadModel() {
        _modelState.value = ModelState.LOADING
        viewModelScope.launch {
            try {
                withContext(Dispatchers.Default) { engine.initialize(modelFile) }
                _modelState.value = ModelState.READY
            } catch (e: Exception) {
                _modelState.value = ModelState.ERROR
                _errorMessage.value = "Chargement du modèle impossible : ${e.message ?: "erreur inconnue"}"
            }
        }
    }

    fun resetModel() {
        engine.close()
        if (modelFile.exists()) modelFile.delete()
        _modelState.value = ModelState.ABSENT
        _messages.value = emptyList()
    }

    fun newConversation() {
        _messages.value = emptyList()
    }

    fun send(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty() || _isThinking.value) return

        _messages.value = _messages.value + ChatMessage(Role.USER, text)

        // 1. Demande explicite de mémorisation ("retiens que...") : on stocke tout de
        // suite le fait, sans passer par le moteur de calcul.
        val explicitFact = MemoryStore.extractExplicitMemory(text)
        if (explicitFact != null) {
            memory.remember(explicitFact)
            _memories.value = memory.all()
            val hidden = "[MEMOIRE_ENREGISTREE: \"$explicitFact\"] Confirme en une phrase naturelle que tu as retenu ceci."
            askEngine(text, hidden, isCalc = false, usedWeb = false, isFileRequest = false)
            return
        }

        // 2. Demande explicite de génération de fichier : on laisse le modèle produire
        // le contenu (avec la consigne [DEMANDE_FICHIER]), le fichier est créé une fois
        // la réponse complète reçue (voir askEngine / finalisation ci-dessous).
        val isFileRequest = FileGenerator.isFileRequest(text)

        // 3. Calcul exact si applicable.
        val expr = Calculator.extractExpression(text)
        if (expr != null && !isFileRequest) {
            try {
                val value = Calculator.evaluate(expr)
                val formatted = Calculator.format(value)
                val hidden = buildHiddenPrompt(text, calcTag = "$expr = $formatted")
                askEngine(text, hidden, isCalc = true, usedWeb = false, isFileRequest = false)
                return
            } catch (_: Exception) {
                // Pas une expression valide malgré les apparences : on continue.
            }
        }

        // 4. Conversion d'unité ou calcul de dates, exacts eux aussi.
        if (!isFileRequest) {
            val conversion = UnitConverter.tryConvert(text) ?: UnitConverter.tryDaysBetween(text)
            if (conversion != null) {
                val hidden = buildHiddenPrompt(text, conversionTag = conversion)
                askEngine(text, hidden, isCalc = true, usedWeb = false, isFileRequest = false)
                return
            }
        }

        // 5. Sinon, flux normal : mémoire pertinente, et recherche web si activée ou si
        // la question semble d'actualité.
        val shouldSearch = _webSearchEnabled.value || looksTimely(text)
        if (shouldSearch) {
            _isThinking.value = true
            viewModelScope.launch {
                val outcome = withContext(Dispatchers.IO) {
                    if (isOnline()) WebSearchTool.search(text)
                    else WebSearchTool.Outcome(emptyList(), "pas de connexion internet")
                }
                val hidden = buildHiddenPrompt(text, webOutcome = outcome, fileRequest = isFileRequest)
                askEngine(text, hidden, isCalc = false, usedWeb = outcome.results.isNotEmpty(), isFileRequest = isFileRequest)
            }
        } else {
            val hidden = buildHiddenPrompt(text, fileRequest = isFileRequest)
            askEngine(text, hidden, isCalc = false, usedWeb = false, isFileRequest = isFileRequest)
        }
    }

    /** Construit le prompt final : message original + balises de contexte fiable (mémoire, web, calcul, fichier). */
    private fun buildHiddenPrompt(
        originalText: String,
        calcTag: String? = null,
        conversionTag: String? = null,
        webOutcome: WebSearchTool.Outcome? = null,
        fileRequest: Boolean = false
    ): String {
        val tags = StringBuilder()
        if (calcTag != null) tags.append("[CALCUL_EXACT: $calcTag] ")
        if (conversionTag != null) tags.append("[CONVERSION_EXACTE: $conversionTag] ")

        val relevantMemories = memory.relevant(originalText)
        if (relevantMemories.isNotEmpty()) {
            tags.append("[MEMOIRE: ${relevantMemories.joinToString(" ; ")}] ")
        }

        // On distingue explicitement une recherche réussie d'une recherche qui a bien eu
        // lieu mais n'a rien donné : sans cette distinction, le modèle a tendance à dire
        // "d'après mes recherches" par habitude même quand il n'a rien reçu de concret.
        if (webOutcome != null) {
            if (webOutcome.results.isNotEmpty()) {
                val snippets = WebSearchTool.formatForPrompt(webOutcome.results)
                tags.append("[RECHERCHE_WEB_OK (${webOutcome.results.size} sources) : $snippets] ")
            } else {
                val reason = webOutcome.failureReason ?: "aucun résultat"
                tags.append("[RECHERCHE_WEB_ECHEC ($reason)] ")
            }
        }

        if (fileRequest) tags.append("[DEMANDE_FICHIER] ")

        return if (tags.isEmpty()) originalText else "$tags Message original : \"$originalText\""
    }

    private fun askEngine(
        displayText: String,
        prompt: String,
        isCalc: Boolean,
        usedWeb: Boolean,
        isFileRequest: Boolean
    ) {
        if (_modelState.value != ModelState.READY) {
            _messages.value = _messages.value + ChatMessage(
                Role.ASSISTANT,
                "Le modèle d'IGOR n'est pas encore chargé — importe le fichier .litertlm depuis le menu.",
                isCalc
            )
            _isThinking.value = false
            return
        }
        _isThinking.value = true
        val placeholderIndex = _messages.value.size
        _messages.value = _messages.value + ChatMessage(Role.ASSISTANT, "", isCalc, usedWeb)

        viewModelScope.launch {
            try {
                val final = engine.ask(prompt) { partial ->
                    updateLastAssistantMessage(placeholderIndex, partial, isCalc, usedWeb)
                }

                var filePath: String? = null
                if (isFileRequest && final.isNotBlank()) {
                    filePath = withContext(Dispatchers.IO) {
                        try {
                            val format = FileGenerator.detectFormat(displayText)
                            val generated = FileGenerator.generate(getApplication(), final, format, displayText)
                            generated.file.absolutePath
                        } catch (_: Exception) {
                            null
                        }
                    }
                    if (filePath != null) {
                        _generatedFiles.value = FileGenerator.listGenerated(getApplication())
                    }
                }

                updateLastAssistantMessage(placeholderIndex, final, isCalc, usedWeb, filePath)

                // On garde une trace compacte de l'échange pour pouvoir s'en resservir
                // plus tard, seulement si le message avait un contenu substantiel
                // (on évite de polluer la mémoire avec du small talk trop bref).
                if (displayText.length > 12 && final.isNotBlank()) {
                    val summary = final.take(220)
                    memory.remember("Question : \"$displayText\" — Réponse : \"$summary\"")
                    _memories.value = memory.all()
                }
            } catch (e: Exception) {
                updateLastAssistantMessage(
                    placeholderIndex,
                    "Un imprévu m'empêche de répondre : ${e.message ?: "erreur inconnue"}",
                    isCalc,
                    usedWeb
                )
            } finally {
                _isThinking.value = false
            }
        }
    }

    private fun updateLastAssistantMessage(
        index: Int,
        text: String,
        isCalc: Boolean,
        usedWeb: Boolean,
        generatedFilePath: String? = null
    ) {
        val current = _messages.value.toMutableList()
        if (index in current.indices) {
            current[index] = ChatMessage(Role.ASSISTANT, text, isCalc, usedWeb, generatedFilePath)
            _messages.value = current
        }
    }

    private fun isOnline(): Boolean {
        return try {
            val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java)
            val network = cm?.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            false
        }
    }

    override fun onCleared() {
        engine.close()
        super.onCleared()
    }

    companion object {
        // Mots-clés indiquant qu'une question porte probablement sur une information
        // factuelle, récente ou changeante, pour déclencher une recherche web même si
        // l'utilisateur n'a pas explicitement activé l'interrupteur. Volontairement
        // large : le modèle embarqué (1,7 milliard de paramètres) n'a ni connaissances
        // très à jour ni beaucoup de connaissances de niche, donc en cas de doute il
        // vaut mieux vérifier sur internet que répondre de mémoire.
        private val timelyPattern = Regex(
            "\\b(aujourd'hui|hier|demain|actualit[ée]s?|derni[eè]re?s?\\s+nouvelles?|en\\s+direct|" +
                "ce\\s+matin|cette\\s+semaine|cette\\s+ann[ée]e|l'ann[ée]e\\s+derni[eè]re|" +
                "m[ée]t[ée]o|score|r[ée]sultat(s)?\\s+du\\s+match|" +
                "qui\\s+est(\\s+(le|la))?|qui\\s+a\\s+(gagn[ée]|invent[ée]|cr[ée][ée]?|d[ée]couvert)|" +
                "o[uù]\\s+(se\\s+trouve|est|sont|se\\s+situe)|quand\\s+(a|est|sera|sort|ouvre|ferme)|" +
                "combien\\s+(co[uû]te|de|font|vaut|p[eè]se|mesure)|prix\\s+(du|de|d'un|d'une)|" +
                "derni[eè]re?\\s+version|nouvelle\\s+version|vient\\s+de\\s+sortir|(vient\\s+de\\s+)?sortir|est\\s+sorti|" +
                "existe[- ]t[- ]il|est[- ]ce\\s+(que|toujours|encore)|disponible|en\\s+ce\\s+moment|" +
                "actuel(le)?(ment)?|pr[ée]sident|premier\\s+ministre|\\bpdg\\b|" +
                "c'est\\s+quoi|qu'est[- ]ce\\s+que|20(2[6-9]|[3-9]\\d))\\b",
            RegexOption.IGNORE_CASE
        )

        fun looksTimely(text: String): Boolean = timelyPattern.containsMatchIn(text)
    }
}
