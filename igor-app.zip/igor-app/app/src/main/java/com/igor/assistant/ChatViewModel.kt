package com.igor.assistant

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Role { USER, ASSISTANT }
data class ChatMessage(val role: Role, val text: String, val isCalc: Boolean = false)

enum class ModelState { ABSENT, LOADING, READY, ERROR }

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val engine = LlmEngineManager()
    private val modelFile: File get() = File(getApplication<Application>().filesDir, "igor-model.litertlm")

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _modelState = MutableStateFlow(ModelState.ABSENT)
    val modelState: StateFlow<ModelState> = _modelState.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    // Mots-clés qui déclenchent une recherche internet avant de répondre : soit une
    // demande explicite ("cherche...", "sur internet"), soit un sujet qui ne peut
    // pas être répondu de façon fiable par un modèle figé (actualité, météo, prix,
    // dernière version d'un logiciel, résultat d'un match, date du jour, etc.).
    // C'est une détection heuristique et non une décision du modèle lui-même : le
    // modèle embarqué n'a pas d'appel d'outil natif, donc IGOR décide en amont.
    private val searchTriggerRegex = Regex(
        """\b(cherche|recherche(s)?|googl(e|ise)|sur\s+internet|en\s+ligne|actualit[ée]s?|""" +
            """derni[eè]res?\s+(nouvelles|infos)|informations?\s+r[ée]centes?|aujourd'hui|""" +
            """en\s+ce\s+moment|m[ée]t[ée]o|cours\s+(du|de\s+la)|prix\s+(du|de\s+la|actuel)|""" +
            """derni[eè]re\s+version|sortie\s+de|score\s+(du|de)|r[ée]sultat\s+du\s+match|""" +
            """qui\s+est\s+(le|la|l'|les)\s+(actuel|nouveau|nouvelle)|quelle\s+heure|quelle\s+date""" +
            "\\b",
        RegexOption.IGNORE_CASE
    )

    private fun needsWebSearch(text: String): Boolean = searchTriggerRegex.containsMatchIn(text)

    init {
        // Ne pas charger automatiquement un ancien modèle au démarrage.
        //
        // Une mise à jour de LiteRT-LM peut rendre un modèle .litertlm déjà
        // présent dans le stockage incompatible. Dans ce cas, l'initialisation
        // native peut faire tomber tout le processus Android avant que l'UI
        // puisse afficher une erreur. On laisse donc IGOR démarrer sans modèle
        // et l'utilisateur choisit explicitement le fichier à charger.
    }

    /** Copie le fichier .litertlm choisi par l'utilisateur dans le stockage privé de l'appli, puis le charge. */
    fun importModel(uri: Uri) {
        _modelState.value = ModelState.LOADING
        _errorMessage.value = null
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                        modelFile.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalStateException("Impossible de lire le fichier sélectionné")
                }
                loadModel()
            } catch (e: Exception) {
                _modelState.value = ModelState.ERROR
                _errorMessage.value = "Import impossible : ${e.message ?: "erreur inconnue"}"
            }
        }
    }

    private fun loadModel() {
        _modelState.value = ModelState.LOADING
        viewModelScope.launch {
            try {
                withContext(Dispatchers.Default) { engine.initialize(modelFile) }
                _modelState.value = ModelState.READY
            } catch (e: Exception) {
                _modelState.value = ModelState.ERROR
                _errorMessage.value = "Chargement du modèle impossible : ${e.message ?: "erreur inconnue"}"
            }
        }
    }

    fun resetModel() {
        engine.close()
        if (modelFile.exists()) modelFile.delete()
        _modelState.value = ModelState.ABSENT
        _messages.value = emptyList()
    }

    fun newConversation() {
        _messages.value = emptyList()
    }

    fun send(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty() || _isThinking.value) return

        _messages.value = _messages.value + ChatMessage(Role.USER, text)

        val expr = Calculator.extractExpression(text)
        if (expr != null) {
            try {
                val value = Calculator.evaluate(expr)
                val formatted = Calculator.format(value)
                val hiddenPrompt = "[CALCUL_EXACT: $expr = $formatted] Message original : \"$text\""
                askEngine(hiddenPrompt, isCalc = true)
                return
            } catch (e: Exception) {
                // Détecté comme calcul mais invalide (ex: division par zéro) : on
                // laisse IGOR répondre normalement au message brut.
            }
        }

        if (needsWebSearch(text)) {
            searchThenAsk(text)
        } else {
            askEngine(text, isCalc = false)
        }
    }

    /** Effectue une recherche internet, puis transmet les résultats au modèle avant qu'il réponde. */
    private fun searchThenAsk(text: String) {
        if (_modelState.value != ModelState.READY) {
            _messages.value = _messages.value + ChatMessage(
                Role.ASSISTANT,
                "Le modèle d'IGOR n'est pas encore chargé — importe le fichier .litertlm depuis le menu.",
                false
            )
            return
        }
        _isThinking.value = true
        val placeholderIndex = _messages.value.size
        _messages.value = _messages.value + ChatMessage(Role.ASSISTANT, "Je consulte internet…", false)

        viewModelScope.launch {
            val resultsText = withContext(Dispatchers.IO) { WebSearch.searchAndFormat(text) }
            val hiddenPrompt = "[RECHERCHE_WEB pour : \"$text\"]\n$resultsText\n\n" +
                "Message original de l'utilisateur : \"$text\""
            try {
                val final = engine.ask(hiddenPrompt) { partial ->
                    updateLastAssistantMessage(placeholderIndex, partial, false)
                }
                updateLastAssistantMessage(placeholderIndex, final, false)
            } catch (e: Exception) {
                updateLastAssistantMessage(
                    placeholderIndex,
                    "Un imprévu m'empêche de répondre : ${e.message ?: "erreur inconnue"}",
                    false
                )
            } finally {
                _isThinking.value = false
            }
        }
    }

    private fun askEngine(prompt: String, isCalc: Boolean) {
        if (_modelState.value != ModelState.READY) {
            _messages.value = _messages.value + ChatMessage(
                Role.ASSISTANT,
                "Le modèle d'IGOR n'est pas encore chargé — importe le fichier .litertlm depuis le menu.",
                isCalc
            )
            return
        }
        _isThinking.value = true
        val placeholderIndex = _messages.value.size
        _messages.value = _messages.value + ChatMessage(Role.ASSISTANT, "", isCalc)

        viewModelScope.launch {
            try {
                val final = engine.ask(prompt) { partial ->
                    updateLastAssistantMessage(placeholderIndex, partial, isCalc)
                }
                updateLastAssistantMessage(placeholderIndex, final, isCalc)
            } catch (e: Exception) {
                updateLastAssistantMessage(
                    placeholderIndex,
                    "Un imprévu m'empêche de répondre : ${e.message ?: "erreur inconnue"}",
                    isCalc
                )
            } finally {
                _isThinking.value = false
            }
        }
    }

    private fun updateLastAssistantMessage(index: Int, text: String, isCalc: Boolean) {
        val current = _messages.value.toMutableList()
        if (index in current.indices) {
            current[index] = ChatMessage(Role.ASSISTANT, text, isCalc)
            _messages.value = current
        }
    }

    override fun onCleared() {
        engine.close()
        super.onCleared()
    }
}
