package com.igor.assistant

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.igor.assistant.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            IgorTheme {
                IgorApp(viewModel)
            }
        }
    }
}

/** Numéro de version de l'appli, lu depuis le paquet installé (= `versionName` de app/build.gradle.kts). */
@Composable
fun rememberAppVersion(): String {
    val context = LocalContext.current
    return remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName.orEmpty()
        } catch (_: Exception) {
            ""
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IgorApp(viewModel: ChatViewModel) {
    val appVersion = rememberAppVersion()
    val messages by viewModel.messages.collectAsState()
    val modelState by viewModel.modelState.collectAsState()
    val error by viewModel.errorMessage.collectAsState()
    val isThinking by viewModel.isThinking.collectAsState()
    val status by viewModel.status.collectAsState()
    val webSearchEnabled by viewModel.webSearchEnabled.collectAsState()
    val reflectionEnabled by viewModel.reflectionEnabled.collectAsState()
    val pendingFiles by viewModel.pendingFiles.collectAsState()
    val openDocuments by viewModel.openDocuments.collectAsState()
    val memories by viewModel.memories.collectAsState()
    val generatedFiles by viewModel.generatedFiles.collectAsState()

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showMemoryDialog by remember { mutableStateOf(false) }
    var showFilesDialog by remember { mutableStateOf(false) }

    val pickModel = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { viewModel.importModel(it) } }

    val pickFiles = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) viewModel.addFiles(uris) }

    if (showMemoryDialog) {
        MemoryDialog(
            memories = memories,
            onClear = { viewModel.clearMemory() },
            onDismiss = { showMemoryDialog = false }
        )
    }

    if (showFilesDialog) {
        FilesDialog(
            files = generatedFiles,
            onDelete = { viewModel.deleteGeneratedFile(it) },
            onDismiss = { showFilesDialog = false }
        )
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = IgorPanel) {
                Column(Modifier.padding(20.dp)) {
                    Text("IGOR", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = IgorText)
                    if (appVersion.isNotEmpty()) {
                        Text("version $appVersion", fontSize = 12.sp, color = IgorMuted)
                    }
                    Spacer(Modifier.height(18.dp))
                    DrawerItem("Nouvelle conversation") {
                        viewModel.newConversation()
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Mémoire d'IGOR (${memories.size})") {
                        showMemoryDialog = true
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Fichiers générés (${generatedFiles.size})") {
                        showFilesDialog = true
                        scope.launch { drawerState.close() }
                    }
                    DrawerItem("Importer / changer de modèle (.litertlm)") {
                        scope.launch { drawerState.close() }
                        pickModel.launch(arrayOf("*/*"))
                    }
                    DrawerItem("Réinitialiser IGOR", danger = true) {
                        viewModel.resetModel()
                        scope.launch { drawerState.close() }
                    }
                    Spacer(Modifier.weight(1f))
                    Text(
                        "IGOR fonctionne hors ligne par défaut, avec le modèle .litertlm que tu as importé. " +
                            "Envoie-lui des fichiers avec le trombone (texte, PDF, Word, Excel, PowerPoint, " +
                            "images) : il les lit et répond à tes questions dessus. Le bouton cerveau active " +
                            "sa réflexion (un brouillon de raisonnement avant chaque réponse). Il retient " +
                            "certains éléments d'une conversation à l'autre, peut chercher sur internet si tu " +
                            "actives l'icône 🌐 ou si ta question porte sur une actualité, et peut générer un " +
                            "vrai fichier (.txt, .md ou .pdf) — dis par exemple « génère-moi un fichier PDF " +
                            "avec... ».",
                        fontSize = 12.sp,
                        color = IgorMuted,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    ) {
        Scaffold(
            containerColor = IgorBackground,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = IgorBackground, titleContentColor = IgorText),
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = IgorText)
                        }
                    },
                    title = { Text("IGOR", fontWeight = FontWeight.SemiBold) },
                    actions = {
                        val (dotColor, label) = when (modelState) {
                            ModelState.READY -> Color(0xFF5B8C5A) to "actif"
                            ModelState.LOADING -> IgorAccent to "chargement…"
                            else -> IgorMuted to "modèle requis"
                        }
                        Box(
                            Modifier
                                .padding(end = 16.dp)
                                .size(8.dp)
                                .background(dotColor, shape = androidx.compose.foundation.shape.CircleShape)
                        )
                        Text(label, fontSize = 12.sp, color = IgorMuted, modifier = Modifier.padding(end = 12.dp))
                    }
                )
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (modelState) {
                    ModelState.ABSENT, ModelState.ERROR -> ModelSetupScreen(
                        error = error,
                        onPick = { pickModel.launch(arrayOf("*/*")) }
                    )
                    ModelState.LOADING -> LoadingScreen()
                    ModelState.READY -> ChatScreen(
                        messages = messages,
                        isThinking = isThinking,
                        status = status,
                        webSearchEnabled = webSearchEnabled,
                        reflectionEnabled = reflectionEnabled,
                        pendingFiles = pendingFiles,
                        openDocuments = openDocuments,
                        onToggleWebSearch = viewModel::toggleWebSearch,
                        onToggleReflection = viewModel::toggleReflection,
                        onAttach = { pickFiles.launch(arrayOf("*/*")) },
                        onRemovePending = viewModel::removePendingFile,
                        onCloseDocument = viewModel::closeDocument,
                        onStop = viewModel::stop,
                        onSend = viewModel::send
                    )
                }
            }
        }
    }
}

@Composable
fun MemoryDialog(memories: List<MemoryStore.Memory>, onClear: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IgorPanel,
        title = { Text("Ce qu'IGOR a retenu", color = IgorText) },
        text = {
            if (memories.isEmpty()) {
                Text(
                    "Rien pour l'instant. Dis-lui « retiens que … » ou discute simplement : " +
                        "IGOR garde une trace des échanges utiles pour s'en resservir plus tard.",
                    color = IgorMuted,
                    fontSize = 13.sp
                )
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                    items(memories) { m ->
                        Column(Modifier.padding(vertical = 6.dp)) {
                            Text(m.date, fontSize = 11.sp, color = IgorMuted)
                            Text(m.text, fontSize = 13.sp, color = IgorText, lineHeight = 18.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Fermer", color = IgorAccent) }
        },
        dismissButton = {
            if (memories.isNotEmpty()) {
                TextButton(onClick = { onClear(); onDismiss() }) {
                    Text("Tout effacer", color = IgorDanger)
                }
            }
        }
    )
}

@Composable
fun FilesDialog(files: List<File>, onDelete: (File) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IgorPanel,
        title = { Text("Fichiers générés par IGOR", color = IgorText) },
        text = {
            if (files.isEmpty()) {
                Text(
                    "Rien pour l'instant. Demande par exemple « génère-moi une note au format " +
                        "PDF sur... » et le fichier apparaîtra ici, prêt à ouvrir ou partager.",
                    color = IgorMuted,
                    fontSize = 13.sp
                )
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                    items(files) { f ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Description, contentDescription = null, tint = IgorMuted, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(f.name, fontSize = 12.sp, color = IgorText, modifier = Modifier.weight(1f))
                            IconButton(onClick = { context.startActivity(FileGenerator.viewIntent(context, f)) }) {
                                Icon(Icons.Filled.Description, contentDescription = "Ouvrir", tint = IgorAccent, modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = {
                                context.startActivity(Intent.createChooser(FileGenerator.shareIntent(context, f), "Partager"))
                            }) {
                                Icon(Icons.Filled.Share, contentDescription = "Partager", tint = IgorAccent, modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = { onDelete(f) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Supprimer", tint = IgorDanger, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Fermer", color = IgorAccent) }
        }
    )
}

@Composable
fun DrawerItem(label: String, danger: Boolean = false, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        color = IgorPanel2,
        shape = RoundedCornerShape(9.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Text(
            label,
            modifier = Modifier.padding(12.dp),
            color = if (danger) IgorDanger else IgorText,
            fontSize = 14.sp
        )
    }
}

@Composable
fun ModelSetupScreen(error: String?, onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("IGOR", fontSize = 34.sp, fontWeight = FontWeight.SemiBold, color = IgorText)
        Spacer(Modifier.height(10.dp))
        Text(
            "Pour discuter, IGOR a besoin d'un modèle de langage au format .litertlm, téléchargé une seule fois puis lu entièrement hors ligne.",
            color = IgorMuted,
            fontSize = 14.sp,
            lineHeight = 20.sp
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "1. Sur ton téléphone, télécharge un modèle .litertlm — conseillé : Gemma3-4B-IT " +
                "(fichier .litertlm, ~4 Go, plus fiable que les petits modèles) depuis " +
                "huggingface.co/litert-community/Gemma3-4B-IT. Un téléphone plus modeste ou " +
                "moins de RAM libre : Qwen3-1.7B (huggingface.co/litert-community/Qwen3-1.7B, " +
                "~2,1 Go) reste plus rapide mais moins fiable pour suivre des consignes précises.\n" +
                "2. Reviens ici et choisis ce fichier.",
            color = IgorMuted,
            fontSize = 13.sp,
            lineHeight = 19.sp
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onPick,
            colors = ButtonDefaults.buttonColors(containerColor = IgorAccent, contentColor = IgorAccentInk)
        ) {
            Text("Choisir le fichier modèle")
        }
        if (error != null) {
            Spacer(Modifier.height(14.dp))
            Text(error, color = IgorDanger, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

@Composable
fun LoadingScreen() {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        CircularProgressIndicator(color = IgorAccent)
        Spacer(Modifier.height(14.dp))
        Text("Chargement du modèle…", color = IgorMuted, fontSize = 13.sp)
    }
}

@Composable
fun ChatScreen(
    messages: List<ChatMessage>,
    isThinking: Boolean,
    status: String?,
    webSearchEnabled: Boolean,
    reflectionEnabled: Boolean,
    pendingFiles: List<PendingFile>,
    openDocuments: List<LoadedDocument>,
    onToggleWebSearch: () -> Unit,
    onToggleReflection: () -> Unit,
    onAttach: () -> Unit,
    onRemovePending: (Long) -> Unit,
    onCloseDocument: (String) -> Unit,
    onStop: () -> Unit,
    onSend: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    val stillReading = pendingFiles.any { it.status == FileStatus.READING }
    val hasReadyFile = pendingFiles.any { it.status == FileStatus.READY }
    val canSend = !isThinking && !stillReading && (input.isNotBlank() || hasReadyFile)

    Column(Modifier.fillMaxSize()) {
        if (messages.isEmpty()) {
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("IGOR", fontSize = 30.sp, fontWeight = FontWeight.SemiBold, color = IgorText)
                val appVersion = rememberAppVersion()
                if (appVersion.isNotEmpty()) {
                    Text("version $appVersion", fontSize = 12.sp, color = IgorMuted)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Pose une question, discute librement, donne-moi un calcul, envoie-moi un fichier " +
                        "avec le trombone (PDF, Word, Excel, texte, image…) ou dis « retiens que… » " +
                        "pour que je m'en souvienne la prochaine fois.",
                    color = IgorMuted,
                    fontSize = 14.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages) { msg -> MessageBubble(msg) }
            }
        }

        if (pendingFiles.isNotEmpty() || openDocuments.isNotEmpty()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                openDocuments.forEach { d ->
                    FileChip(d.name, busy = false, failed = false, pending = false, onClose = { onCloseDocument(d.name) })
                }
                pendingFiles.forEach { f ->
                    FileChip(
                        f.name,
                        busy = f.status == FileStatus.READING,
                        failed = f.status == FileStatus.FAILED,
                        pending = true,
                        onClose = { onRemovePending(f.id) }
                    )
                }
            }
            pendingFiles.firstOrNull { it.status == FileStatus.FAILED }?.let { f ->
                Text(
                    "${f.name} : ${f.error ?: "lecture impossible"}",
                    fontSize = 11.sp,
                    color = IgorDanger,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Psychology, contentDescription = null, tint = IgorMuted, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            val info = status
                ?: buildString {
                    append(if (webSearchEnabled) "Recherche web activée" else "Mémoire locale active")
                    append(if (reflectionEnabled) " · Réflexion activée" else " · Réflexion désactivée")
                }
            Text(info, fontSize = 11.sp, color = IgorMuted)
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .background(IgorPanel, RoundedCornerShape(18.dp))
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolButton(Icons.Filled.AttachFile, "Joindre un fichier", pendingFiles.isNotEmpty(), onAttach)
            ToolButton(Icons.Filled.Psychology, "Activer la réflexion", reflectionEnabled, onToggleReflection)
            ToolButton(Icons.Filled.Language, "Activer la recherche web", webSearchEnabled, onToggleWebSearch)
            TextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                maxLines = 5,
                placeholder = { Text("Écris à IGOR…", color = IgorMuted) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = IgorText,
                    unfocusedTextColor = IgorText,
                )
            )
            if (isThinking) {
                IconButton(
                    onClick = onStop,
                    modifier = Modifier.padding(4.dp).background(IgorDanger, CircleShape)
                ) {
                    Icon(Icons.Filled.Stop, contentDescription = "Arrêter", tint = IgorAccentInk)
                }
            } else {
                IconButton(
                    enabled = canSend,
                    onClick = {
                        onSend(input)
                        input = ""
                    },
                    modifier = Modifier
                        .padding(4.dp)
                        .background(if (canSend) IgorAccent else IgorPanel2, CircleShape)
                ) {
                    Icon(
                        Icons.Filled.Send,
                        contentDescription = "Envoyer",
                        tint = if (canSend) IgorAccentInk else IgorMuted
                    )
                }
            }
        }
    }
}

@Composable
fun ToolButton(icon: ImageVector, description: String, active: Boolean, onClick: () -> Unit) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .padding(2.dp)
            .size(38.dp)
            .background(if (active) IgorAccent else IgorPanel2, CircleShape)
    ) {
        Icon(
            icon,
            contentDescription = description,
            tint = if (active) IgorAccentInk else IgorMuted,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun FileChip(label: String, busy: Boolean, failed: Boolean, pending: Boolean, onClose: () -> Unit) {
    Surface(
        color = if (failed) IgorDanger.copy(alpha = 0.18f) else IgorPanel2,
        shape = RoundedCornerShape(50)
    ) {
        Row(
            Modifier.padding(start = 10.dp, end = 2.dp).height(30.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (busy) {
                CircularProgressIndicator(Modifier.size(12.dp), strokeWidth = 2.dp, color = IgorAccent)
            } else {
                Icon(
                    Icons.Filled.Description,
                    contentDescription = null,
                    tint = if (failed) IgorDanger else IgorAccent,
                    modifier = Modifier.size(14.dp)
                )
            }
            Spacer(Modifier.width(6.dp))
            Text(
                label,
                fontSize = 12.sp,
                color = if (pending) IgorAccent else IgorText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 150.dp)
            )
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Retirer", tint = IgorMuted, modifier = Modifier.size(14.dp))
            }
        }
    }
}

@Composable
fun ThoughtBlock(msg: ChatMessage) {
    var expanded by remember { mutableStateOf(false) }
    val open = expanded || msg.isReflecting
    Surface(
        onClick = { expanded = !expanded },
        color = IgorPanel,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.padding(bottom = 6.dp).widthIn(max = 280.dp)
    ) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Psychology, contentDescription = null, tint = IgorAccent, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                val title = when {
                    msg.isReflecting -> "IGOR réfléchit…"
                    msg.thoughtSeconds != null -> "Réflexion (${msg.thoughtSeconds} s)"
                    else -> "Réflexion"
                }
                Text(title, fontSize = 12.sp, color = IgorMuted, modifier = Modifier.weight(1f))
                Icon(
                    if (open) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = null,
                    tint = IgorMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
            if (open && msg.thought.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    msg.thought,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    fontStyle = FontStyle.Italic,
                    color = IgorMuted
                )
            }
        }
    }
}

@Composable
fun MessageBubble(msg: ChatMessage) {
    val isUser = msg.role == Role.USER
    val context = LocalContext.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
        Column(horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
            if (!isUser && (msg.thought.isNotBlank() || msg.isReflecting)) {
                ThoughtBlock(msg)
            }
            if (isUser || msg.text.isNotEmpty() || !msg.isReflecting) {
                Surface(
                    color = if (isUser) IgorAccent else IgorPanel2,
                    shape = RoundedCornerShape(
                        topStart = 16.dp, topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    ),
                    modifier = Modifier.widthIn(max = 280.dp)
                ) {
                    if (isUser) {
                        Text(
                            text = msg.text,
                            color = IgorAccentInk,
                            modifier = Modifier.padding(12.dp),
                            fontSize = 15.sp,
                            lineHeight = 21.sp
                        )
                    } else {
                        SelectionContainer {
                            Text(
                                text = renderMarkdown(msg.text.ifEmpty { "…" }),
                                color = IgorText,
                                modifier = Modifier.padding(12.dp),
                                fontSize = 15.sp,
                                lineHeight = 21.sp
                            )
                        }
                    }
                }
            }
            if (isUser && msg.attachments.isNotEmpty()) {
                Text(
                    "📎 " + msg.attachments.joinToString(", "),
                    fontSize = 11.sp,
                    color = IgorMuted,
                    modifier = Modifier.padding(top = 3.dp, start = 4.dp, end = 4.dp).widthIn(max = 280.dp)
                )
            }
            if (msg.usedWeb) {
                Text(
                    "🌐 réponse appuyée sur une recherche web",
                    fontSize = 10.sp,
                    color = IgorMuted,
                    modifier = Modifier.padding(top = 3.dp, start = 4.dp, end = 4.dp)
                )
            }
            msg.generatedFilePath?.let { path ->
                val file = File(path)
                Surface(
                    color = IgorPanel,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.padding(top = 6.dp).widthIn(max = 280.dp)
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Description, contentDescription = null, tint = IgorAccent, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(file.name, fontSize = 11.sp, color = IgorText, modifier = Modifier.weight(1f))
                        IconButton(
                            modifier = Modifier.size(28.dp),
                            onClick = { context.startActivity(FileGenerator.viewIntent(context, file)) }
                        ) {
                            Icon(Icons.Filled.Description, contentDescription = "Ouvrir", tint = IgorAccent, modifier = Modifier.size(16.dp))
                        }
                        IconButton(
                            modifier = Modifier.size(28.dp),
                            onClick = { context.startActivity(Intent.createChooser(FileGenerator.shareIntent(context, file), "Partager")) }
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = "Partager", tint = IgorAccent, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}
