package com.igor.assistant

import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.abs

/**
 * Deuxième moteur déterministe, dans le même esprit que [Calculator] : conversions
 * d'unités courantes et calculs de dates. Comme pour les calculs, IGOR ne doit jamais
 * deviner un facteur de conversion ou compter des jours de tête — un petit modèle
 * embarqué (1,7 milliard de paramètres) se trompe facilement sur ce genre de chose,
 * alors qu'un facteur de conversion ou une soustraction de dates n'a qu'une seule
 * bonne réponse.
 */
object UnitConverter {

    // -----------------------------------------------------------------
    // Conversions d'unités
    // -----------------------------------------------------------------

    private val lengthToMeters = mapOf(
        "mm" to 0.001, "millimetre" to 0.001, "millimètre" to 0.001, "millimetres" to 0.001, "millimètres" to 0.001,
        "cm" to 0.01, "centimetre" to 0.01, "centimètre" to 0.01, "centimetres" to 0.01, "centimètres" to 0.01,
        "m" to 1.0, "metre" to 1.0, "mètre" to 1.0, "metres" to 1.0, "mètres" to 1.0,
        "km" to 1000.0, "kilometre" to 1000.0, "kilomètre" to 1000.0, "kilometres" to 1000.0, "kilomètres" to 1000.0,
        "mile" to 1609.344, "miles" to 1609.344, "mi" to 1609.344,
        "yard" to 0.9144, "yards" to 0.9144, "yd" to 0.9144,
        "pied" to 0.3048, "pieds" to 0.3048, "ft" to 0.3048,
        "pouce" to 0.0254, "pouces" to 0.0254, "in" to 0.0254
    )

    private val massToGrams = mapOf(
        "mg" to 0.001,
        "g" to 1.0, "gramme" to 1.0, "grammes" to 1.0,
        "kg" to 1000.0, "kilo" to 1000.0, "kilos" to 1000.0, "kilogramme" to 1000.0, "kilogrammes" to 1000.0,
        "tonne" to 1_000_000.0, "tonnes" to 1_000_000.0,
        "livre" to 453.59237, "livres" to 453.59237, "lb" to 453.59237, "lbs" to 453.59237,
        "once" to 28.349523, "onces" to 28.349523, "oz" to 28.349523
    )

    private val volumeToLiters = mapOf(
        "ml" to 0.001, "millilitre" to 0.001, "millilitres" to 0.001,
        "cl" to 0.01, "centilitre" to 0.01, "centilitres" to 0.01,
        "l" to 1.0, "litre" to 1.0, "litres" to 1.0,
        "gallon" to 3.785412, "gallons" to 3.785412,
        "pinte" to 0.473176, "pintes" to 0.473176
    )

    private val conversionPattern = Regex(
        "convert(?:is|ir)?\\s+([0-9]+(?:[.,][0-9]+)?)\\s*([a-zà-ÿ°]+)\\s+en\\s+([a-zà-ÿ°]+)|" +
            "([0-9]+(?:[.,][0-9]+)?)\\s*([a-zà-ÿ°]+)\\s+en\\s+([a-zà-ÿ°]+)\\b",
        RegexOption.IGNORE_CASE
    )

    private val celsiusNames = setOf("c", "celsius", "°c")
    private val fahrenheitNames = setOf("f", "fahrenheit", "°f")
    private val kelvinNames = setOf("k", "kelvin")

    /** Tente une conversion d'unité dans [text]. Retourne une phrase de résultat, ou null si non applicable. */
    fun tryConvert(text: String): String? {
        val m = conversionPattern.find(text.lowercase()) ?: return null
        val rawValue = m.groupValues[1].ifEmpty { m.groupValues[4] }
        val fromUnit = (m.groupValues[2].ifEmpty { m.groupValues[5] }).trim()
        val toUnit = (m.groupValues[3].ifEmpty { m.groupValues[6] }).trim()
        val value = rawValue.replace(',', '.').toDoubleOrNull() ?: return null

        temperatureResult(value, fromUnit, toUnit)?.let { return it }

        val table = when {
            fromUnit in lengthToMeters && toUnit in lengthToMeters -> lengthToMeters
            fromUnit in massToGrams && toUnit in massToGrams -> massToGrams
            fromUnit in volumeToLiters && toUnit in volumeToLiters -> volumeToLiters
            else -> return null
        }
        val fromFactor = table[fromUnit] ?: return null
        val toFactor = table[toUnit] ?: return null
        val result = value * fromFactor / toFactor
        return "${trimNumber(value)} $fromUnit = ${trimNumber(result)} $toUnit"
    }

    private fun temperatureResult(value: Double, fromUnit: String, toUnit: String): String? {
        if (fromUnit !in celsiusNames && fromUnit !in fahrenheitNames && fromUnit !in kelvinNames) return null
        if (toUnit !in celsiusNames && toUnit !in fahrenheitNames && toUnit !in kelvinNames) return null

        val celsius = when {
            fromUnit in celsiusNames -> value
            fromUnit in fahrenheitNames -> (value - 32) * 5.0 / 9.0
            else -> value - 273.15
        }
        val result = when {
            toUnit in celsiusNames -> celsius
            toUnit in fahrenheitNames -> celsius * 9.0 / 5.0 + 32
            else -> celsius + 273.15
        }
        return "${trimNumber(value)} $fromUnit = ${trimNumber(result)} $toUnit"
    }

    private fun trimNumber(v: Double): String {
        val rounded = Math.round(v * 1000) / 1000.0
        val s = if (rounded == rounded.toLong().toDouble()) rounded.toLong().toString() else rounded.toString()
        return s.replace('.', ',')
    }

    // -----------------------------------------------------------------
    // Calcul de dates
    // -----------------------------------------------------------------

    private val daysBetweenPattern = Regex(
        "combien\\s+de\\s+jours?\\s+(?:y\\s+a[- ]t[- ]il\\s+)?(?:entre|du|depuis)\\s+(.+?)\\s+et\\s+(.+)",
        RegexOption.IGNORE_CASE
    )
    private val dateFormats = listOf("dd/MM/yyyy", "dd-MM-yyyy", "d MMMM yyyy", "d MMM yyyy")

    /** Tente de calculer le nombre de jours entre deux dates données dans [text]. */
    fun tryDaysBetween(text: String): String? {
        val m = daysBetweenPattern.find(text) ?: return null
        val d1 = parseDate(m.groupValues[1].trim()) ?: return null
        val d2 = parseDate(m.groupValues[2].trim().trimEnd('?', '.', ' ')) ?: return null
        val diffDays = abs((d2.time - d1.time) / (1000L * 60 * 60 * 24))
        return "Il y a $diffDays jour(s) entre ces deux dates."
    }

    private fun parseDate(raw: String): java.util.Date? {
        for (fmt in dateFormats) {
            try {
                val sdf = SimpleDateFormat(fmt, Locale.FRANCE)
                sdf.isLenient = false
                return sdf.parse(raw)
            } catch (_: Exception) {
                // On essaie le format suivant.
            }
        }
        return null
    }
}
