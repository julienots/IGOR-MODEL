package com.igor.assistant

import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Mémoire à long terme d'IGOR.
 *
 * Ceci n'entraîne pas et ne modifie jamais les poids du modèle : « faire progresser »
 * un modèle de plusieurs milliards de paramètres directement sur un téléphone n'est pas
 * réaliste. Ce qui fonctionne bien à la place, et que fait cette classe : IGOR se
 * souvient, d'une conversation à l'autre, de ce que l'utilisateur lui a dit ou demandé
 * de retenir, et réinjecte ce contexte dans ses réponses futures. Tout reste local et
 * privé : rien de ceci ne quitte le téléphone.
 *
 * Ce qui est enregistré : les demandes explicites (« retiens que… ») et les faits que
 * l'utilisateur donne spontanément sur lui (prénom, ville, métier, goûts…). Les
 * réponses d'IGOR ne sont plus mémorisées : elles peuvent contenir des erreurs, et les
 * réinjecter plus tard contaminerait les réponses suivantes.
 *
 * Format de stockage : un fichier JSON Lines (`igor_memory.jsonl`) dans le stockage
 * privé de l'application, un souvenir par ligne : { "date": ..., "text": ... }.
 */
class MemoryStore(private val storageDir: File) {

    private val file = File(storageDir, "igor_memory.jsonl")
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)

    data class Memory(val date: String, val text: String)

    /** Ajoute un souvenir. [text] doit déjà être formulé de façon autonome (compréhensible hors contexte). */
    @Synchronized
    fun remember(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val entry = JSONObject().apply {
            put("date", dateFormat.format(Date()))
            put("text", clean)
        }
        file.appendText(entry.toString() + "\n")
        trimIfTooLarge()
    }

    /** Ajoute un souvenir seulement s'il n'existe pas déjà (comparaison sans accents ni casse). */
    @Synchronized
    fun rememberIfNew(text: String): Boolean {
        val clean = text.trim()
        if (clean.isEmpty()) return false
        val norm = Lexicon.normalize(clean)
        if (all().any { Lexicon.normalize(it.text) == norm }) return false
        remember(clean)
        return true
    }

    /** Retourne tous les souvenirs, du plus récent au plus ancien. */
    @Synchronized
    fun all(): List<Memory> {
        if (!file.exists()) return emptyList()
        return file.readLines()
            .filter { it.isNotBlank() }
            .mapNotNull { line ->
                try {
                    val obj = JSONObject(line)
                    Memory(obj.getString("date"), obj.getString("text"))
                } catch (_: Exception) {
                    null
                }
            }
            .reversed()
    }

    /** Supprime tous les souvenirs. */
    @Synchronized
    fun clear() {
        if (file.exists()) file.delete()
    }

    /**
     * Retourne jusqu'à [limit] souvenirs jugés pertinents pour [query] : ceux qui
     * partagent des mots-clés avec la question (racines de mots, sans accents), plus
     * les faits de base sur l'utilisateur (prénom, ville…) qui servent presque toujours.
     * Les anciennes entrées « Question : … Réponse : … » (issues d'une version
     * précédente) ne sont plus réinjectées.
     */
    @Synchronized
    fun relevant(query: String, limit: Int = 4): List<String> {
        val memories = all().filter { !it.text.startsWith("Question :") }
        if (memories.isEmpty()) return emptyList()
        val q = Lexicon.keywordSet(query)

        val matched = if (q.isEmpty()) {
            emptyList()
        } else {
            memories
                .map { it to Lexicon.keywordSet(it.text).intersect(q).size }
                .filter { it.second > 0 }
                .sortedByDescending { it.second }
                .map { it.first }
        }
        val profile = memories.filter { it.text.startsWith("L'utilisateur") }.take(2)
        return (matched + profile).distinctBy { it.text }.take(limit).map { it.text }
    }

    /** Garde le fichier raisonnable (les 500 derniers souvenirs) pour ne jamais grossir indéfiniment. */
    private fun trimIfTooLarge(maxEntries: Int = 500) {
        val lines = file.readLines()
        if (lines.size > maxEntries) {
            file.writeText(lines.takeLast(maxEntries).joinToString("\n") + "\n")
        }
    }

    companion object {
        /**
         * Détecte une demande explicite de mémorisation (« retiens que… »,
         * « souviens-toi que… », « n'oublie pas que… »). Retourne le fait à retenir
         * (texte nettoyé) si le message en est une, sinon null.
         */
        private val memorizeCommand = Regex(
            "^(retiens|souviens[- ]toi|n'oublie pas|note)\\s+(que|:)?\\s*",
            RegexOption.IGNORE_CASE
        )

        fun extractExplicitMemory(raw: String): String? {
            val trimmed = raw.trim().replace('’', '\'')
            if (!memorizeCommand.containsMatchIn(trimmed)) return null
            val fact = memorizeCommand.replace(trimmed, "").trim()
            return fact.ifEmpty { null }
        }

        private val ci = RegexOption.IGNORE_CASE

        private val factPatterns: List<Pair<Regex, (MatchResult) -> String>> = listOf(
            Regex("\\bje m'appelle\\s+([\\p{L}][\\p{L}'\\- ]{0,30}?)(?=[.,;!?\\n]|\\s+et\\b|$)", ci) to
                { m: MatchResult -> "L'utilisateur s'appelle ${m.groupValues[1].trim()}" },
            Regex("\\b(?:j'habite|je vis)\\s+((?:à|en|au|aux|dans)\\s+[^.,;!?\\n]{2,40})", ci) to
                { m: MatchResult -> "L'utilisateur habite ${m.groupValues[1].trim()}" },
            Regex("\\bj'ai\\s+(\\d{1,3})\\s+ans\\b", ci) to
                { m: MatchResult -> "L'utilisateur a ${m.groupValues[1]} ans" },
            Regex("\\bje travaille\\s+((?:comme|en tant que|chez|dans|à)\\s+[^.,;!?\\n]{2,40})", ci) to
                { m: MatchResult -> "L'utilisateur travaille ${m.groupValues[1].trim()}" },
            Regex("\\bj'(?:aime|adore)\\s+(?!(?:pas|plus|jamais)\\b)(?:bien\\s+)?([^.,;!?\\n]{2,40})", ci) to
                { m: MatchResult -> "L'utilisateur aime ${m.groupValues[1].trim()}" },
            Regex("\\bje préfère\\s+([^.,;!?\\n]{2,40})", ci) to
                { m: MatchResult -> "L'utilisateur préfère ${m.groupValues[1].trim()}" }
        )

        /**
         * Repère les faits simples que l'utilisateur donne sur lui-même (« je m'appelle
         * Léa », « j'habite à Lyon »…) pour les retenir sans qu'il ait à le demander.
         * Volontairement prudent : seulement des tournures très claires, jamais sur une question.
         */
        fun extractPersonalFacts(raw: String): List<String> {
            val text = raw.trim().replace('’', '\'')
            if (text.contains('?')) return emptyList()
            return factPatterns.mapNotNull { (regex, build) ->
                regex.find(text)?.let { build(it) }?.takeIf { it.length <= 90 }
            }
        }
    }
}
