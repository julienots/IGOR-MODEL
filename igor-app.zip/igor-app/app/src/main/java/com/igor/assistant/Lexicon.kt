package com.igor.assistant

import java.text.Normalizer

/**
 * Outils de texte partagés par la mémoire et la lecture de documents : normalisation
 * (minuscules, sans accents), extraction de mots-clés et racinisation grossière
 * (6 premières lettres, pluriels retirés) pour que « fichiers » et « fichier »
 * se retrouvent, sans aucune dépendance externe.
 */
object Lexicon {

    private val accents = Regex("\\p{M}+")
    private val splitter = Regex("[^\\p{L}\\p{N}]+")

    private val stopWords = setOf(
        "les", "une", "des", "aux", "elle", "nous", "vous", "ils", "elles", "est", "suis", "sont",
        "que", "qui", "quoi", "pour", "avec", "sur", "dans", "cet", "cette", "ces", "mon", "mes",
        "ton", "tes", "son", "ses", "pas", "plus", "tres", "bien", "mais", "donc", "car", "comme",
        "par", "ete", "etre", "avoir", "ont", "fait", "faire", "peut", "peux", "veux", "dit", "dis",
        "moi", "toi", "lui", "leur", "leurs", "sans", "sous", "entre", "vers", "chez", "tout",
        "tous", "toute", "toutes", "aussi", "alors", "quel", "quelle", "quels", "quelles",
        "comment", "pourquoi", "quand", "combien", "fichier", "fichiers", "document", "documents",
        "texte", "pdf", "resume", "resumer", "explique", "donne", "parle", "parler", "dire",
        "the", "and", "can", "you", "please", "stp", "svp"
    )

    /** Minuscules + suppression des accents. */
    fun normalize(text: String): String =
        accents.replace(Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD), "")

    /** Mots significatifs (sans mots vides), ramenés à une racine grossière. */
    fun keywords(text: String): List<String> =
        normalize(text)
            .split(splitter)
            .filter { it.length > 2 && it !in stopWords }
            .map { stem(it) }

    fun keywordSet(text: String): Set<String> = keywords(text).toSet()

    private fun stem(word: String): String = word.trimEnd('s', 'x').take(6)
}
