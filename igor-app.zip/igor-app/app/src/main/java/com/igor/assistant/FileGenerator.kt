package com.igor.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class GeneratedFormat { TXT, MD, PDF }

data class GeneratedFile(val file: File, val format: GeneratedFormat)

/**
 * Permet à IGOR de produire de vrais fichiers téléchargeables (texte, Markdown ou PDF)
 * à partir de sa réponse, et de les proposer à l'ouverture ou au partage. Tout reste
 * local à l'appli (dossier privé, exposé via [FileProvider]) : aucune dépendance
 * externe n'est ajoutée — la génération de PDF utilise l'API `android.graphics.pdf`
 * fournie nativement par Android.
 */
object FileGenerator {

    /**
     * Détecte une demande explicite de fichier (« génère un fichier », « exporte en PDF »…).
     * Le nom du fichier doit être introduit par « un / une / en / au format / sous forme de » :
     * « fais-moi un résumé de ce document » (où le document est la source, pas le résultat)
     * ne déclenche donc pas la création d'un fichier.
     */
    private val explicitRequest = Regex(
        "\\b(g[ée]n[èe]re(?:r|s|-moi)?|cr[ée]e(?:r|-moi)?|fais(?:-moi)?|sauvegarde(?:r|-moi)?|" +
            "enregistre(?:r|-moi)?|exporte(?:r|-moi)?|mets\\s+[cç]a\\s+dans|t[ée]l[ée]charge(?:r|-moi)?)" +
            "\\b.{0,60}?\\b(?:un|une|en|au\\s+format|sous\\s+forme\\s+de)\\s+(?:nouveau\\s+|nouvelle\\s+)?" +
            "(?:fichier|document|note|pdf|texte|markdown|\\.txt|\\.md|\\.pdf)",
        RegexOption.IGNORE_CASE
    )

    fun isFileRequest(text: String): Boolean = explicitRequest.containsMatchIn(text)

    fun detectFormat(text: String): GeneratedFormat {
        val lower = text.lowercase()
        return when {
            lower.contains("pdf") -> GeneratedFormat.PDF
            lower.contains(".md") || lower.contains("markdown") -> GeneratedFormat.MD
            else -> GeneratedFormat.TXT
        }
    }

    /** Dossier privé de l'appli (aucune permission de stockage requise), exposé via FileProvider. */
    private fun outputDir(context: Context): File {
        val dir = File(context.filesDir, "fichiers_igor")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun generate(context: Context, content: String, format: GeneratedFormat, titleHint: String): GeneratedFile {
        val dir = outputDir(context)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.FRANCE).format(Date())
        val safeName = titleHint
            .lowercase()
            .replace(Regex("[^a-z0-9À-ÿ]+"), "_")
            .trim('_')
            .ifEmpty { "note" }
            .take(40)

        return when (format) {
            GeneratedFormat.TXT -> {
                val f = File(dir, "${safeName}_$stamp.txt")
                f.writeText(content)
                GeneratedFile(f, format)
            }
            GeneratedFormat.MD -> {
                val f = File(dir, "${safeName}_$stamp.md")
                f.writeText(content)
                GeneratedFile(f, format)
            }
            GeneratedFormat.PDF -> {
                val f = File(dir, "${safeName}_$stamp.pdf")
                writePdf(f, content)
                GeneratedFile(f, format)
            }
        }
    }

    private class PdfLine(val text: String, val paint: Paint, val gapBefore: Float)

    private val headingLine = Regex("^(#{1,4})\\s+(.*)$")
    private val bulletLine = Regex("^\\s*[-*•]\\s+(.*)$")

    private fun stripInlineMarkdown(s: String): String =
        s.replace("**", "").replace("__", "").replace("`", "")

    /**
     * Génère un PDF paginé avec l'API PdfDocument native d'Android. Le Markdown de la
     * réponse est respecté : titres (#) plus grands et en gras, puces (•), et les
     * marques **gras** / `code` sont retirées au lieu d'apparaître telles quelles.
     */
    private fun writePdf(file: File, content: String) {
        val pageWidth = 595   // A4 à 72dpi
        val pageHeight = 842
        val margin = 40f
        val maxWidth = pageWidth - margin * 2

        val body = Paint().apply { textSize = 12f; isAntiAlias = true }
        val h1 = Paint(body).apply { textSize = 20f; isFakeBoldText = true }
        val h2 = Paint(body).apply { textSize = 16f; isFakeBoldText = true }
        val h3 = Paint(body).apply { textSize = 13.5f; isFakeBoldText = true }

        // Découpe chaque ligne de texte en lignes qui tiennent dans la largeur de la page.
        val lines = mutableListOf<PdfLine>()
        var inCode = false
        for (raw in content.split("\n")) {
            if (raw.trimStart().startsWith("```")) {
                inCode = !inCode
                continue
            }
            var paint = body
            var gap = 0f
            var text = raw.trimEnd()
            if (!inCode) {
                val heading = headingLine.matchEntire(text)
                val bullet = bulletLine.matchEntire(text)
                if (heading != null) {
                    paint = when (heading.groupValues[1].length) { 1 -> h1; 2 -> h2; else -> h3 }
                    gap = 8f
                    text = heading.groupValues[2]
                } else if (bullet != null) {
                    text = "• " + bullet.groupValues[1]
                }
                text = stripInlineMarkdown(text)
            }
            if (text.isBlank()) {
                lines.add(PdfLine("", body, gap))
                continue
            }
            var current = StringBuilder()
            var first = true
            for (word in text.split(Regex("\\s+"))) {
                val candidate = if (current.isEmpty()) word else "$current $word"
                if (paint.measureText(candidate) > maxWidth && current.isNotEmpty()) {
                    lines.add(PdfLine(current.toString(), paint, if (first) gap else 0f))
                    first = false
                    current = StringBuilder(word)
                } else {
                    current = StringBuilder(candidate)
                }
            }
            if (current.isNotEmpty()) lines.add(PdfLine(current.toString(), paint, if (first) gap else 0f))
        }

        val doc = PdfDocument()
        var pageNumber = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        var canvas: Canvas = page.canvas
        var y = margin
        for (line in lines) {
            val lh = line.paint.fontSpacing
            if (y + line.gapBefore + lh > pageHeight - margin && y > margin) {
                doc.finishPage(page)
                pageNumber++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                canvas = page.canvas
                y = margin
            }
            y += line.gapBefore + lh
            canvas.drawText(line.text, margin, y, line.paint)
        }
        doc.finishPage(page)

        file.outputStream().use { doc.writeTo(it) }
        doc.close()
    }

    fun shareIntent(context: Context, file: File): Intent {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        return Intent(Intent.ACTION_SEND).apply {
            type = mimeType(file)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun viewIntent(context: Context, file: File): Intent {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType(file))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun listGenerated(context: Context): List<File> =
        outputDir(context).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun delete(file: File): Boolean = file.delete()

    fun mimeType(file: File): String = when (file.extension.lowercase()) {
        "pdf" -> "application/pdf"
        "md" -> "text/markdown"
        else -> "text/plain"
    }
}
