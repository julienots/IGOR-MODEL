package com.igor.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class GeneratedFormat { TXT, MD, PDF }

data class GeneratedFile(val file: File, val format: GeneratedFormat)

/**
 * Permet à IGOR de produire de vrais fichiers téléchargeables (texte, Markdown ou PDF)
 * à partir de sa réponse, et de les proposer à l'ouverture ou au partage. Tout reste
 * local à l'appli (dossier privé, exposé via [FileProvider]) : aucune dépendance
 * externe n'est ajoutée — la génération de PDF utilise l'API `android.graphics.pdf`
 * fournie nativement par Android.
 */
object FileGenerator {

    /** Détecte une demande explicite de fichier ("génère un fichier", "exporte en PDF", etc.). */
    private val explicitRequest = Regex(
        "\\b(g[ée]n[èe]re(?:r|s|-moi)?|cr[ée]e(?:r|-moi)?|fais(?:-moi)?|sauvegarde(?:r|-moi)?|" +
            "enregistre(?:r|-moi)?|exporte(?:r|-moi)?|mets\\s+[cç]a\\s+dans|t[ée]l[ée]charge(?:r|-moi)?)" +
            "\\b.{0,40}?\\b(fichier|document|note|pdf|texte|markdown|\\.txt|\\.md|\\.pdf)\\b",
        RegexOption.IGNORE_CASE
    )

    fun isFileRequest(text: String): Boolean = explicitRequest.containsMatchIn(text)

    fun detectFormat(text: String): GeneratedFormat {
        val lower = text.lowercase()
        return when {
            lower.contains("pdf") -> GeneratedFormat.PDF
            lower.contains(".md") || lower.contains("markdown") -> GeneratedFormat.MD
            else -> GeneratedFormat.TXT
        }
    }

    /** Dossier privé de l'appli (aucune permission de stockage requise), exposé via FileProvider. */
    private fun outputDir(context: Context): File {
        val dir = File(context.filesDir, "fichiers_igor")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun generate(context: Context, content: String, format: GeneratedFormat, titleHint: String): GeneratedFile {
        val dir = outputDir(context)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.FRANCE).format(Date())
        val safeName = titleHint
            .lowercase()
            .replace(Regex("[^a-z0-9À-ÿ]+"), "_")
            .trim('_')
            .ifEmpty { "note" }
            .take(40)

        return when (format) {
            GeneratedFormat.TXT -> {
                val f = File(dir, "${safeName}_$stamp.txt")
                f.writeText(content)
                GeneratedFile(f, format)
            }
            GeneratedFormat.MD -> {
                val f = File(dir, "${safeName}_$stamp.md")
                f.writeText(content)
                GeneratedFile(f, format)
            }
            GeneratedFormat.PDF -> {
                val f = File(dir, "${safeName}_$stamp.pdf")
                writePdf(f, content)
                GeneratedFile(f, format)
            }
        }
    }

    /** Génère un PDF texte simple, paginé, avec l'API PdfDocument native d'Android. */
    private fun writePdf(file: File, content: String) {
        val pageWidth = 595   // A4 à 72dpi
        val pageHeight = 842
        val margin = 40f
        val paint = Paint().apply { textSize = 12f; isAntiAlias = true }
        val lineHeight = paint.fontSpacing
        val maxWidth = pageWidth - margin * 2

        // Découpe le texte (en respectant les sauts de ligne existants) en lignes qui
        // tiennent dans la largeur de la page.
        val lines = mutableListOf<String>()
        for (paragraph in content.split("\n")) {
            if (paragraph.isBlank()) {
                lines.add("")
                continue
            }
            var current = StringBuilder()
            for (word in paragraph.split(Regex("\\s+"))) {
                val candidate = if (current.isEmpty()) word else "$current $word"
                if (paint.measureText(candidate) > maxWidth && current.isNotEmpty()) {
                    lines.add(current.toString())
                    current = StringBuilder(word)
                } else {
                    current = StringBuilder(candidate)
                }
            }
            if (current.isNotEmpty()) lines.add(current.toString())
        }

        val doc = PdfDocument()
        val linesPerPage = ((pageHeight - margin * 2) / lineHeight).toInt().coerceAtLeast(1)
        var pageNumber = 1
        var index = 0
        do {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            val page = doc.startPage(pageInfo)
            val canvas: Canvas = page.canvas
            var y = margin + lineHeight
            var linesOnPage = 0
            while (index < lines.size && linesOnPage < linesPerPage) {
                canvas.drawText(lines[index], margin, y, paint)
                y += lineHeight
                index++
                linesOnPage++
            }
            doc.finishPage(page)
            pageNumber++
        } while (index < lines.size)

        file.outputStream().use { doc.writeTo(it) }
        doc.close()
    }

    fun shareIntent(context: Context, file: File): Intent {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        return Intent(Intent.ACTION_SEND).apply {
            type = mimeType(file)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun viewIntent(context: Context, file: File): Intent {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType(file))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun listGenerated(context: Context): List<File> =
        outputDir(context).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun delete(file: File): Boolean = file.delete()

    fun mimeType(file: File): String = when (file.extension.lowercase()) {
        "pdf" -> "application/pdf"
        "md" -> "text/markdown"
        else -> "text/plain"
    }
}
