package com.igor.assistant

import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.flow.collect
import java.io.File

/**
 * Enveloppe autour du moteur LiteRT-LM (com.google.ai.edge.litertlm), le framework
 * d'inférence sur appareil de Google. Le modèle (.litertlm) tourne entièrement en
 * local, sans réseau, une fois chargé : IGOR ne dépend d'aucun serveur pour générer
 * ses réponses.
 *
 * Modèle attendu : **Qwen3-1.7B** au format .litertlm, tel que publié par Google sur
 * huggingface.co/litert-community/Qwen3-1.7B (fichier `Qwen3_1.7B.litertlm`, ~2,1 Go).
 * L'API Engine -> Conversation -> sendMessageAsync est la même que pour Gemma : seul
 * le fichier modèle change, rien d'autre à adapter côté LiteRT-LM.
 *
 * Particularité de Qwen3 : la famille est entraînée avec un mode de "raisonnement"
 * (chain-of-thought) qui peut s'afficher entre des balises <think>...</think> avant
 * la réponse finale. Pour un assistant de chat, on ne veut pas exposer ce brouillon :
 * on demande donc explicitement au modèle de ne pas raisonner à voix haute (suffixe
 * `/no_think`, reconnu par Qwen3) et, par sécurité, on filtre quand même toute balise
 * <think> qui subsisterait dans la sortie (voir [stripThinking]).
 *
 * Remarque : l'API Kotlin de LiteRT-LM évolue encore rapidement (bibliothèque en
 * développement actif). Si une méthode ci-dessous ne correspond plus exactement à
 * la version publiée sur Google Maven au moment du build, consulte le KDoc généré
 * par Android Studio sur la classe Engine / Conversation — la forme générale
 * (Engine -> initialize -> createConversation -> sendMessageAsync) est stable.
 */
class LlmEngineManager {

    private var engine: Engine? = null
    private var conversation: Conversation? = null

    @Volatile
    var isReady: Boolean = false
        private set

    private val persona = """
        Tu es IGOR, une intelligence artificielle conversationnelle qui fonctionne
        entièrement hors ligne, embarquée dans une application mobile (modèle Qwen3
        1,7 milliard de paramètres). Tu réponds toujours en français, avec des
        phrases naturelles et variées que tu construis toi-même. Ton style est
        chaleureux et clair. Ne montre jamais ton raisonnement intermédiaire, ne
        produis aucune balise <think> : donne directement ta réponse finale. /no_think

        Comme tu es un petit modèle embarqué, tes connaissances internes sont
        limitées et potentiellement datées. Sois honnête sur ce que tu sais vraiment :
        si une question porte sur un fait précis, récent ou de niche que tu n'es pas
        certain de connaître, dis-le clairement plutôt que d'inventer une réponse
        plausible. Une réponse courte et exacte vaut toujours mieux qu'une réponse
        détaillée mais fausse.

        Certains messages contiennent des balises invisibles pour l'utilisateur qui
        te donnent du contexte fiable :
        - [CALCUL_EXACT: expression = valeur] : ce résultat a déjà été calculé par un
          moteur exact, annonce-le tel quel, sans le recalculer.
        - [CONVERSION_EXACTE: ...] : une conversion d'unité ou un calcul de dates a
          déjà été fait par un moteur exact (pas par toi) — annonce ce résultat tel
          quel, ne recalcule jamais un facteur de conversion ou un nombre de jours
          de tête, tu te tromperais.
        - [MEMOIRE: ...] : des éléments que tu as retenus de conversations
          précédentes avec cet utilisateur. Utilise-les seulement s'ils sont
          pertinents pour la question posée.
        - [RECHERCHE_WEB_OK (N sources) : ...] : une recherche internet vient
          réellement d'être effectuée (météo, Wikipédia ou moteur de recherche
          généraliste selon la question) et a trouvé N sources, chacune avec son
          titre, un extrait du contenu réel de la page, et son URL entre crochets.
          Fonde ta réponse sur ces extraits, reprends les faits précis qu'ils
          donnent (noms, chiffres, dates), et indique à l'utilisateur que
          l'information vient d'une recherche récente. Si les sources se
          contredisent ou restent vagues sur un point, dis-le plutôt que de
          trancher au hasard.
        - [RECHERCHE_WEB_ECHEC (raison)] : une recherche internet vient réellement
          d'être tentée mais n'a RIEN trouvé d'exploitable (pas de réseau, service
          indisponible, ou aucun résultat pertinent). Dans ce cas précis, tu DOIS dire
          clairement et simplement à l'utilisateur que ta recherche n'a rien donné et
          que tu ne peux pas confirmer l'information. Il est interdit de prétendre
          avoir trouvé une réponse ou d'inventer un résultat quand cette balise est
          présente : mieux vaut admettre l'échec que donner une fausse information.
        - [DEMANDE_FICHIER] : l'utilisateur veut que ta réponse devienne un fichier
          téléchargeable (texte, Markdown ou PDF selon ce qu'il a précisé). Dans ce
          cas, écris DIRECTEMENT le contenu final destiné au fichier : pas de
          formule d'introduction ("Voici...", "Bien sûr..."), pas de commentaire sur
          le fait que tu vas créer un fichier — l'application s'en charge déjà après
          ta réponse. Structure le texte avec des titres et des listes si c'est
          pertinent pour le sujet.
    """.trimIndent()

    suspend fun initialize(modelFile: File) {
        close()
        val config = EngineConfig(modelPath = modelFile.absolutePath)
        val eng = Engine(config)
        eng.initialize()
        val conv = eng.createConversation()
        engine = eng
        conversation = conv
        isReady = true

        // Amorce silencieuse : on établit la personnalité d'IGOR sans afficher la réponse.
        try {
            conv.sendMessageAsync(persona).collect { /* réponse d'amorçage ignorée */ }
        } catch (_: Exception) {
            // Si l'amorçage échoue, IGOR répondra quand même, juste sans ce cadrage initial.
        }
    }

    /**
     * Envoie [prompt] au modèle et appelle [onChunk] à chaque fragment de texte reçu,
     * déjà nettoyé de tout raisonnement caché (le flux d'IGOR se construit token après
     * token). Retourne le texte complet final, également nettoyé.
     */
    suspend fun ask(prompt: String, onChunk: (String) -> Unit): String {
        val conv = conversation ?: throw IllegalStateException("Le modèle n'est pas encore chargé")
        val builder = StringBuilder()
        conv.sendMessageAsync("$prompt /no_think").collect { fragment ->
            builder.append(fragment)
            onChunk(stripThinking(builder.toString()))
        }
        return stripThinking(builder.toString())
    }

    fun close() {
        try { conversation?.close() } catch (_: Exception) {}
        try { engine?.close() } catch (_: Exception) {}
        conversation = null
        engine = null
        isReady = false
    }

    companion object {
        private val thinkBlock = Regex("(?s)<think>.*?</think>")
        private val danglingThinkOpen = Regex("(?s)<think>.*$")

        /**
         * Retire tout bloc <think>...</think> complet, ainsi qu'un éventuel <think>
         * resté ouvert en cours de streaming (on masque le brouillon jusqu'à ce que
         * la balise fermante arrive, ou définitivement si elle n'arrive jamais).
         */
        fun stripThinking(text: String): String {
            val withoutClosed = thinkBlock.replace(text, "")
            return danglingThinkOpen.replace(withoutClosed, "").trim()
        }
    }
}
