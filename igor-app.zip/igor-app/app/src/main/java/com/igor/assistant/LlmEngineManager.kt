package com.igor.assistant

import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File

/**
 * Enveloppe autour du moteur LiteRT-LM (com.google.ai.edge.litertlm), le framework
 * d'inférence sur appareil de Google. Le modèle (.litertlm) tourne entièrement en
 * local, sans réseau, une fois chargé : IGOR ne dépend d'aucun serveur pour générer
 * ses réponses.
 *
 * Remarque : l'API Kotlin de LiteRT-LM évolue encore rapidement (bibliothèque en
 * développement actif). Si une méthode ci-dessous ne correspond plus exactement à
 * la version publiée sur Google Maven au moment du build, consulte le KDoc généré
 * par Android Studio sur la classe Engine / Conversation — la forme générale
 * (Engine -> initialize -> createConversation -> sendMessageAsync) est stable.
 */
class LlmEngineManager {

    private var engine: Engine? = null
    private var conversation: Conversation? = null

    @Volatile
    var isReady: Boolean = false
        private set

    private val persona = """
        Tu es IGOR, une intelligence artificielle conversationnelle. Quel que soit
        le modèle de langage qui te fait tourner (Gemma 3 4B, 1B, ou tout autre
        modèle .litertlm importé par l'utilisateur), tu gardes toujours la même
        personnalité et les mêmes règles ci-dessous. Tu réponds toujours en
        français.

        RÈGLE ABSOLUE — jamais de réponse générique : ne réponds jamais par une
        phrase creuse, un conseil passe-partout ou une formule toute faite qui
        pourrait s'appliquer à n'importe quelle question. Prends toujours le temps
        de vraiment traiter CETTE question précise, avec des éléments concrets,
        un raisonnement qui lui est propre, et si besoin des exemples ou des
        chiffres réels — jamais de généralités vagues pour remplir l'espace.

        TON — sérieux et amical à la fois : tu es fiable et précis, tu ne fais
        jamais semblant de savoir, et tu dis honnêtement quand tu n'es pas sûr
        plutôt que d'inventer. Mais tu restes chaleureux et naturel, jamais froid
        ni robotique — comme quelqu'un de compétent à qui on peut faire confiance.

        FORME — pensé pour être écouté autant que lu : écris en phrases complètes
        et fluides, sans symboles de mise en forme (pas d'astérisques, pas de
        dièses, pas de tirets de liste). Si tu dois énumérer plusieurs éléments,
        fais-le dans une phrase construite plutôt qu'en liste à puces, pour que ça
        reste agréable et clair à l'oreille comme à l'œil. Adapte la longueur de ta
        réponse à ce que la question mérite vraiment : développe quand c'est utile,
        reste concis quand une question est simple.

        CALCUL — si un message contient une balise [CALCUL_EXACT: expression =
        valeur], cette valeur a déjà été calculée par un moteur exact : annonce-la
        telle quelle, sans la recalculer, dans une phrase naturelle.

        RECHERCHE INTERNET — si un message contient une balise [RECHERCHE_WEB ...]
        suivie de résultats de recherche, appuie-toi sur ces résultats pour
        répondre de façon concrète et à jour : reformule les informations utiles
        avec tes propres mots, cite la source par son nom quand c'est utile (par
        exemple "d'après tel site"), mais ne lis jamais une adresse internet à
        voix haute. Si les résultats sont vides, insuffisants ou hors sujet,
        dis-le clairement à l'utilisateur plutôt que d'inventer une réponse.
    """.trimIndent()

    /**
     * Paramètres de génération visant des réponses plus développées et plus
     * "intelligentes" : plus de tokens autorisés par réponse (les réponses ne
     * sont pas coupées court), une température modérée (cohérence sans être
     * robotique) et un tirage top-k/top-p qui laisse le modèle varier son
     * vocabulaire au lieu de répéter toujours les mêmes tournures.
     *
     * Dans la version actuelle de l'API LiteRT-LM, EngineConfig ne porte que le
     * chemin du modèle (et le backend) : température, top-k et top-p sont des
     * paramètres d'échantillonnage qui se règlent via SamplerConfig, transmis à
     * la conversation (ConversationConfig), pas au moteur. Il n'y a pas de champ
     * "maxTokens" équivalent à ce niveau — la longueur de réponse se limite plutôt
     * au moment de l'envoi du message si besoin.
     */
    suspend fun initialize(modelFile: File) {
        close()
        val config = EngineConfig(modelPath = modelFile.absolutePath)
        val eng = Engine(config)
        eng.initialize()
        val conversationConfig = ConversationConfig(
            samplerConfig = SamplerConfig(topK = 40, topP = 0.9, temperature = 0.75)
        )
        val conv = eng.createConversation(conversationConfig)
        engine = eng
        conversation = conv
        isReady = true

        // Amorce silencieuse : on établit la personnalité d'IGOR sans afficher la réponse.
        // Plafonnée à 25s : sur un téléphone sans accélération NPU (CPU seul), un modèle
        // en mode "thinking" peut générer un raisonnement interne très long avant de
        // répondre, ce qui bloquait l'écran de chargement indéfiniment. Passé ce délai,
        // on abandonne l'amorçage (IGOR répondra quand même, juste sans ce cadrage initial)
        // plutôt que de laisser l'utilisateur bloqué sur "Chargement du modèle...".
        try {
            withTimeoutOrNull(25_000) {
                conv.sendMessageAsync(persona).collect { /* réponse d'amorçage ignorée */ }
            }
        } catch (_: Exception) {
            // Si l'amorçage échoue, IGOR répondra quand même, juste sans ce cadrage initial.
        }
    }

    /**
     * Envoie [prompt] au modèle et appelle [onChunk] à chaque fragment de texte reçu
     * (le flux d'IGOR se construit token après token). Retourne le texte complet final.
     */
    suspend fun ask(prompt: String, onChunk: (String) -> Unit): String {
        val conv = conversation ?: throw IllegalStateException("Le modèle n'est pas encore chargé")
        // Attention : chaque émission de sendMessageAsync contient le texte cumulé
        // depuis le début de la réponse, pas seulement le nouveau fragment. Il ne
        // faut donc pas faire builder.append(fragment) (le texte serait dupliqué),
        // juste renvoyer la dernière valeur reçue telle quelle.
        var latest = ""
        conv.sendMessageAsync(prompt).collect { fragment ->
            latest = fragment.toString()
            onChunk(latest)
        }
        return latest
    }

    fun close() {
        try { conversation?.close() } catch (_: Exception) {}
        try { engine?.close() } catch (_: Exception) {}
        conversation = null
        engine = null
        isReady = false
    }
}
