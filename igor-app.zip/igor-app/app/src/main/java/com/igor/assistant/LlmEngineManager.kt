package com.igor.assistant

import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

/**
 * Enveloppe autour du moteur LiteRT-LM (com.google.ai.edge.litertlm), le framework
 * d'inférence sur appareil de Google. Le modèle (.litertlm) tourne entièrement en
 * local, sans réseau, une fois chargé : IGOR ne dépend d'aucun serveur pour générer
 * ses réponses.
 *
 * Modèles conseillés : Gemma3-4B-IT (meilleure qualité) ou Qwen3-1.7B (plus léger),
 * publiés par Google sur huggingface.co/litert-community. L'API
 * Engine -> Conversation -> sendMessageAsync est la même pour tous : seul le fichier
 * modèle change.
 *
 * Gestion du contexte : un petit modèle embarqué n'a qu'une fenêtre de contexte de
 * quelques milliers de tokens. Cette classe suit donc la quantité de texte déjà envoyée
 * dans la conversation et, avant que la fenêtre ne déborde (ou après une interruption),
 * repart d'une conversation neuve en réinjectant la personnalité d'IGOR et un court
 * rappel des derniers échanges. Sans cela, IGOR finissait par planter ou par « oublier »
 * ses consignes au bout de quelques messages.
 *
 * Particularité de Qwen3 : la famille produit parfois un raisonnement entre balises
 * <think>...</think>. On le désactive (suffixe `/no_think`, uniquement pour Qwen) et on
 * filtre de toute façon ces balises ([stripThinking]) : la « réflexion » affichée par
 * IGOR est produite par une étape dédiée, contrôlée par l'application.
 */
class LlmEngineManager {

    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private val lock = Mutex()

    @Volatile
    var isReady: Boolean = false
        private set

    private var isQwen = false
    private var usedChars = 0
    private var dirty = false

    private val persona = """
        Tu es IGOR, un assistant personnel intelligent qui tourne entièrement sur le téléphone de l'utilisateur (modèle embarqué, sans serveur). Tu réponds en français, sauf si l'utilisateur écrit dans une autre langue. Ton ton est chaleureux, direct et naturel.

        Ta façon de travailler :
        - Tu comprends d'abord ce que l'utilisateur veut vraiment, puis tu réponds précisément. Question simple : réponse courte. Question complexe : réponse structurée (étapes, listes, exemples).
        - Tu raisonnes avec rigueur, étape par étape, pour la logique, les problèmes, l'analyse de textes et de documents. Tu relis ton résultat avant de conclure.
        - Tu es honnête : si tu n'es pas sûr, ou si l'information te manque, tu le dis au lieu d'inventer. Une réponse courte et exacte vaut mieux qu'une réponse détaillée mais fausse. Tes connaissances internes sont limitées et peuvent être datées.
        - Si la demande est ambiguë, tu fais l'hypothèse la plus raisonnable en l'annonçant, ou tu poses une seule question de précision.
        - Tu peux utiliser un peu de Markdown (**gras**, listes à puces, titres, blocs de code) quand cela aide la lecture.

        Certains messages contiennent des balises invisibles pour l'utilisateur qui te donnent un contexte fiable :
        - [CALCUL_EXACT: expression = valeur] et [CONVERSION_EXACTE: ...] : résultat déjà calculé par un moteur exact. Annonce-le tel quel, ne le recalcule jamais de tête.
        - [MEMOIRE: ...] : éléments retenus lors de conversations précédentes avec cet utilisateur. Utilise-les seulement s'ils sont pertinents.
        - [DOCUMENTS_JOINTS: ...] : contenu réel de fichiers envoyés par l'utilisateur (extraits choisis ou résumé par parties). Appuie-toi dessus, cite le nom du fichier (et la page si elle est indiquée), n'invente rien qui n'y figure pas. Si les extraits ne contiennent pas la réponse, dis-le clairement. Tu sais lire ces fichiers : ne dis jamais le contraire.
        - [RECHERCHE_WEB_OK (N sources) : ...] : une vraie recherche internet vient d'être faite ; chaque source a un titre, un extrait et son URL entre crochets. Fonde ta réponse sur ces extraits, reprends les faits précis (noms, chiffres, dates) et précise que l'information vient d'une recherche récente. Si les sources se contredisent ou restent vagues, dis-le.
        - [RECHERCHE_WEB_ECHEC (raison)] : une recherche a été tentée mais n'a rien donné d'exploitable. Dis-le simplement à l'utilisateur et ne prétends jamais avoir trouvé une réponse.
        - [DEMANDE_FICHIER] : l'utilisateur veut que ta réponse devienne un fichier. Écris directement le contenu final, sans introduction (« Voici... ») ni commentaire sur le fichier : l'application le crée ensuite. Structure le texte avec des titres et des listes si c'est pertinent.
        - [ETAPE_REFLEXION] : écris seulement un court brouillon de réflexion (notes à la première personne), sans la réponse finale.
        - [ETAPE_REPONSE] : ta réflexion est faite ; écris maintenant la réponse finale, sans recopier le brouillon.
        - [HISTORIQUE_RECENT] : rappel des derniers échanges quand la conversation reprend ; sers-t'en comme contexte.
        Ne mentionne jamais ces balises à l'utilisateur.
    """.trimIndent()

    suspend fun initialize(modelFile: File, modelName: String? = null) {
        close()
        isQwen = modelName?.contains("qwen", ignoreCase = true) == true
        val config = EngineConfig(modelPath = modelFile.absolutePath)
        val eng = Engine(config)
        eng.initialize()
        engine = eng
        isReady = true
        try {
            lock.withLock { openConversation("") }
        } catch (e: Exception) {
            close()
            throw e
        }
    }

    /** Force le départ d'une conversation neuve au prochain message (nouvelle conversation, arrêt, erreur). */
    fun resetConversation() {
        dirty = true
    }

    fun markDirty() {
        dirty = true
    }

    /**
     * Envoie [prompt] à la conversation en cours et appelle [onChunk] à chaque fragment
     * reçu (déjà nettoyé de tout raisonnement caché). Si la conversation doit repartir
     * de zéro (fenêtre de contexte presque pleine, interruption, erreur), [freshPrompt]
     * est envoyé à la place de [prompt] : il doit contenir tout le contexte nécessaire,
     * alors que [prompt] peut se contenter de prolonger l'échange en cours. [recap]
     * fournit le rappel des derniers échanges pour la conversation neuve.
     * Retourne le texte complet final, également nettoyé.
     */
    suspend fun ask(
        prompt: String,
        freshPrompt: String,
        recap: () -> String,
        onChunk: (String) -> Unit
    ): String = lock.withLock {
        if (engine == null) throw IllegalStateException("Le modèle n'est pas encore chargé")
        var decorated = decorate(prompt)
        if (conversation == null || dirty || usedChars + decorated.length + ANSWER_MARGIN > MAX_CONTEXT_CHARS) {
            openConversation(recap())
            decorated = decorate(freshPrompt)
        }
        val conv = conversation ?: throw IllegalStateException("Le modèle n'est pas encore chargé")
        usedChars += decorated.length
        val builder = StringBuilder()
        try {
            conv.sendMessageAsync(decorated).collect { fragment ->
                builder.append(fragment)
                onChunk(stripThinking(builder.toString()))
            }
        } catch (e: Exception) {
            // Interruption ou erreur : l'état interne de la conversation n'est plus fiable.
            dirty = true
            throw e
        }
        usedChars += builder.length
        stripThinking(builder.toString())
    }

    /**
     * Pose une question isolée, dans une conversation jetable au contexte vierge (sans la
     * personnalité ni l'historique). Sert à résumer un long document morceau par morceau
     * sans saturer la conversation principale, qui repartira à neuf au message suivant.
     */
    suspend fun askOneShot(prompt: String): String = lock.withLock {
        val eng = engine ?: throw IllegalStateException("Le modèle n'est pas encore chargé")
        try { conversation?.close() } catch (_: Exception) {}
        conversation = null
        dirty = true
        val conv = eng.createConversation()
        try {
            val b = StringBuilder()
            conv.sendMessageAsync(decorate(prompt)).collect { fragment ->
                b.append(fragment)
            }
            stripThinking(b.toString())
        } finally {
            try { conv.close() } catch (_: Exception) {}
        }
    }

    private suspend fun openConversation(recap: String) {
        val eng = engine ?: throw IllegalStateException("Le modèle n'est pas encore chargé")
        try { conversation?.close() } catch (_: Exception) {}
        conversation = null
        val conv = eng.createConversation()
        conversation = conv
        dirty = false

        val priming = buildString {
            append(persona)
            if (recap.isNotBlank()) {
                append("\n\n[HISTORIQUE_RECENT — la conversation reprend ; voici les derniers échanges, sers-t'en comme contexte sans les répéter]\n")
                append(recap)
            }
            append("\n\nRéponds uniquement par : OK")
        }
        val decorated = decorate(priming)
        usedChars = decorated.length + 8

        // Amorce silencieuse : on établit la personnalité d'IGOR sans afficher la réponse.
        try {
            conv.sendMessageAsync(decorated).collect { /* réponse d'amorçage ignorée */ }
        } catch (e: CancellationException) {
            dirty = true
            throw e
        } catch (_: Exception) {
            // Si l'amorçage échoue, IGOR répondra quand même, juste sans ce cadrage initial.
        }
    }

    private fun decorate(prompt: String): String = if (isQwen) "$prompt /no_think" else prompt

    fun close() {
        try { conversation?.close() } catch (_: Exception) {}
        try { engine?.close() } catch (_: Exception) {}
        conversation = null
        engine = null
        isReady = false
        dirty = false
        usedChars = 0
    }

    companion object {
        /** Taille maximale (en caractères, ≈ 3 caractères par token) avant de repartir d'une conversation neuve. */
        private const val MAX_CONTEXT_CHARS = 9_000
        private const val ANSWER_MARGIN = 1_500

        private val thinkBlock = Regex("(?s)<think>.*?</think>")
        private val danglingThinkOpen = Regex("(?s)<think>.*$")

        /**
         * Retire tout bloc <think>...</think> complet, ainsi qu'un éventuel <think>
         * resté ouvert en cours de streaming (on masque le brouillon jusqu'à ce que
         * la balise fermante arrive, ou définitivement si elle n'arrive jamais).
         */
        fun stripThinking(text: String): String {
            val withoutClosed = thinkBlock.replace(text, "")
            return danglingThinkOpen.replace(withoutClosed, "").trim()
        }
    }
}
