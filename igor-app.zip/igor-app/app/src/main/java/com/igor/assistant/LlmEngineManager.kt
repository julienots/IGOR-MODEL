package com.igor.assistant

import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.flow.collect
import java.io.File

/**
 * Enveloppe autour du moteur LiteRT-LM (com.google.ai.edge.litertlm), le framework
 * d'inférence sur appareil de Google. Le modèle (.litertlm) tourne entièrement en
 * local, sans réseau, une fois chargé : IGOR ne dépend d'aucun serveur pour générer
 * ses réponses.
 *
 * Remarque : l'API Kotlin de LiteRT-LM évolue encore rapidement (bibliothèque en
 * développement actif). Si une méthode ci-dessous ne correspond plus exactement à
 * la version publiée sur Google Maven au moment du build, consulte le KDoc généré
 * par Android Studio sur la classe Engine / Conversation — la forme générale
 * (Engine -> initialize -> createConversation -> sendMessageAsync) est stable.
 */
class LlmEngineManager {

    private var engine: Engine? = null
    private var conversation: Conversation? = null

    @Volatile
    var isReady: Boolean = false
        private set

    private val persona = """
        Tu es IGOR, une intelligence artificielle conversationnelle. Quel que soit
        le modèle de langage qui te fait tourner (Gemma 3 4B, 1B, ou tout autre
        modèle .litertlm importé par l'utilisateur), tu gardes toujours la même
        personnalité et les mêmes règles ci-dessous. Tu réponds toujours en
        français.

        RÈGLE ABSOLUE — jamais de réponse générique : ne réponds jamais par une
        phrase creuse, un conseil passe-partout ou une formule toute faite qui
        pourrait s'appliquer à n'importe quelle question. Prends toujours le temps
        de vraiment traiter CETTE question précise, avec des éléments concrets,
        un raisonnement qui lui est propre, et si besoin des exemples ou des
        chiffres réels — jamais de généralités vagues pour remplir l'espace.

        TON — sérieux et amical à la fois : tu es fiable et précis, tu ne fais
        jamais semblant de savoir, et tu dis honnêtement quand tu n'es pas sûr
        plutôt que d'inventer. Mais tu restes chaleureux et naturel, jamais froid
        ni robotique — comme quelqu'un de compétent à qui on peut faire confiance.

        FORME — pensé pour être écouté autant que lu : écris en phrases complètes
        et fluides, sans symboles de mise en forme (pas d'astérisques, pas de
        dièses, pas de tirets de liste). Si tu dois énumérer plusieurs éléments,
        fais-le dans une phrase construite plutôt qu'en liste à puces, pour que ça
        reste agréable et clair à l'oreille comme à l'œil. Adapte la longueur de ta
        réponse à ce que la question mérite vraiment : développe quand c'est utile,
        reste concis quand une question est simple.

        CALCUL — si un message contient une balise [CALCUL_EXACT: expression =
        valeur], cette valeur a déjà été calculée par un moteur exact : annonce-la
        telle quelle, sans la recalculer, dans une phrase naturelle.

        RECHERCHE INTERNET — si un message contient une balise [RECHERCHE_WEB ...]
        suivie de résultats de recherche, appuie-toi sur ces résultats pour
        répondre de façon concrète et à jour : reformule les informations utiles
        avec tes propres mots, cite la source par son nom quand c'est utile (par
        exemple "d'après tel site"), mais ne lis jamais une adresse internet à
        voix haute. Si les résultats sont vides, insuffisants ou hors sujet,
        dis-le clairement à l'utilisateur plutôt que d'inventer une réponse.
    """.trimIndent()

    /**
     * Paramètres de génération visant des réponses plus développées et plus
     * "intelligentes" : plus de tokens autorisés par réponse (les réponses ne
     * sont pas coupées court), une température modérée (cohérence sans être
     * robotique) et un tirage top-k/top-p qui laisse le modèle varier son
     * vocabulaire au lieu de répéter toujours les mêmes tournures.
     *
     * Ces noms de paramètres correspondent à l'API LiteRT-LM au moment de
     * l'écriture ; comme la bibliothèque évolue vite, si l'un d'eux ne compile
     * plus, regarde le KDoc généré sur EngineConfig — la logique (plus de
     * tokens, température ~0.7-0.8, top-k/top-p activés) doit être conservée
     * quel que soit le nom exact des champs dans la version que tu utilises.
     */
    suspend fun initialize(modelFile: File) {
        close()
        val config = EngineConfig(
            modelPath = modelFile.absolutePath,
            maxTokens = 2048,
            temperature = 0.75f,
            topK = 40,
            topP = 0.9f
        )
        val eng = Engine(config)
        eng.initialize()
        val conv = eng.createConversation()
        engine = eng
        conversation = conv
        isReady = true

        // Amorce silencieuse : on établit la personnalité d'IGOR sans afficher la réponse.
        try {
            conv.sendMessageAsync(persona).collect { /* réponse d'amorçage ignorée */ }
        } catch (_: Exception) {
            // Si l'amorçage échoue, IGOR répondra quand même, juste sans ce cadrage initial.
        }
    }

    /**
     * Envoie [prompt] au modèle et appelle [onChunk] à chaque fragment de texte reçu
     * (le flux d'IGOR se construit token après token). Retourne le texte complet final.
     */
    suspend fun ask(prompt: String, onChunk: (String) -> Unit): String {
        val conv = conversation ?: throw IllegalStateException("Le modèle n'est pas encore chargé")
        val builder = StringBuilder()
        conv.sendMessageAsync(prompt).collect { fragment ->
            builder.append(fragment)
            onChunk(builder.toString())
        }
        return builder.toString()
    }

    fun close() {
        try { conversation?.close() } catch (_: Exception) {}
        try { engine?.close() } catch (_: Exception) {}
        conversation = null
        engine = null
        isReady = false
    }
}
