package com.igor.assistant

import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.flow.collect
import java.io.File

/**
 * Enveloppe autour du moteur LiteRT-LM (com.google.ai.edge.litertlm), le framework
 * d'inférence sur appareil de Google. Le modèle (.litertlm) tourne entièrement en
 * local, sans réseau, une fois chargé : IGOR ne dépend d'aucun serveur pour générer
 * ses réponses.
 *
 * Remarque : l'API Kotlin de LiteRT-LM évolue encore rapidement (bibliothèque en
 * développement actif). Si une méthode ci-dessous ne correspond plus exactement à
 * la version publiée sur Google Maven au moment du build, consulte le KDoc généré
 * par Android Studio sur la classe Engine / Conversation — la forme générale
 * (Engine -> initialize -> createConversation -> sendMessageAsync) est stable.
 */
class LlmEngineManager {

    private var engine: Engine? = null
    private var conversation: Conversation? = null

    @Volatile
    var isReady: Boolean = false
        private set

    private val persona = """
        Tu es IGOR, une intelligence artificielle conversationnelle qui fonctionne
        entièrement hors ligne, embarquée dans une application mobile. Tu réponds
        toujours en français, avec des phrases naturelles et variées que tu
        construis toi-même. Ton style est chaleureux et clair. Si un message
        contient une balise [CALCUL_EXACT: expression = valeur], cette valeur a
        déjà été calculée par un moteur exact : annonce-la telle quelle, sans la
        recalculer, dans une phrase naturelle.
    """.trimIndent()

    suspend fun initialize(modelFile: File) {
        close()
        val config = EngineConfig(modelPath = modelFile.absolutePath)
        val eng = Engine(config)
        eng.initialize()
        val conv = eng.createConversation()
        engine = eng
        conversation = conv
        isReady = true

        // Amorce silencieuse : on établit la personnalité d'IGOR sans afficher la réponse.
        try {
            conv.sendMessageAsync(persona).collect { /* réponse d'amorçage ignorée */ }
        } catch (_: Exception) {
            // Si l'amorçage échoue, IGOR répondra quand même, juste sans ce cadrage initial.
        }
    }

    /**
     * Envoie [prompt] au modèle et appelle [onChunk] à chaque fragment de texte reçu
     * (le flux d'IGOR se construit token après token). Retourne le texte complet final.
     */
    suspend fun ask(prompt: String, onChunk: (String) -> Unit): String {
        val conv = conversation ?: throw IllegalStateException("Le modèle n'est pas encore chargé")
        val builder = StringBuilder()
        conv.sendMessageAsync(prompt).collect { fragment ->
            builder.append(fragment)
            onChunk(builder.toString())
        }
        return builder.toString()
    }

    fun close() {
        try { conversation?.close() } catch (_: Exception) {}
        try { engine?.close() } catch (_: Exception) {}
        conversation = null
        engine = null
        isReady = false
    }
}
