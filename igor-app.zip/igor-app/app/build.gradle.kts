plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

android {
    namespace = "com.igor.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.igor.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "/META-INF/DEPENDENCIES"
            excludes += "/META-INF/LICENSE*"
            excludes += "/META-INF/NOTICE*"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.activity:activity-compose:1.9.2")

    implementation(platform("androidx.compose:compose-bom:2026.04.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")

    // Moteur d'inférence LLM 100% embarqué (LiteRT-LM — successeur de MediaPipe LLM Inference)
    implementation("com.google.ai.edge.litertlm:litertlm-android:latest.release")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.11.0")

    // Recherche web ponctuelle (optionnelle, activable par l'utilisateur) : IGOR reste
    // hors ligne par défaut, ce bloc ne sert qu'à aller chercher quelques extraits de
    // pages web quand l'utilisateur l'active ou pose une question manifestement datée.
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jsoup:jsoup:1.18.3")

    // Lecture de fichiers envoyés à IGOR, 100% sur le téléphone :
    // - PdfBox-Android : extraction du texte des PDF ;
    // - ML Kit (modèle latin embarqué, sans réseau) : OCR des images et des PDF scannés.
    // Word / Excel / PowerPoint sont lus avec le simple parseur XML d'Android (aucune dépendance).
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
