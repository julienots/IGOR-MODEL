# Conserve les classes JNI du moteur LiteRT-LM
-keep class com.google.ai.edge.litertlm.** { *; }
