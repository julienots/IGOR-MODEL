# IGOR — application Android avec IA embarquée

IGOR est une vraie application Android (Kotlin + Jetpack Compose) : un chat avec une
intelligence artificielle qui tourne **entièrement sur le téléphone**, sans serveur,
plus un moteur de calcul exact intégré. Le modèle de langage utilisé est **Qwen3
(1,7 milliard de paramètres, quantifié)** via **LiteRT-LM**, le framework d'inférence
sur appareil de Google (successeur de MediaPipe LLM Inference).

IGOR dispose aussi d'une **mémoire persistante** (il retient des éléments d'une
conversation à l'autre), d'une **recherche web ponctuelle et optionnelle** appuyée sur
plusieurs sources réelles (météo, Wikipédia, recherche généraliste — voir plus bas), de
**deux moteurs de calcul exacts** (arithmétique et conversions d'unités/dates), et peut
**générer de vrais fichiers téléchargeables** (.txt, .md, .pdf) à partir de ses réponses.
Voir la section *Mémoire et mise à jour* plus bas pour le détail — et surtout pour ce que
ces mots ne veulent *pas* dire ici.

## Comment ça marche

- `Calculator.kt` : un vrai analyseur d'expressions mathématiques (pas d'appel réseau,
  pas d'approximation) — IGOR ne se trompe jamais sur un calcul.
- `UnitConverter.kt` : deuxième moteur exact, même esprit que `Calculator` : conversions
  d'unités courantes (longueur, masse, volume, température) et calcul du nombre de
  jours entre deux dates. Un facteur de conversion ou une soustraction de dates n'a
  qu'une seule bonne réponse — autant la laisser à un moteur déterministe plutôt qu'à un
  petit modèle qui peut se tromper.
- `LlmEngineManager.kt` : charge le modèle `.litertlm` et fait tourner l'inférence
  directement sur le CPU/GPU du téléphone via `com.google.ai.edge.litertlm`. Filtre
  aussi le raisonnement caché (`<think>...</think>`) que Qwen3 peut produire, pour
  qu'IGOR aille droit à la réponse.
- `MemoryStore.kt` : mémoire à long terme, stockée localement (fichier JSON Lines
  privé, jamais envoyé nulle part). Détecte les demandes explicites ("retiens
  que…") et retrouve les souvenirs pertinents par recouvrement de mots-clés.
- `WebSearchTool.kt` : recherche web réelle, utilisée seulement si tu actives l'icône
  🌐 ou si ta question ressemble à une question d'actualité. Choisit sa source selon la
  question au lieu de dépendre d'un seul moteur fragile :
  1. **Météo** : appel direct à l'API Open-Meteo (géocodage + prévisions, sans clé) —
     plus fiable qu'un résultat de recherche générique pour ce type de question.
  2. **Wikipédia** : pour les questions "qui est / qu'est-ce que", l'API officielle
     (stable, pas de scraping) renvoie un résumé net et sourcé.
  3. **Recherche généraliste** : sinon, DuckDuckGo (html puis lite) puis Bing en
     dernier recours, avec lecture du contenu réel des meilleures pages (pas
     seulement le court extrait renvoyé par le moteur).
  Échoue honnêtement (et le dit à l'utilisateur via IGOR) si le téléphone est hors
  ligne ou si toutes les sources échouent — jamais d'invention à la place.
- `FileGenerator.kt` : génère de vrais fichiers (.txt, .md ou .pdf — le PDF est produit
  avec `android.graphics.pdf`, une API native d'Android, sans dépendance
  supplémentaire) à partir d'une réponse d'IGOR, dans le stockage privé de l'appli, et
  prépare les intentions Android pour les ouvrir ou les partager (via un
  `FileProvider`).
- `ChatViewModel.kt` : orchestre tout — détecte les calculs, conversions et demandes de
  fichier, va chercher la mémoire et le web si besoin, transmet ce contexte au modèle
  pour qu'il formule une réponse naturelle, puis génère le fichier si demandé.
- `MainActivity.kt` : l'interface (menu, écran d'import du modèle, chat, visualiseur
  de mémoire, interrupteur de recherche web, liste des fichiers générés).

Le modèle n'est **pas inclus dans le dépôt** : à ~2,1 Go, il est bien trop volumineux
pour un dépôt Git classique, et Google distribue ces fichiers sous licence (voir plus
bas). L'appli te guide pour l'importer au premier lancement.

## Mémoire et mise à jour — ce qu'IGOR fait vraiment

Il faut être honnête sur un point : **IGOR ne "s'entraîne" jamais lui-même**. Ré-
entraîner un réseau de neurones de 1,7 milliard de paramètres (calculer des
gradients, ajuster des poids) demande une puissance de calcul et une énergie que
n'a aucun téléphone — et ce n'est de toute façon pas prudent à faire sans contrôle
sur ce qui est appris. Aucune application mobile sérieuse ne fait ça, quoi qu'elle
en dise dans son marketing.

Ce qu'IGOR fait à la place, et qui donne en pratique le résultat recherché (un
assistant qui devient plus utile et plus à jour au fil du temps) :

1. **Mémoire persistante.** Chaque échange un peu substantiel, et tout ce que tu lui
   dis explicitement de retenir ("retiens que…", "souviens-toi que…"), est
   enregistré dans un fichier local. Au message suivant, IGOR ne relit pas tout —
   il ne récupère que les souvenirs qui semblent pertinents pour ta question et se
   les fait rappeler discrètement. Tu peux consulter et vider cette mémoire depuis
   le menu (☰ → *Mémoire d'IGOR*).
2. **Recherche web à la demande.** Pour les questions d'actualité (météo, résultats
   récents, "qui est l'actuel…", années 2026 et plus, etc.), ou quand tu actives
   l'icône 🌐 à côté du champ de texte, IGOR va chercher quelques extraits sur le
   web et s'en sert pour répondre, au lieu d'inventer à partir de connaissances
   figées à l'entraînement. S'il n'y a pas de réseau, il continue avec ses seules
   connaissances internes, sans planter.

Les deux sont strictement locaux à ton téléphone : rien n'est envoyé à un serveur
IGOR (il n'y en a pas), la recherche web ne part que quand tu le déclenches.

## Générer un fichier

Demande-lui explicitement, par exemple : « génère-moi une note au format PDF sur les
avantages du vélo », « exporte ça en .md », « crée-moi un fichier texte avec la liste
des courses ». IGOR rédige alors directement le contenu final (sans "Voici..." ni
commentaire sur le fichier lui-même) puis l'enregistre en `.txt` par défaut, ou en
`.md`/`.pdf` si tu précises le format. Le fichier apparaît ensuite sous sa réponse (et
dans ☰ → *Fichiers générés*) avec des boutons pour l'ouvrir ou le partager. Tout reste
dans le stockage privé de l'appli — aucune permission de stockage n'est demandée.

## Calculs exacts et conversions

En plus du calcul arithmétique ("combien fait 12% de 340 ?"), IGOR convertit les
unités courantes ("convertis 5 miles en km", "36 kg en livres", "20°C en Fahrenheit")
et calcule un nombre de jours entre deux dates ("combien de jours entre le 01/03/2026
et le 15/06/2026 ?") avec un moteur déterministe, jamais en devinant de tête.

## 1. Récupérer le projet et le compiler en APK

Ce dépôt contient un *workflow GitHub Actions* (`.github/workflows/build.yml`) qui
compile l'APK à ta place, sans Android Studio :

1. Crée un dépôt GitHub (public ou privé) et pousse-y le contenu de ce dossier.
2. Va dans l'onglet **Actions** de ton dépôt → le workflow *Build IGOR APK* se lance
   automatiquement.
3. Une fois terminé (quelques minutes), ouvre le run → **Artifacts** → télécharge
   `IGOR-debug-apk`. C'est ton APK installable.
4. Transfère l'APK sur ton téléphone Android et installe-le (autorise
   « sources inconnues » si demandé).

## 2. Obtenir le modèle de langage (.litertlm)

Google distribue des modèles compatibles LiteRT-LM sur Hugging Face, y compris des
conversions officielles de Qwen3, sous licence Apache 2.0 (acceptation gratuite et
immédiate) :

1. Va sur **huggingface.co/litert-community/Qwen3-1.7B**.
2. Connecte-toi (ou crée un compte gratuit) et accepte la licence affichée sur la
   page — c'est instantané.
3. Télécharge le fichier **`Qwen3_1.7B.litertlm`** (~2,1 Go, quantification
   `dynamic_wi8_afp32` — la seule variante proposée pour ce modèle, adaptée à un
   usage CPU général).
4. Garde ce fichier sur le téléphone (Téléchargements suffit).

## 3. Premier lancement

1. Ouvre IGOR.
2. Appuie sur **Choisir le fichier modèle** et sélectionne le `.litertlm` téléchargé.
3. IGOR le copie dans son stockage privé et charge le modèle (quelques secondes à
   une minute selon le téléphone). Une fois prêt, le point en haut à droite passe au
   vert et tu peux discuter.

## Prérequis matériels

Les modèles de langage sur appareil demandent un téléphone relativement récent —
Google recommande des appareils haut de gamme type Pixel 8 / Galaxy S23 ou plus
récents, avec plusieurs Go de RAM libres. Sur un appareil plus modeste, le
chargement peut être lent ou échouer : c'est une limite du matériel, pas de
l'application.

## Pour aller plus loin

- `app/build.gradle.kts` : dépendance `com.google.ai.edge.litertlm:litertlm-android`
  (`latest.release`) — tu peux la figer sur un numéro de version précis une fois que
  le premier build a réussi, en le relevant depuis Google Maven.
- Le fichier modèle peut être remplacé par n'importe quel `.litertlm` compatible
  (une autre taille de Qwen3, ou même un Gemma 3, par exemple) : rouvre juste le
  menu → *Importer / changer de modèle*.
- `WebSearchTool.kt` interroge `html.duckduckgo.com`, qui ne demande pas de clé API.
  Si tu préfères un autre moteur (Brave Search API, SerpAPI…), c'est le seul fichier
  à modifier ; le reste de l'appli n'a pas besoin de changer.
