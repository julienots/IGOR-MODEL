# IGOR — application Android avec IA embarquée

IGOR est une vraie application Android (Kotlin + Jetpack Compose) : un chat avec une
intelligence artificielle qui tourne **entièrement sur le téléphone**, sans serveur,
plus un moteur de calcul exact intégré. Le modèle de langage utilisé par défaut est
**Gemma 3 (4B, quantifié)** via **LiteRT-LM**, le framework d'inférence sur appareil
de Google (successeur de MediaPipe LLM Inference) : nettement plus intelligent et
plus riche à l'écrit que la variante 1B, au prix d'un téléphone un peu plus musclé
et d'un temps de chargement un peu plus long. La variante 1B reste utilisable en
repli sur les appareils plus modestes (voir la section modèle ci-dessous).

## Comment ça marche

- `Calculator.kt` : un vrai analyseur d'expressions mathématiques (pas d'appel réseau,
  pas d'approximation) — IGOR ne se trompe jamais sur un calcul.
- `LlmEngineManager.kt` : charge le modèle `.litertlm` et fait tourner l'inférence
  directement sur le CPU/GPU du téléphone via `com.google.ai.edge.litertlm`.
- `ChatViewModel.kt` : orchestre tout — détecte les calculs, les résout, transmet le
  résultat exact au modèle pour qu'il le formule dans une phrase naturelle.
- `MainActivity.kt` : l'interface (menu, écran d'import du modèle, chat).

Le modèle n'est **pas inclus dans le dépôt** : à ~600 Mo, il est trop volumineux pour
un dépôt Git classique, et Google distribue ces fichiers sous licence (voir plus bas).
L'appli te guide pour l'importer au premier lancement.

## 1. Récupérer le projet et le compiler en APK

Ce dépôt contient un *workflow GitHub Actions* (`.github/workflows/build.yml`) qui
compile l'APK à ta place, sans Android Studio :

1. Crée un dépôt GitHub (public ou privé) et pousse-y le contenu de ce dossier.
2. Va dans l'onglet **Actions** de ton dépôt → le workflow *Build IGOR APK* se lance
   automatiquement.
3. Une fois terminé (quelques minutes), ouvre le run → **Artifacts** → télécharge
   `IGOR-debug-apk`. C'est ton APK installable.
4. Transfère l'APK sur ton téléphone Android et installe-le (autorise
   « sources inconnues » si demandé).

## 2. Obtenir le modèle de langage (.litertlm)

Google distribue les modèles compatibles LiteRT-LM sur Hugging Face, sous licence
Gemma (acceptation gratuite et immédiate) :

1. Va sur **huggingface.co/litert-community/Gemma3-4B-IT** (le plus intelligent des
   deux, recommandé si ton téléphone est récent) — ou sur
   **huggingface.co/litert-community/Gemma3-1B-IT** si tu préfères la version plus
   légère et plus rapide.
2. Connecte-toi (ou crée un compte gratuit) et accepte la licence Gemma affichée sur
   la page — c'est instantané.
3. Télécharge une variante `.litertlm` adaptée à un usage CPU général (les variantes
   nommées par SoC comme `sm8550` sont optimisées pour des puces précises ; à défaut,
   utilise la version générique proposée sur la page du modèle).
4. Garde ce fichier sur le téléphone (Téléchargements suffit).

IGOR ne dépend pas d'une taille de modèle particulière : n'importe quel `.litertlm`
compatible fonctionne, tu peux donc essayer le 4B puis revenir au 1B (ou l'inverse)
simplement en réimportant un autre fichier depuis le menu de l'appli.

## 3. Premier lancement

1. Ouvre IGOR.
2. Appuie sur **Choisir le fichier modèle** et sélectionne le `.litertlm` téléchargé.
3. IGOR le copie dans son stockage privé et charge le modèle (quelques secondes à
   une minute selon le téléphone). Une fois prêt, le point en haut à droite passe au
   vert et tu peux discuter.

## Prérequis matériels

Les modèles de langage sur appareil demandent un téléphone relativement récent —
Google recommande des appareils haut de gamme type Pixel 8 / Galaxy S23 ou plus
récents, avec plusieurs Go de RAM libres. Le modèle 4B (recommandé pour la
qualité des réponses) est plus exigeant que le 1B : compte plutôt 6-8 Go de RAM
disponible et un chargement un peu plus long. Sur un appareil plus modeste,
repasse au modèle 1B — le chargement d'un modèle trop lourd pour le téléphone
peut être lent ou échouer : c'est une limite du matériel, pas de l'application.

## Pour aller plus loin

- `app/build.gradle.kts` : dépendance `com.google.ai.edge.litertlm:litertlm-android`
  (`0.17.0`) — tu peux la figer sur un numéro de version précis une fois que
  le premier build a réussi, en le relevant depuis Google Maven.
- Le fichier modèle peut être remplacé par n'importe quel `.litertlm` compatible
  (d'autres tailles de Gemma 3, par exemple) : rouvre juste le menu → *Importer /
  changer de modèle*.
