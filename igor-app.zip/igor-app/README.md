# IGOR — application Android avec IA embarquée

IGOR est une vraie application Android (Kotlin + Jetpack Compose) : un chat avec une
intelligence artificielle qui tourne **entièrement sur le téléphone**, sans serveur,
plus un moteur de calcul exact intégré. Le modèle de langage utilisé est **Gemma 3
(1B, quantifié)** via **LiteRT-LM**, le framework d'inférence sur appareil de Google
(successeur de MediaPipe LLM Inference).

## Comment ça marche

- `Calculator.kt` : un vrai analyseur d'expressions mathématiques (pas d'appel réseau,
  pas d'approximation) — IGOR ne se trompe jamais sur un calcul.
- `LlmEngineManager.kt` : charge le modèle `.litertlm` et fait tourner l'inférence
  directement sur le CPU/GPU du téléphone via `com.google.ai.edge.litertlm`.
- `ChatViewModel.kt` : orchestre tout — détecte les calculs, les résout, transmet le
  résultat exact au modèle pour qu'il le formule dans une phrase naturelle.
- `MainActivity.kt` : l'interface (menu, écran d'import du modèle, chat).

Le modèle n'est **pas inclus dans le dépôt** : à ~600 Mo, il est trop volumineux pour
un dépôt Git classique, et Google distribue ces fichiers sous licence (voir plus bas).
L'appli te guide pour l'importer au premier lancement.

## 1. Récupérer le projet et le compiler en APK

Ce dépôt contient un *workflow GitHub Actions* (`.github/workflows/build.yml`) qui
compile l'APK à ta place, sans Android Studio :

1. Crée un dépôt GitHub (public ou privé) et pousse-y le contenu de ce dossier.
2. Va dans l'onglet **Actions** de ton dépôt → le workflow *Build IGOR APK* se lance
   automatiquement.
3. Une fois terminé (quelques minutes), ouvre le run → **Artifacts** → télécharge
   `IGOR-debug-apk`. C'est ton APK installable.
4. Transfère l'APK sur ton téléphone Android et installe-le (autorise
   « sources inconnues » si demandé).

## 2. Obtenir le modèle de langage (.litertlm)

Google distribue les modèles compatibles LiteRT-LM sur Hugging Face, sous licence
Gemma (acceptation gratuite et immédiate) :

1. Va sur **huggingface.co/litert-community/Gemma3-1B-IT**.
2. Connecte-toi (ou crée un compte gratuit) et accepte la licence Gemma affichée sur
   la page — c'est instantané.
3. Télécharge une variante `.litertlm` adaptée à un usage CPU général (les variantes
   nommées par SoC comme `sm8550` sont optimisées pour des puces précises ; à défaut,
   utilise la version générique proposée sur la page du modèle).
4. Garde ce fichier sur le téléphone (Téléchargements suffit).

## 3. Premier lancement

1. Ouvre IGOR.
2. Appuie sur **Choisir le fichier modèle** et sélectionne le `.litertlm` téléchargé.
3. IGOR le copie dans son stockage privé et charge le modèle (quelques secondes à
   une minute selon le téléphone). Une fois prêt, le point en haut à droite passe au
   vert et tu peux discuter.

## Prérequis matériels

Les modèles de langage sur appareil demandent un téléphone relativement récent —
Google recommande des appareils haut de gamme type Pixel 8 / Galaxy S23 ou plus
récents, avec plusieurs Go de RAM libres. Sur un appareil plus modeste, le
chargement peut être lent ou échouer : c'est une limite du matériel, pas de
l'application.

## Pour aller plus loin

- `app/build.gradle.kts` : dépendance `com.google.ai.edge.litertlm:litertlm-android`
  (`latest.release`) — tu peux la figer sur un numéro de version précis une fois que
  le premier build a réussi, en le relevant depuis Google Maven.
- Le fichier modèle peut être remplacé par n'importe quel `.litertlm` compatible
  (d'autres tailles de Gemma 3, par exemple) : rouvre juste le menu → *Importer /
  changer de modèle*.
