# IGOR — application Android avec IA embarquée

IGOR est une vraie application Android (Kotlin + Jetpack Compose) : un chat avec une
intelligence artificielle qui tourne **entièrement sur le téléphone**, sans serveur,
plus un moteur de calcul exact intégré. Le modèle de langage utilisé est **Qwen3
(1,7 milliard de paramètres, quantifié)** via **LiteRT-LM**, le framework d'inférence
sur appareil de Google (successeur de MediaPipe LLM Inference).

IGOR dispose aussi d'une **mémoire persistante** (il retient des éléments d'une
conversation à l'autre) et d'une **recherche web ponctuelle et optionnelle** (pour les
questions d'actualité). Voir la section *Mémoire et mise à jour* plus bas pour le
détail — et surtout pour ce que ces deux mots ne veulent *pas* dire ici.

## Comment ça marche

- `Calculator.kt` : un vrai analyseur d'expressions mathématiques (pas d'appel réseau,
  pas d'approximation) — IGOR ne se trompe jamais sur un calcul.
- `LlmEngineManager.kt` : charge le modèle `.litertlm` et fait tourner l'inférence
  directement sur le CPU/GPU du téléphone via `com.google.ai.edge.litertlm`. Filtre
  aussi le raisonnement caché (`<think>...</think>`) que Qwen3 peut produire, pour
  qu'IGOR aille droit à la réponse.
- `MemoryStore.kt` : mémoire à long terme, stockée localement (fichier JSON Lines
  privé, jamais envoyé nulle part). Détecte les demandes explicites ("retiens
  que…") et retrouve les souvenirs pertinents par recouvrement de mots-clés.
- `WebSearchTool.kt` : recherche web ponctuelle (DuckDuckGo, sans clé API), utilisée
  seulement si tu actives l'icône 🌐 ou si ta question ressemble à une question
  d'actualité. Échoue silencieusement si le téléphone est hors ligne.
- `ChatViewModel.kt` : orchestre tout — détecte les calculs et les résout, va
  chercher la mémoire et le web si besoin, transmet ce contexte au modèle pour qu'il
  formule une réponse naturelle.
- `MainActivity.kt` : l'interface (menu, écran d'import du modèle, chat, visualiseur
  de mémoire, interrupteur de recherche web).

Le modèle n'est **pas inclus dans le dépôt** : à ~2,1 Go, il est bien trop volumineux
pour un dépôt Git classique, et Google distribue ces fichiers sous licence (voir plus
bas). L'appli te guide pour l'importer au premier lancement.

## Mémoire et mise à jour — ce qu'IGOR fait vraiment

Il faut être honnête sur un point : **IGOR ne "s'entraîne" jamais lui-même**. Ré-
entraîner un réseau de neurones de 1,7 milliard de paramètres (calculer des
gradients, ajuster des poids) demande une puissance de calcul et une énergie que
n'a aucun téléphone — et ce n'est de toute façon pas prudent à faire sans contrôle
sur ce qui est appris. Aucune application mobile sérieuse ne fait ça, quoi qu'elle
en dise dans son marketing.

Ce qu'IGOR fait à la place, et qui donne en pratique le résultat recherché (un
assistant qui devient plus utile et plus à jour au fil du temps) :

1. **Mémoire persistante.** Chaque échange un peu substantiel, et tout ce que tu lui
   dis explicitement de retenir ("retiens que…", "souviens-toi que…"), est
   enregistré dans un fichier local. Au message suivant, IGOR ne relit pas tout —
   il ne récupère que les souvenirs qui semblent pertinents pour ta question et se
   les fait rappeler discrètement. Tu peux consulter et vider cette mémoire depuis
   le menu (☰ → *Mémoire d'IGOR*).
2. **Recherche web à la demande.** Pour les questions d'actualité (météo, résultats
   récents, "qui est l'actuel…", années 2026 et plus, etc.), ou quand tu actives
   l'icône 🌐 à côté du champ de texte, IGOR va chercher quelques extraits sur le
   web et s'en sert pour répondre, au lieu d'inventer à partir de connaissances
   figées à l'entraînement. S'il n'y a pas de réseau, il continue avec ses seules
   connaissances internes, sans planter.

Les deux sont strictement locaux à ton téléphone : rien n'est envoyé à un serveur
IGOR (il n'y en a pas), la recherche web ne part que quand tu le déclenches.

## 1. Récupérer le projet et le compiler en APK

Ce dépôt contient un *workflow GitHub Actions* (`.github/workflows/build.yml`) qui
compile l'APK à ta place, sans Android Studio :

1. Crée un dépôt GitHub (public ou privé) et pousse-y le contenu de ce dossier.
2. Va dans l'onglet **Actions** de ton dépôt → le workflow *Build IGOR APK* se lance
   automatiquement.
3. Une fois terminé (quelques minutes), ouvre le run → **Artifacts** → télécharge
   `IGOR-debug-apk`. C'est ton APK installable.
4. Transfère l'APK sur ton téléphone Android et installe-le (autorise
   « sources inconnues » si demandé).

## 2. Obtenir le modèle de langage (.litertlm)

Google distribue des modèles compatibles LiteRT-LM sur Hugging Face, y compris des
conversions officielles de Qwen3, sous licence Apache 2.0 (acceptation gratuite et
immédiate) :

1. Va sur **huggingface.co/litert-community/Qwen3-1.7B**.
2. Connecte-toi (ou crée un compte gratuit) et accepte la licence affichée sur la
   page — c'est instantané.
3. Télécharge le fichier **`Qwen3_1.7B.litertlm`** (~2,1 Go, quantification
   `dynamic_wi8_afp32` — la seule variante proposée pour ce modèle, adaptée à un
   usage CPU général).
4. Garde ce fichier sur le téléphone (Téléchargements suffit).

## 3. Premier lancement

1. Ouvre IGOR.
2. Appuie sur **Choisir le fichier modèle** et sélectionne le `.litertlm` téléchargé.
3. IGOR le copie dans son stockage privé et charge le modèle (quelques secondes à
   une minute selon le téléphone). Une fois prêt, le point en haut à droite passe au
   vert et tu peux discuter.

## Prérequis matériels

Les modèles de langage sur appareil demandent un téléphone relativement récent —
Google recommande des appareils haut de gamme type Pixel 8 / Galaxy S23 ou plus
récents, avec plusieurs Go de RAM libres. Sur un appareil plus modeste, le
chargement peut être lent ou échouer : c'est une limite du matériel, pas de
l'application.

## Pour aller plus loin

- `app/build.gradle.kts` : dépendance `com.google.ai.edge.litertlm:litertlm-android`
  (`latest.release`) — tu peux la figer sur un numéro de version précis une fois que
  le premier build a réussi, en le relevant depuis Google Maven.
- Le fichier modèle peut être remplacé par n'importe quel `.litertlm` compatible
  (une autre taille de Qwen3, ou même un Gemma 3, par exemple) : rouvre juste le
  menu → *Importer / changer de modèle*.
- `WebSearchTool.kt` interroge `html.duckduckgo.com`, qui ne demande pas de clé API.
  Si tu préfères un autre moteur (Brave Search API, SerpAPI…), c'est le seul fichier
  à modifier ; le reste de l'appli n'a pas besoin de changer.
