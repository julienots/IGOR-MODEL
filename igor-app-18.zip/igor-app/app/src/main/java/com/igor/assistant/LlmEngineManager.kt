package com.igor.assistant

import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.flow.collect
import java.io.File

/**
 * Enveloppe autour du moteur LiteRT-LM (com.google.ai.edge.litertlm), le framework
 * d'inférence sur appareil de Google. Le modèle (.litertlm) tourne entièrement en
 * local, sans réseau, une fois chargé : IGOR ne dépend d'aucun serveur pour générer
 * ses réponses.
 *
 * Modèle attendu : **Qwen3-1.7B** au format .litertlm, tel que publié par Google sur
 * huggingface.co/litert-community/Qwen3-1.7B (fichier `Qwen3_1.7B.litertlm`, ~2,1 Go).
 * L'API Engine -> Conversation -> sendMessageAsync est la même que pour Gemma : seul
 * le fichier modèle change, rien d'autre à adapter côté LiteRT-LM.
 *
 * Particularité de Qwen3 : la famille est entraînée avec un mode de "raisonnement"
 * (chain-of-thought) qui peut s'afficher entre des balises <think>...</think> avant
 * la réponse finale. Pour un assistant de chat, on ne veut pas exposer ce brouillon :
 * on demande donc explicitement au modèle de ne pas raisonner à voix haute (suffixe
 * `/no_think`, reconnu par Qwen3) et, par sécurité, on filtre quand même toute balise
 * <think> qui subsisterait dans la sortie (voir [stripThinking]).
 *
 * Remarque : l'API Kotlin de LiteRT-LM évolue encore rapidement (bibliothèque en
 * développement actif). Si une méthode ci-dessous ne correspond plus exactement à
 * la version publiée sur Google Maven au moment du build, consulte le KDoc généré
 * par Android Studio sur la classe Engine / Conversation — la forme générale
 * (Engine -> initialize -> createConversation -> sendMessageAsync) est stable.
 */
class LlmEngineManager {

    private var engine: Engine? = null
    private var conversation: Conversation? = null

    @Volatile
    var isReady: Boolean = false
        private set

    private val persona = """
        Tu es IGOR, une intelligence artificielle conversationnelle qui fonctionne
        entièrement hors ligne, embarquée dans une application mobile (modèle Qwen3
        1,7 milliard de paramètres). Tu réponds toujours en français, avec des
        phrases naturelles et variées que tu construis toi-même. Ton style est
        chaleureux et clair. Ne montre jamais ton raisonnement intermédiaire, ne
        produis aucune balise <think> : donne directement ta réponse finale. /no_think

        Certains messages contiennent des balises invisibles pour l'utilisateur qui
        te donnent du contexte fiable :
        - [CALCUL_EXACT: expression = valeur] : ce résultat a déjà été calculé par un
          moteur exact, annonce-le tel quel, sans le recalculer.
        - [MEMOIRE: ...] : des éléments que tu as retenus de conversations
          précédentes avec cet utilisateur. Utilise-les seulement s'ils sont
          pertinents pour la question posée.
        - [RECHERCHE_WEB: ...] : des extraits trouvés à l'instant sur internet pour
          répondre à une question d'actualité. Fonde ta réponse dessus et signale que
          l'information vient d'une recherche récente ; si les extraits ne suffisent
          pas, dis-le simplement au lieu d'inventer.
    """.trimIndent()

    suspend fun initialize(modelFile: File) {
        close()
        val config = EngineConfig(modelPath = modelFile.absolutePath)
        val eng = Engine(config)
        eng.initialize()
        val conv = eng.createConversation()
        engine = eng
        conversation = conv
        isReady = true

        // Amorce silencieuse : on établit la personnalité d'IGOR sans afficher la réponse.
        try {
            conv.sendMessageAsync(persona).collect { /* réponse d'amorçage ignorée */ }
        } catch (_: Exception) {
            // Si l'amorçage échoue, IGOR répondra quand même, juste sans ce cadrage initial.
        }
    }

    /**
     * Envoie [prompt] au modèle et appelle [onChunk] à chaque fragment de texte reçu,
     * déjà nettoyé de tout raisonnement caché (le flux d'IGOR se construit token après
     * token). Retourne le texte complet final, également nettoyé.
     */
    suspend fun ask(prompt: String, onChunk: (String) -> Unit): String {
        val conv = conversation ?: throw IllegalStateException("Le modèle n'est pas encore chargé")
        val builder = StringBuilder()
        conv.sendMessageAsync("$prompt /no_think").collect { fragment ->
            builder.append(fragment)
            onChunk(stripThinking(builder.toString()))
        }
        return stripThinking(builder.toString())
    }

    fun close() {
        try { conversation?.close() } catch (_: Exception) {}
        try { engine?.close() } catch (_: Exception) {}
        conversation = null
        engine = null
        isReady = false
    }

    companion object {
        private val thinkBlock = Regex("(?s)<think>.*?</think>")
        private val danglingThinkOpen = Regex("(?s)<think>.*$")

        /**
         * Retire tout bloc <think>...</think> complet, ainsi qu'un éventuel <think>
         * resté ouvert en cours de streaming (on masque le brouillon jusqu'à ce que
         * la balise fermante arrive, ou définitivement si elle n'arrive jamais).
         */
        fun stripThinking(text: String): String {
            val withoutClosed = thinkBlock.replace(text, "")
            return danglingThinkOpen.replace(withoutClosed, "").trim()
        }
    }
}
