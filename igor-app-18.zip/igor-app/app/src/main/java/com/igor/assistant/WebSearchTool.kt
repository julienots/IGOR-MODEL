package com.igor.assistant

import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

/**
 * Recherche web ponctuelle et facultative.
 *
 * IGOR reste par défaut un assistant 100% hors ligne. Ce module ne s'active que
 * lorsque l'utilisateur bascule l'interrupteur "recherche web" du chat, ou pose une
 * question qui semble manifestement d'actualité (voir [ChatViewModel.looksTimely]).
 * Il n'y a pas de clé API à configurer : on interroge la version HTML légère de
 * DuckDuckGo, qui ne demande pas d'authentification, et on en extrait quelques
 * extraits de résultats. En cas d'échec (pas de réseau, service indisponible, etc.),
 * la fonction retourne une liste vide plutôt que de planter — IGOR répond alors avec
 * ses seules connaissances internes, comme d'habitude.
 */
object WebSearchTool {

    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    data class Result(val title: String, val snippet: String)

    /** Retourne jusqu'à [maxResults] résultats pour [query], ou une liste vide si la recherche échoue. */
    fun search(query: String, maxResults: Int = 4): List<Result> {
        return try {
            val url = "https://html.duckduckgo.com/html/?q=" +
                java.net.URLEncoder.encode(query, "UTF-8")
            val request = Request.Builder()
                .url(url)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128 Mobile Safari/537.36"
                )
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val html = response.body?.string() ?: return emptyList()
                val doc = Jsoup.parse(html)
                doc.select("div.result").take(maxResults).mapNotNull { el ->
                    val title = el.select("a.result__a").firstOrNull()?.text()?.trim()
                    val snippet = el.select("a.result__snippet, .result__snippet").firstOrNull()?.text()?.trim()
                    if (title.isNullOrEmpty() && snippet.isNullOrEmpty()) null
                    else Result(title.orEmpty(), snippet.orEmpty())
                }.filter { it.title.isNotEmpty() || it.snippet.isNotEmpty() }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /** Formate les résultats pour les injecter dans le prompt caché envoyé au modèle. */
    fun formatForPrompt(results: List<Result>): String {
        if (results.isEmpty()) return ""
        return results.joinToString(" | ") { r ->
            listOf(r.title, r.snippet).filter { it.isNotEmpty() }.joinToString(" : ")
        }
    }
}
