package com.igor.assistant

import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Mémoire à long terme d'IGOR.
 *
 * Ceci n'entraîne pas et ne modifie jamais les poids du modèle Qwen3 : "faire
 * progresser" un modèle de 1,7 milliard de paramètres directement sur un téléphone
 * (recalculer des gradients, ré-entraîner) n'est pas réaliste avec la puissance et la
 * batterie disponibles, et ce n'est de toute façon pas ce qui rend un assistant plus
 * utile au quotidien. Ce qui fonctionne bien à la place, et que fait cette classe :
 * IGOR se souvient, d'une conversation à l'autre, de ce que l'utilisateur lui a dit
 * ou demandé de retenir, et réinjecte ce contexte dans ses réponses futures. C'est un
 * mécanisme simple (pas d'embeddings, pas de base vectorielle) mais entièrement local
 * et privé : rien de tout ceci ne quitte le téléphone.
 *
 * Format de stockage : un fichier JSON Lines (`igor_memory.jsonl`) dans le stockage
 * privé de l'application, un souvenir par ligne : { "date": ..., "text": ... }.
 */
class MemoryStore(private val storageDir: File) {

    private val file = File(storageDir, "igor_memory.jsonl")
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)

    data class Memory(val date: String, val text: String)

    /** Ajoute un souvenir. [text] doit déjà être formulé de façon autonome (compréhensible hors contexte). */
    @Synchronized
    fun remember(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val entry = JSONObject().apply {
            put("date", dateFormat.format(Date()))
            put("text", clean)
        }
        file.appendText(entry.toString() + "\n")
        trimIfTooLarge()
    }

    /** Retourne tous les souvenirs, du plus récent au plus ancien. */
    @Synchronized
    fun all(): List<Memory> {
        if (!file.exists()) return emptyList()
        return file.readLines()
            .filter { it.isNotBlank() }
            .mapNotNull { line ->
                try {
                    val obj = JSONObject(line)
                    Memory(obj.getString("date"), obj.getString("text"))
                } catch (_: Exception) {
                    null
                }
            }
            .reversed()
    }

    /** Supprime tous les souvenirs. */
    @Synchronized
    fun clear() {
        if (file.exists()) file.delete()
    }

    /**
     * Retourne jusqu'à [limit] souvenirs jugés pertinents pour [query], par simple
     * recouvrement de mots (pas d'embeddings : suffisant pour un usage personnel léger,
     * et ça tourne instantanément sur téléphone sans dépendance supplémentaire).
     */
    @Synchronized
    fun relevant(query: String, limit: Int = 4): List<String> {
        val memories = all()
        if (memories.isEmpty()) return emptyList()
        val queryWords = tokenize(query)
        if (queryWords.isEmpty()) return memories.take(limit).map { it.text }

        return memories
            .map { it to overlapScore(queryWords, tokenize(it.text)) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(limit)
            .map { it.first.text }
    }

    private fun overlapScore(a: Set<String>, b: Set<String>): Int = a.intersect(b).size

    private fun tokenize(text: String): Set<String> {
        val stopWords = setOf(
            "le", "la", "les", "un", "une", "des", "de", "du", "et", "ou", "à", "au",
            "aux", "je", "tu", "il", "elle", "nous", "vous", "ils", "elles", "est",
            "es", "suis", "sont", "que", "qui", "quoi", "pour", "avec", "sur", "dans",
            "ce", "cet", "cette", "mon", "ma", "mes", "ton", "ta", "tes", "son", "sa",
            "ses", "pas", "plus", "très", "bien"
        )
        return text.lowercase()
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length > 2 && it !in stopWords }
            .toSet()
    }

    /** Garde le fichier raisonnable (les 500 derniers souvenirs) pour ne jamais grossir indéfiniment. */
    private fun trimIfTooLarge(maxEntries: Int = 500) {
        val lines = file.readLines()
        if (lines.size > maxEntries) {
            file.writeText(lines.takeLast(maxEntries).joinToString("\n") + "\n")
        }
    }

    companion object {
        /**
         * Détecte une demande explicite de mémorisation ("retiens que...",
         * "souviens-toi que...", "n'oublie pas que..."). Retourne le fait à retenir
         * (texte nettoyé) si le message en est une, sinon null.
         */
        private val memorizeCommand = Regex(
            "^(retiens|souviens[- ]toi|n'oublie pas|note)\\s+(que|:)?\\s*",
            RegexOption.IGNORE_CASE
        )

        fun extractExplicitMemory(raw: String): String? {
            val trimmed = raw.trim()
            if (!memorizeCommand.containsMatchIn(trimmed)) return null
            val fact = memorizeCommand.replace(trimmed, "").trim()
            return fact.ifEmpty { null }
        }
    }
}
