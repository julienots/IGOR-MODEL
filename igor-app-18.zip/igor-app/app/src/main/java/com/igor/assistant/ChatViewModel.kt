package com.igor.assistant

import android.app.Application
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Role { USER, ASSISTANT }
data class ChatMessage(val role: Role, val text: String, val isCalc: Boolean = false, val usedWeb: Boolean = false)

enum class ModelState { ABSENT, LOADING, READY, ERROR }

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val engine = LlmEngineManager()
    private val modelFile: File get() = File(getApplication<Application>().filesDir, "igor-model.litertlm")
    private val memory = MemoryStore(getApplication<Application>().filesDir)

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _modelState = MutableStateFlow(ModelState.ABSENT)
    val modelState: StateFlow<ModelState> = _modelState.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    /** Interrupteur "recherche web" que l'utilisateur peut activer/désactiver pour ce message. */
    private val _webSearchEnabled = MutableStateFlow(false)
    val webSearchEnabled: StateFlow<Boolean> = _webSearchEnabled.asStateFlow()

    private val _memories = MutableStateFlow<List<MemoryStore.Memory>>(memory.all())
    val memories: StateFlow<List<MemoryStore.Memory>> = _memories.asStateFlow()

    init {
        if (modelFile.exists()) loadModel()
    }

    fun toggleWebSearch() {
        _webSearchEnabled.value = !_webSearchEnabled.value
    }

    fun clearMemory() {
        memory.clear()
        _memories.value = emptyList()
    }

    /** Copie le fichier .litertlm choisi par l'utilisateur dans le stockage privé de l'appli, puis le charge. */
    fun importModel(uri: Uri) {
        _modelState.value = ModelState.LOADING
        _errorMessage.value = null
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                        modelFile.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalStateException("Impossible de lire le fichier sélectionné")
                }
                loadModel()
            } catch (e: Exception) {
                _modelState.value = ModelState.ERROR
                _errorMessage.value = "Import impossible : ${e.message ?: "erreur inconnue"}"
            }
        }
    }

    private fun loadModel() {
        _modelState.value = ModelState.LOADING
        viewModelScope.launch {
            try {
                withContext(Dispatchers.Default) { engine.initialize(modelFile) }
                _modelState.value = ModelState.READY
            } catch (e: Exception) {
                _modelState.value = ModelState.ERROR
                _errorMessage.value = "Chargement du modèle impossible : ${e.message ?: "erreur inconnue"}"
            }
        }
    }

    fun resetModel() {
        engine.close()
        if (modelFile.exists()) modelFile.delete()
        _modelState.value = ModelState.ABSENT
        _messages.value = emptyList()
    }

    fun newConversation() {
        _messages.value = emptyList()
    }

    fun send(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty() || _isThinking.value) return

        _messages.value = _messages.value + ChatMessage(Role.USER, text)

        // 1. Demande explicite de mémorisation ("retiens que...") : on stocke tout de
        // suite le fait, sans passer par le moteur de calcul.
        val explicitFact = MemoryStore.extractExplicitMemory(text)
        if (explicitFact != null) {
            memory.remember(explicitFact)
            _memories.value = memory.all()
            val hidden = "[MEMOIRE_ENREGISTREE: \"$explicitFact\"] Confirme en une phrase naturelle que tu as retenu ceci."
            askEngine(text, hidden, isCalc = false, usedWeb = false)
            return
        }

        // 2. Sinon, flux normal : calcul exact si applicable, mémoire pertinente, et
        // recherche web si activée ou si la question semble d'actualité.
        val expr = Calculator.extractExpression(text)
        if (expr != null) {
            try {
                val value = Calculator.evaluate(expr)
                val formatted = Calculator.format(value)
                val hidden = buildHiddenPrompt(
                    text,
                    calcTag = "$expr = $formatted"
                )
                askEngine(text, hidden, isCalc = true, usedWeb = false)
                return
            } catch (_: Exception) {
                // Pas une expression valide malgré les apparences : on continue en mode normal.
            }
        }

        val shouldSearch = _webSearchEnabled.value || looksTimely(text)
        if (shouldSearch) {
            _isThinking.value = true
            viewModelScope.launch {
                val results = withContext(Dispatchers.IO) {
                    if (isOnline()) WebSearchTool.search(text) else emptyList()
                }
                val hidden = buildHiddenPrompt(text, webSnippets = WebSearchTool.formatForPrompt(results))
                askEngine(text, hidden, isCalc = false, usedWeb = results.isNotEmpty())
            }
        } else {
            val hidden = buildHiddenPrompt(text)
            askEngine(text, hidden, isCalc = false, usedWeb = false)
        }
    }

    /** Construit le prompt final : message original + balises de contexte fiable (mémoire, web, calcul). */
    private fun buildHiddenPrompt(originalText: String, calcTag: String? = null, webSnippets: String? = null): String {
        val tags = StringBuilder()
        if (calcTag != null) tags.append("[CALCUL_EXACT: $calcTag] ")

        val relevantMemories = memory.relevant(originalText)
        if (relevantMemories.isNotEmpty()) {
            tags.append("[MEMOIRE: ${relevantMemories.joinToString(" ; ")}] ")
        }

        if (!webSnippets.isNullOrEmpty()) {
            tags.append("[RECHERCHE_WEB: $webSnippets] ")
        }

        return if (tags.isEmpty()) originalText else "$tags Message original : \"$originalText\""
    }

    private fun askEngine(displayText: String, prompt: String, isCalc: Boolean, usedWeb: Boolean) {
        if (_modelState.value != ModelState.READY) {
            _messages.value = _messages.value + ChatMessage(
                Role.ASSISTANT,
                "Le modèle d'IGOR n'est pas encore chargé — importe le fichier .litertlm depuis le menu.",
                isCalc
            )
            _isThinking.value = false
            return
        }
        _isThinking.value = true
        val placeholderIndex = _messages.value.size
        _messages.value = _messages.value + ChatMessage(Role.ASSISTANT, "", isCalc, usedWeb)

        viewModelScope.launch {
            try {
                val final = engine.ask(prompt) { partial ->
                    updateLastAssistantMessage(placeholderIndex, partial, isCalc, usedWeb)
                }
                updateLastAssistantMessage(placeholderIndex, final, isCalc, usedWeb)

                // On garde une trace compacte de l'échange pour pouvoir s'en resservir
                // plus tard, seulement si le message avait un contenu substantiel
                // (on évite de polluer la mémoire avec du small talk trop bref).
                if (displayText.length > 12 && final.isNotBlank()) {
                    val summary = final.take(220)
                    memory.remember("Question : \"$displayText\" — Réponse : \"$summary\"")
                    _memories.value = memory.all()
                }
            } catch (e: Exception) {
                updateLastAssistantMessage(
                    placeholderIndex,
                    "Un imprévu m'empêche de répondre : ${e.message ?: "erreur inconnue"}",
                    isCalc,
                    usedWeb
                )
            } finally {
                _isThinking.value = false
            }
        }
    }

    private fun updateLastAssistantMessage(index: Int, text: String, isCalc: Boolean, usedWeb: Boolean) {
        val current = _messages.value.toMutableList()
        if (index in current.indices) {
            current[index] = ChatMessage(Role.ASSISTANT, text, isCalc, usedWeb)
            _messages.value = current
        }
    }

    private fun isOnline(): Boolean {
        return try {
            val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java)
            val network = cm?.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            false
        }
    }

    override fun onCleared() {
        engine.close()
        super.onCleared()
    }

    companion object {
        // Mots-clés grossiers indiquant qu'une question porte probablement sur une
        // information récente / changeante, pour déclencher une recherche web même si
        // l'utilisateur n'a pas explicitement activé l'interrupteur.
        private val timelyPattern = Regex(
            "\\b(aujourd'hui|actualit[ée]|derni[eè]re?s?\\s+nouvelles?|en\\s+direct|ce\\s+matin|" +
                "cette\\s+semaine|m[ée]t[ée]o|score|r[ée]sultat\\s+du\\s+match|qui\\s+est\\s+(le|la)\\s+" +
                "(actuel|actuelle|pr[ée]sident|premier\\s+ministre|pdg)|20(2[6-9]|[3-9]\\d))\\b",
            RegexOption.IGNORE_CASE
        )

        fun looksTimely(text: String): Boolean = timelyPattern.containsMatchIn(text)
    }
}
